interface OnEventRequest {
    readonly RequestType: 'Create' | 'Update' | 'Delete';
    readonly PhysicalResourceId?: string;
    readonly ResourceProperties: {
        [key: string]: any;
    };
}
interface OnEventResponse {
    readonly PhysicalResourceId?: string;
    readonly Data?: {
        [name: string]: any;
    };
}
export declare function handler(event: OnEventRequest): Promise<OnEventResponse>;
export {};
