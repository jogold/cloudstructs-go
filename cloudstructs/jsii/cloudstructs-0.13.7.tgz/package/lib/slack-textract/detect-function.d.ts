import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for DetectFunction
 */
export interface DetectFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/slack-textract/detect.
 */
export declare class DetectFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: DetectFunctionProps);
}
