export interface SlackEvent {
    channel_id: string;
    file_id: string;
}
export declare function handler(event: SlackEvent): Promise<void>;
