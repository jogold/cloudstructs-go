export declare const handler: import("@aws/durable-execution-sdk-js").DurableLambdaHandler;
