import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for AnalyzeFunction
 */
export interface AnalyzeFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/ssl-server-test/analyze.
 */
export declare class AnalyzeFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: AnalyzeFunctionProps);
}
