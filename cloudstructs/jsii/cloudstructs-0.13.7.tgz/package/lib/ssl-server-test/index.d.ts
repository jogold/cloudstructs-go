import { ScheduleExpression } from 'aws-cdk-lib/aws-scheduler';
import { ITopic } from 'aws-cdk-lib/aws-sns';
import { Construct } from 'constructs';
import { SslServerTestGrade } from './types';
export { SslServerTestGrade } from './types';
/**
 * Properties for a SslServerTest
 */
export interface SslServerTestProps {
    /**
     * The email registered with SSL Labs API
     *
     * @see https://github.com/ssllabs/ssllabs-scan/blob/master/ssllabs-api-docs-v4.md#register-for-scan-api-initiation-and-result-fetching
     */
    readonly registrationEmail: string;
    /**
     * The hostname to test
     */
    readonly host: string;
    /**
     * Minimum grade for the test. The grade is calculated
     * using the worst grade of all endpoints.
     *
     * Used to send the results to an alarm SNS topic.
     *
     * @default SslServerTestGrade.A_PLUS
     */
    readonly minimumGrade?: SslServerTestGrade;
    /**
     * The topic to which the results must be sent when the
     * grade is below the minimum grade.
     *
     * @default - a new topic is created
     */
    readonly alarmTopic?: ITopic;
    /**
     * The schedule for the test
     *
     * @default - every day
     */
    readonly scheduleExpression?: ScheduleExpression;
}
/**
 * Perform SSL server test for a hostname
 */
export declare class SslServerTest extends Construct {
    /**
     * The topic to which the SSL test results are sent when the grade is
     * below the minimum grade
     */
    readonly alarmTopic: ITopic;
    constructor(scope: Construct, id: string, props: SslServerTestProps);
}
