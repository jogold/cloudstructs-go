import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for WhitelistFunction
 */
export interface WhitelistFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/email-receiver/whitelist.
 */
export declare class WhitelistFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: WhitelistFunctionProps);
}
