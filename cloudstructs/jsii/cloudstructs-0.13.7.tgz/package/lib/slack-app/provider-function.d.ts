import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for ProviderFunction
 */
export interface ProviderFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/slack-app/provider.
 */
export declare class ProviderFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: ProviderFunctionProps);
}
