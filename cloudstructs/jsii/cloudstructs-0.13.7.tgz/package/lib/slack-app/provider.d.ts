import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
export declare class SlackAppProvider extends Construct {
    /**
     * Creates a stack-singleton resource provider
     */
    static getOrCreate(scope: Construct): SlackAppProvider;
    readonly serviceToken: string;
    readonly handler: lambda.Function;
    constructor(scope: Construct, id: string);
}
