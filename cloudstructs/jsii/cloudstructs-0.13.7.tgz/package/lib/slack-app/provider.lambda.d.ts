import type { OnEventRequest, OnEventResponse } from 'aws-cdk-lib/custom-resources/lib/provider-framework/types';
export declare function handler(event: OnEventRequest): Promise<OnEventResponse>;
