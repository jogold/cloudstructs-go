export interface VerifyRequestSignatureOptions {
    readonly body: string;
    readonly requestSignature: string;
    readonly requestTimestamp: number;
    readonly signingSecret: string;
}
export declare function verifyRequestSignature(options: VerifyRequestSignatureOptions): boolean;
