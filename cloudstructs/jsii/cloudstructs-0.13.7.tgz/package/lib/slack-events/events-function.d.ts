import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for EventsFunction
 */
export interface EventsFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/slack-events/events.
 */
export declare class EventsFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: EventsFunctionProps);
}
