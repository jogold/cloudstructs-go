/**
 * Handle Slack events
 */
export declare function handler(event: AWSLambda.APIGatewayProxyEvent): Promise<AWSLambda.APIGatewayProxyResult>;
