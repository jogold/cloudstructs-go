export declare const MISSING_PHYSICAL_ID_MARKER = "AWSCDK::StateMachineProvider::MISSING_PHYSICAL_ID";
interface CloudFormationResponse {
    StackId: string;
    RequestId: string;
    PhysicalResourceId?: string;
    LogicalResourceId: string;
    ResponseURL: string;
    Data?: any;
    NoEcho?: boolean;
    Reason?: string;
}
export declare function respond(status: 'SUCCESS' | 'FAILED', event: CloudFormationResponse): Promise<void>;
export {};
