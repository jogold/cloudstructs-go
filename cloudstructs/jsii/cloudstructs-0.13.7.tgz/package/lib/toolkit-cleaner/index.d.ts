import { Duration } from 'aws-cdk-lib';
import { ScheduleExpression } from 'aws-cdk-lib/aws-scheduler';
import { Construct } from 'constructs';
/**
 * Properties for a ToolkitCleaner
 */
export interface ToolkitCleanerProps {
    /**
     * The schedule for the cleaner.
     *
     * @default - every day
     */
    readonly scheduleExpression?: ScheduleExpression;
    /**
     * Whether to clean on schedule. If you'd like to run the cleanup manually
     * via the console, set to `false`.
     *
     * @default true
     */
    readonly scheduleEnabled?: boolean;
    /**
     * Only output number of assets and total size that would be deleted
     * but without actually deleting assets.
     */
    readonly dryRun?: boolean;
    /**
     * Retain unused assets that were created recently
     *
     * @default - all unused assets are removed
     */
    readonly retainAssetsNewerThan?: Duration;
    /**
     * The timeout for the clean function
     *
     * @default Duration.minutes(30)
     */
    readonly cleanAssetsTimeout?: Duration;
}
/**
 * Clean unused S3 and ECR assets from your CDK Toolkit.
 */
export declare class ToolkitCleaner extends Construct {
    constructor(scope: Construct, id: string, props?: ToolkitCleanerProps);
}
