import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for CleanFunction
 */
export interface CleanFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/toolkit-cleaner/clean.
 */
export declare class CleanFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: CleanFunctionProps);
}
