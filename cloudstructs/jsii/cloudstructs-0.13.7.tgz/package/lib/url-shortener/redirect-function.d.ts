import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for RedirectFunction
 */
export interface RedirectFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/url-shortener/redirect.
 */
export declare class RedirectFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: RedirectFunctionProps);
}
