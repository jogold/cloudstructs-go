export declare function handler(event: AWSLambda.LambdaFunctionURLEvent): Promise<AWSLambda.LambdaFunctionURLResult>;
