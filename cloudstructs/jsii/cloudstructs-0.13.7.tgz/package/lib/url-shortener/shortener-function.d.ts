import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for ShortenerFunction
 */
export interface ShortenerFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/url-shortener/shortener.
 */
export declare class ShortenerFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: ShortenerFunctionProps);
}
