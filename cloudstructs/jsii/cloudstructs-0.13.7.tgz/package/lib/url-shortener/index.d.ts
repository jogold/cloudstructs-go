import { Duration } from 'aws-cdk-lib';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as route53 from 'aws-cdk-lib/aws-route53';
import { Construct } from 'constructs';
/**
 * Properties for a UrlShortener
 */
export interface UrlShortenerProps {
    /**
     * The hosted zone for the short URLs domain
     */
    readonly hostedZone: route53.IHostedZone;
    /**
     * The ACM certificate to use for the CloudFront distribution.
     * Must be in us-east-1.
     */
    readonly certificate: acm.ICertificate;
    /**
     * The record name to use in the hosted zone
     *
     * @default - zone root
     */
    readonly recordName?: string;
    /**
     * Expiration for short urls
     *
     * @default cdk.Duration.days(365)
     */
    readonly expiration?: Duration;
    /**
     * An interface VPC endpoint for API gateway. Specifying this property will
     * make the API private.
     *
     * @see https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-private-apis.html
     *
     * @default - API is public
     */
    readonly apiGatewayEndpoint?: ec2.IInterfaceVpcEndpoint;
    /**
     * Authorizer for API gateway.
     *
     * @default - do not use an authorizer for the API
     */
    readonly apiGatewayAuthorizer?: apigateway.IAuthorizer;
    /**
     * Whether to use IAM authorization
     *
     * @default - do not use IAM authorization
     */
    readonly iamAuthorization?: boolean;
    /**
     * Allowed origins for CORS
     *
     * @default - CORS is not enabled
     */
    readonly corsAllowOrigins?: string[];
    /**
     * A name for the bucket saving the redirects
     *
     * @default - derived from short link domain name
     */
    readonly bucketName?: string;
}
/**
 * URL shortener
 */
export declare class UrlShortener extends Construct {
    /**
     * The endpoint of the URL shortener API
     */
    readonly apiEndpoint: string;
    /**
     * The underlying API Gateway REST API
     */
    readonly api: apigateway.RestApi;
    private readonly iamAuthorization?;
    constructor(scope: Construct, id: string, props: UrlShortenerProps);
    /**
     * Grant access to invoke the URL shortener if protected by IAM authorization
     */
    grantInvoke(grantee: iam.IGrantable): iam.Grant;
}
