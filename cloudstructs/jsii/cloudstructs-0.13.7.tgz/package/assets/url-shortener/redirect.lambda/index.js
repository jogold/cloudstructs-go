"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/url-shortener/redirect.lambda.ts
var redirect_lambda_exports = {};
__export(redirect_lambda_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(redirect_lambda_exports);
var import_client_s3 = require("@aws-sdk/client-s3");
var s3Client = new import_client_s3.S3Client({});
async function handler(event) {
  try {
    const key = event.rawPath.substring(1);
    const data = await s3Client.send(new import_client_s3.GetObjectCommand({
      Bucket: process.env.BUCKET_NAME,
      Key: key
    }));
    if (!data.Body) {
      throw new Error("No body");
    }
    const redirect = JSON.parse(await data.Body.transformToString());
    if (!redirect.url) {
      throw new Error("Redirect object in S3 is missing a `url` property.");
    }
    return {
      statusCode: 301,
      headers: {
        Location: redirect.url
      }
    };
  } catch (err) {
    console.log(err);
    return { statusCode: 404 };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
