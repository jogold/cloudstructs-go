"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/slack-app/provider.lambda.ts
var provider_lambda_exports = {};
__export(provider_lambda_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(provider_lambda_exports);
var import_client_secrets_manager = require("@aws-sdk/client-secrets-manager");
var SLACK_API_BASE = "https://slack.com/api";
var secretsmanagerClient = new import_client_secrets_manager.SecretsManagerClient({});
async function handler(event) {
  console.log("Event: %j", event);
  const data = await secretsmanagerClient.send(new import_client_secrets_manager.GetSecretValueCommand({
    SecretId: event.ResourceProperties.configurationTokenSecretArn
  }));
  if (!data.SecretString) {
    throw new Error("No secret string found in configuration token secret");
  }
  const secret = JSON.parse(data.SecretString);
  let accessToken = secret.accessToken;
  if (!accessToken || isExpired(secret.exp ?? 0)) {
    if (!secret.refreshToken) {
      throw new Error("No refresh token found in configuration token secret");
    }
    console.log("Refreshing access token");
    const rotateUrl = new URL(`${SLACK_API_BASE}/tooling.tokens.rotate`);
    rotateUrl.searchParams.set("refresh_token", secret.refreshToken);
    const rotateResponse = await fetch(rotateUrl);
    if (!rotateResponse.ok) {
      throw new Error(`Failed to refresh access token: ${rotateResponse.status} ${rotateResponse.statusText}`);
    }
    const rotate = await rotateResponse.json();
    if (!rotate.ok) {
      throw new Error(`Failed to refresh access token: ${rotate.error}`);
    }
    console.log("Access token refreshed");
    accessToken = rotate.token;
    console.log("Saving access token");
    const putSecretValue = await secretsmanagerClient.send(new import_client_secrets_manager.PutSecretValueCommand({
      SecretId: event.ResourceProperties.configurationTokenSecretArn,
      SecretString: JSON.stringify({
        accessToken,
        refreshToken: rotate.refresh_token,
        exp: rotate.exp
      })
    }));
    console.log(`Successfully saved access token in secret ${putSecretValue.ARN}`);
  }
  const operation = event.RequestType.toLowerCase();
  const request = getManifestRequest(event);
  console.log(`Calling ${operation} manifest API: %j`, request);
  const manifestHttpResponse = await fetch(`${SLACK_API_BASE}/apps.manifest.${operation}`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(request)
  });
  if (!manifestHttpResponse.ok) {
    throw new Error(`Failed to ${operation} manifest: ${manifestHttpResponse.status} ${manifestHttpResponse.statusText}`);
  }
  const response = await manifestHttpResponse.json();
  if (!response.ok) {
    const errors = response.errors ? response.errors.map((err) => `${err.message} at ${err.pointer}`).join("\n") : "";
    throw new Error(`Failed to ${operation} manifest: ${response.error}.${errors ? `
${errors}}` : ""}`);
  }
  console.log(`Successfully ${operation}d Slack app ${event.PhysicalResourceId ?? response.app_id}`);
  if (event.RequestType === "Create" && response.credentials) {
    console.log("Saving app credentials");
    const putSecretValue = await secretsmanagerClient.send(new import_client_secrets_manager.PutSecretValueCommand({
      SecretId: event.ResourceProperties.credentialsSecretArn,
      SecretString: JSON.stringify({
        appId: response.app_id,
        clientId: response.credentials.client_id,
        clientSecret: response.credentials.client_secret,
        verificationToken: response.credentials.verification_token,
        signingSecret: response.credentials.signing_secret
      })
    }));
    console.log(`Successfully saved app credentials in secret ${putSecretValue.ARN}`);
  }
  return {
    PhysicalResourceId: response.app_id,
    Data: {
      appId: response.app_id
    }
  };
}
function isExpired(iat) {
  return iat - Date.now() / 1e3 < 0;
}
function getManifestRequest(event) {
  switch (event.RequestType) {
    case "Create":
      return {
        manifest: event.ResourceProperties.manifest
      };
    case "Update":
      return {
        app_id: event.PhysicalResourceId,
        manifest: event.ResourceProperties.manifest
      };
    case "Delete":
      return {
        app_id: event.PhysicalResourceId
      };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
