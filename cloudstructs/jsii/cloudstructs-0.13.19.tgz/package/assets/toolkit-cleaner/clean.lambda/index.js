"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/toolkit-cleaner/clean.lambda.ts
var clean_lambda_exports = {};
__export(clean_lambda_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(clean_lambda_exports);
var path = __toESM(require("path"));

// node_modules/@aws/durable-execution-sdk-js/dist/index.mjs
var import_events = require("events");
var asyncHooks = __toESM(require("node:async_hooks"), 1);
var import_crypto = require("crypto");
var import_node_console = require("node:console");
var import_node_util = __toESM(require("node:util"), 1);
var import_node_url = require("node:url");
var import_node_path = require("node:path");
var import_module = require("module");
var import_path = require("path");
var import_url = require("url");
var import_meta = {};
var OperationType = {
  CALLBACK: "CALLBACK",
  CHAINED_INVOKE: "CHAINED_INVOKE",
  CONTEXT: "CONTEXT",
  EXECUTION: "EXECUTION",
  STEP: "STEP",
  WAIT: "WAIT"
};
var OperationStatus = {
  CANCELLED: "CANCELLED",
  FAILED: "FAILED",
  PENDING: "PENDING",
  READY: "READY",
  STARTED: "STARTED",
  STOPPED: "STOPPED",
  SUCCEEDED: "SUCCEEDED",
  TIMED_OUT: "TIMED_OUT"
};
var OperationAction = {
  CANCEL: "CANCEL",
  FAIL: "FAIL",
  RETRY: "RETRY",
  START: "START",
  SUCCEED: "SUCCEED"
};
var DurableExecutionMode;
(function(DurableExecutionMode2) {
  DurableExecutionMode2["ExecutionMode"] = "ExecutionMode";
  DurableExecutionMode2["ReplayMode"] = "ReplayMode";
  DurableExecutionMode2["ReplaySucceededContext"] = "ReplaySucceededContext";
})(DurableExecutionMode || (DurableExecutionMode = {}));
var InvocationStatus;
(function(InvocationStatus2) {
  InvocationStatus2["SUCCEEDED"] = "SUCCEEDED";
  InvocationStatus2["FAILED"] = "FAILED";
  InvocationStatus2["PENDING"] = "PENDING";
})(InvocationStatus || (InvocationStatus = {}));
var OperationSubType;
(function(OperationSubType2) {
  OperationSubType2["STEP"] = "Step";
  OperationSubType2["WAIT"] = "Wait";
  OperationSubType2["CALLBACK"] = "Callback";
  OperationSubType2["RUN_IN_CHILD_CONTEXT"] = "RunInChildContext";
  OperationSubType2["MAP"] = "Map";
  OperationSubType2["MAP_ITERATION"] = "MapIteration";
  OperationSubType2["PARALLEL"] = "Parallel";
  OperationSubType2["PARALLEL_BRANCH"] = "ParallelBranch";
  OperationSubType2["WAIT_FOR_CALLBACK"] = "WaitForCallback";
  OperationSubType2["WAIT_FOR_CONDITION"] = "WaitForCondition";
  OperationSubType2["CHAINED_INVOKE"] = "ChainedInvoke";
})(OperationSubType || (OperationSubType = {}));
var DurableLogLevel;
(function(DurableLogLevel2) {
  DurableLogLevel2["INFO"] = "INFO";
  DurableLogLevel2["WARN"] = "WARN";
  DurableLogLevel2["ERROR"] = "ERROR";
  DurableLogLevel2["DEBUG"] = "DEBUG";
})(DurableLogLevel || (DurableLogLevel = {}));
var StepSemantics;
(function(StepSemantics2) {
  StepSemantics2["AtMostOncePerRetry"] = "AT_MOST_ONCE_PER_RETRY";
  StepSemantics2["AtLeastOncePerRetry"] = "AT_LEAST_ONCE_PER_RETRY";
})(StepSemantics || (StepSemantics = {}));
var JitterStrategy;
(function(JitterStrategy2) {
  JitterStrategy2["NONE"] = "NONE";
  JitterStrategy2["FULL"] = "FULL";
  JitterStrategy2["HALF"] = "HALF";
})(JitterStrategy || (JitterStrategy = {}));
var NestingType;
(function(NestingType2) {
  NestingType2["NESTED"] = "NESTED";
  NestingType2["FLAT"] = "FLAT";
})(NestingType || (NestingType = {}));
var BatchItemStatus;
(function(BatchItemStatus2) {
  BatchItemStatus2["SUCCEEDED"] = "SUCCEEDED";
  BatchItemStatus2["FAILED"] = "FAILED";
  BatchItemStatus2["STARTED"] = "STARTED";
})(BatchItemStatus || (BatchItemStatus = {}));
var CompletionOutcome;
(function(CompletionOutcome2) {
  CompletionOutcome2["SUCCEEDED"] = "SUCCEEDED";
  CompletionOutcome2["FAILED"] = "FAILED";
})(CompletionOutcome || (CompletionOutcome = {}));
var DurablePromise = class {
  /**
   * The actual promise instance, created only when execution begins.
   * Starts as null and remains null until the DurablePromise is first awaited
   * or chained (.then/.catch/.finally). Once created, it holds the running
   * promise returned by the _executor function.
   *
   * Example lifecycle:
   * ```typescript
   * const dp = new DurablePromise(() => fetch('/api')); // _promise = null
   * console.log(dp.isExecuted); // false
   *
   * const result = await dp; // NOW _promise = fetch('/api') promise
   * console.log(dp.isExecuted); // true
   * ```
   *
   * This lazy initialization prevents the executor from running until needed.
   */
  _promise = null;
  /**
   * Function that contains the deferred execution logic.
   * This function is NOT called when the DurablePromise is created - it's only
   * executed when the promise is first awaited or chained (.then/.catch/.finally).
   *
   * Example:
   * ```typescript
   * const durablePromise = new DurablePromise(async () => {
   *   console.log("This runs ONLY when awaited, not when created");
   *   return await someAsyncOperation();
   * });
   *
   * // At this point, nothing has executed yet
   * console.log("Promise created but not executed");
   *
   * // NOW the executor function runs
   * const result = await durablePromise;
   * ```
   */
  _executor;
  /** Flag indicating whether the promise has been executed (awaited or chained) */
  _isExecuted = false;
  /**
   * Creates a new DurablePromise
   * @param executor - Function containing the deferred execution logic
   */
  constructor(executor) {
    this._executor = executor;
  }
  /**
   * Ensures the promise is executed, creating the actual promise if needed
   * @returns The underlying promise instance
   */
  ensureExecution() {
    if (!this._promise) {
      this._isExecuted = true;
      this._promise = this._executor();
    }
    return this._promise;
  }
  /**
   * Attaches callbacks for the resolution and/or rejection of the Promise
   * Triggers execution if not already started
   */
  // biome-ignore lint/suspicious/noThenProperty: DurablePromise is deliberately a thenable. The "then" member is part of its public contract, so callers can await a durable operation directly.
  then(onfulfilled, onrejected) {
    return this.ensureExecution().then(onfulfilled, onrejected);
  }
  /**
   * Attaches a callback for only the rejection of the Promise
   * Triggers execution if not already started
   */
  catch(onrejected) {
    return this.ensureExecution().catch(onrejected);
  }
  /**
   * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected)
   * Triggers execution if not already started
   */
  finally(onfinally) {
    return this.ensureExecution().finally(onfinally);
  }
  /** Returns the string tag for the promise type */
  get [Symbol.toStringTag]() {
    return "DurablePromise";
  }
  /**
   * Check if the promise has been executed (awaited or had .then/.catch/.finally called)
   * @returns true if execution has started, false otherwise
   */
  get isExecuted() {
    return this._isExecuted;
  }
};
var OperationLifecycleState;
(function(OperationLifecycleState2) {
  OperationLifecycleState2["EXECUTING"] = "EXECUTING";
  OperationLifecycleState2["RETRY_WAITING"] = "RETRY_WAITING";
  OperationLifecycleState2["IDLE_NOT_AWAITED"] = "IDLE_NOT_AWAITED";
  OperationLifecycleState2["IDLE_AWAITED"] = "IDLE_AWAITED";
  OperationLifecycleState2["COMPLETED"] = "COMPLETED";
})(OperationLifecycleState || (OperationLifecycleState = {}));
var PluginInvocationStatus = {
  SUCCEEDED: "SUCCEEDED",
  FAILED: "FAILED",
  PENDING: "PENDING",
  RETRYING: "RETRYING"
};
var PluginOperationStatus = {
  STARTED: "STARTED",
  READY: "READY",
  PENDING: "PENDING",
  SUCCEEDED: "SUCCEEDED",
  FAILED: "FAILED",
  TIMED_OUT: "TIMED_OUT",
  STOPPED: "STOPPED",
  CANCELLED: "CANCELLED"
};
var AttemptEndInfoOutcome = {
  SUCCEEDED: "SUCCEEDED",
  FAILED: "FAILED"
};
var DURABLE_INSTRUMENTATION_PLUGIN_REGISTRATION = /* @__PURE__ */ Symbol.for("aws.lambda.durable.instrumentation.plugin-registration");
function durationToSeconds(duration) {
  const days = "days" in duration ? duration.days ?? 0 : 0;
  const hours = "hours" in duration ? duration.hours ?? 0 : 0;
  const minutes = "minutes" in duration ? duration.minutes ?? 0 : 0;
  const seconds = "seconds" in duration ? duration.seconds ?? 0 : 0;
  return days * 24 * 60 * 60 + hours * 60 * 60 + minutes * 60 + seconds;
}
function terminateForUnrecoverableError(context, error, stepIdentifier) {
  context.terminationManager.terminate({
    reason: error.terminationReason,
    message: `Unrecoverable error in step ${stepIdentifier}: ${error.message}`,
    error
  });
  return new Promise(() => {
  });
}
var safeStringify = (data) => {
  try {
    const seen = /* @__PURE__ */ new WeakSet();
    return JSON.stringify(data, (key, value) => {
      if (typeof value === "object" && value !== null) {
        if (seen.has(value))
          return "[Circular]";
        seen.add(value);
        if (value instanceof Error) {
          return {
            ...value,
            name: value.name,
            message: value.message,
            stack: value.stack
          };
        }
      }
      return value;
    }, 2);
  } catch {
    return "[Unable to stringify]";
  }
};
var verbose = process.env.DURABLE_VERBOSE_MODE === "true";
var log = (emoji, message, data) => {
  if (!verbose) {
    return;
  }
  const resolved = typeof data === "function" ? data() : data;
  console.debug(`${emoji} ${message}`, resolved ? safeStringify(resolved) : "");
};
async function completeAfter(checkpoint, stepId, work, metadata) {
  checkpoint.markOperationState(stepId, OperationLifecycleState.EXECUTING, metadata ? { metadata } : void 0);
  try {
    return await work();
  } finally {
    checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
  }
}
var applyJitter$1 = (delay, strategy) => {
  switch (strategy) {
    case JitterStrategy.NONE:
      return delay;
    case JitterStrategy.FULL:
      return Math.random() * delay;
    case JitterStrategy.HALF:
      return delay / 2 + Math.random() * (delay / 2);
    default:
      return delay;
  }
};
var resolveRetryableErrors = (retryableErrors, retryableErrorTypes) => {
  const shouldUseDefaultErrors = retryableErrors === void 0 && retryableErrorTypes === void 0;
  return {
    retryableErrors: retryableErrors ?? (shouldUseDefaultErrors ? [/.*/] : []),
    retryableErrorTypes: retryableErrorTypes ?? []
  };
};
var isErrorRetryable = (error, retryableErrors, retryableErrorTypes) => {
  const isRetryableErrorMessage = retryableErrors.some((pattern) => {
    if (pattern instanceof RegExp) {
      return pattern.test(error.message);
    }
    return error.message.includes(pattern);
  });
  const isRetryableErrorType = retryableErrorTypes.some((ErrorType) => error instanceof ErrorType);
  return isRetryableErrorMessage || isRetryableErrorType;
};
var finalizeDelaySeconds = (baseDelaySeconds, jitter) => {
  const delayWithJitter = applyJitter$1(baseDelaySeconds, jitter);
  return Math.max(1, Math.round(delayWithJitter));
};
var DEFAULT_CONFIG$2 = {
  maxAttempts: 3,
  initialDelay: { seconds: 5 },
  maxDelay: { minutes: 5 },
  backoffRate: 2,
  jitter: JitterStrategy.FULL,
  retryableErrors: [/.*/],
  // By default, retry all errors
  retryableErrorTypes: []
};
var createRetryStrategy = (config = {}) => {
  const { retryableErrors, retryableErrorTypes } = resolveRetryableErrors(config.retryableErrors, config.retryableErrorTypes);
  const finalConfig = {
    ...DEFAULT_CONFIG$2,
    ...config,
    retryableErrors,
    retryableErrorTypes
  };
  return (error, attemptsMade) => {
    if (attemptsMade >= finalConfig.maxAttempts) {
      return { shouldRetry: false };
    }
    if (!isErrorRetryable(error, finalConfig.retryableErrors, finalConfig.retryableErrorTypes)) {
      return { shouldRetry: false };
    }
    const initialDelaySeconds = durationToSeconds(finalConfig.initialDelay);
    const maxDelaySeconds = durationToSeconds(finalConfig.maxDelay);
    const baseDelay = Math.min(initialDelaySeconds * finalConfig.backoffRate ** (attemptsMade - 1), maxDelaySeconds);
    const finalDelay = finalizeDelaySeconds(baseDelay, finalConfig.jitter);
    return { shouldRetry: true, delay: { seconds: finalDelay } };
  };
};
var DEFAULT_CONFIG$1 = {
  maxAttempts: 6,
  initialDelay: { seconds: 1 },
  increment: { seconds: 1 },
  maxDelay: { minutes: 5 },
  jitter: JitterStrategy.FULL,
  retryableErrors: [/.*/],
  // By default, retry all errors
  retryableErrorTypes: []
};
var createLinearRetryStrategy = (config = {}) => {
  const { retryableErrors, retryableErrorTypes } = resolveRetryableErrors(config.retryableErrors, config.retryableErrorTypes);
  const finalConfig = {
    ...DEFAULT_CONFIG$1,
    ...config,
    retryableErrors,
    retryableErrorTypes
  };
  return (error, attemptsMade) => {
    if (attemptsMade >= finalConfig.maxAttempts) {
      return { shouldRetry: false };
    }
    if (!isErrorRetryable(error, finalConfig.retryableErrors, finalConfig.retryableErrorTypes)) {
      return { shouldRetry: false };
    }
    const initialDelaySeconds = durationToSeconds(finalConfig.initialDelay);
    const incrementSeconds = durationToSeconds(finalConfig.increment);
    const maxDelaySeconds = durationToSeconds(finalConfig.maxDelay);
    const baseDelay = Math.min(initialDelaySeconds + incrementSeconds * (attemptsMade - 1), maxDelaySeconds);
    const finalDelay = finalizeDelaySeconds(baseDelay, finalConfig.jitter);
    return { shouldRetry: true, delay: { seconds: finalDelay } };
  };
};
var retryPresets = {
  /**
   * Default retry strategy with exponential backoff
   * - 6 total attempts (1 initial + 5 retries)
   * - Initial delay: 5 seconds
   * - Max delay: 60 seconds
   * - Backoff rate: 2x
   * - Jitter: FULL (randomizes delay between 0 and calculated delay)
   * - Total max wait time less than 150 seconds (2:30)
   */
  default: createRetryStrategy({
    maxAttempts: 6,
    initialDelay: { seconds: 5 },
    maxDelay: { seconds: 60 },
    backoffRate: 2,
    jitter: JitterStrategy.FULL
  }),
  /**
   * Linear retry strategy with fixed increment
   * - 6 total attempts (1 initial + 5 retries)
   * - Delays: 1s, 2s, 3s, 4s, 5s
   * - Jitter: NONE (deterministic delays)
   * - Total max wait time: 15 seconds
   */
  linear: createLinearRetryStrategy({
    maxAttempts: 6,
    initialDelay: { seconds: 1 },
    increment: { seconds: 1 },
    jitter: JitterStrategy.NONE
  }),
  /**
   * No retry strategy - fails immediately on first error
   * - 1 total attempt (no retries)
   */
  noRetry: createRetryStrategy({
    maxAttempts: 1
  })
};
var StepInterruptedError = class extends Error {
  constructor(_stepId, _stepName) {
    super(`The step execution process was initiated but failed to reach completion due to an interruption.`);
    this.name = "StepInterruptedError";
  }
};
var CHECKPOINT_TERMINATION_COOLDOWN_MS = 3;
var MAX_TIMER_DELAY_MS = 2 ** 31 - 1;
var MIN_REMAINING_TIME_TO_POLL_MS = 1e3;
var INITIAL_POLL_DELAY_MS = 1e3;
var POLL_INTERVAL_CEILING_MS = 1e4;
var EXTENDED_POLL_INTERVAL_CEILING_MS = 6e4;
var POLLS_BEFORE_EXTENDED_INTERVAL = 95;
var CHECKPOINT_SIZE_LIMIT_BYTES = 256 * 1024;
var DurableOperationError = class _DurableOperationError extends Error {
  cause;
  errorData;
  stackTrace;
  constructor(message, cause, errorData) {
    super(message);
    this.name = this.constructor.name;
    this.cause = cause;
    this.errorData = errorData;
  }
  /**
   * Create DurableOperationError from ErrorObject (for reconstruction during replay)
   */
  static fromErrorObject(errorObject) {
    const cause = new Error(errorObject.ErrorMessage);
    cause.name = errorObject.ErrorType || "Error";
    cause.stack = errorObject.StackTrace?.join("\n");
    switch (errorObject.ErrorType) {
      case "StepError":
        return new StepError(errorObject.ErrorMessage || "Step failed", cause, errorObject.ErrorData);
      case "CallbackError":
        return new CallbackError(errorObject.ErrorMessage || "Callback failed", cause, errorObject.ErrorData);
      case "CallbackExternalError":
        return new CallbackExternalError(errorObject.ErrorMessage || "Callback failed", cause, errorObject.ErrorData);
      case "CallbackTimeoutError":
        return new CallbackTimeoutError(errorObject.ErrorMessage || "Callback timed out", cause, errorObject.ErrorData);
      case "CallbackSubmitterError":
        return new CallbackSubmitterError(errorObject.ErrorMessage || "Callback submitter failed", cause, errorObject.ErrorData);
      case "InvokeError":
        return new InvokeError(errorObject.ErrorMessage || "Invoke failed", cause, errorObject.ErrorData);
      case "ChildContextError":
        return new ChildContextError(errorObject.ErrorMessage || "Child context failed", cause, errorObject.ErrorData);
      case "WaitForConditionError":
        return new WaitForConditionError(errorObject.ErrorMessage || "Wait for condition failed", cause, errorObject.ErrorData);
      case "PromiseCombinatorError":
        return new PromiseCombinatorError(errorObject.ErrorMessage || "Promise combinator failed", cause, errorObject.ErrorData);
      default:
        return new StepError(errorObject.ErrorMessage || "Unknown error", cause, errorObject.ErrorData);
    }
  }
  /**
   * Convert to ErrorObject for serialization.
   * When errorData is undefined, walks the cause chain to surface the first
   * errorData found — prevents loss across runInChildContext boundaries.
   */
  toErrorObject() {
    let errorData = this.errorData;
    if (errorData === void 0) {
      let node = this.cause;
      for (let i = 0; i < 10 && node; i++) {
        if (node instanceof _DurableOperationError && typeof node.errorData === "string") {
          errorData = node.errorData;
          break;
        }
        node = node instanceof Error ? node.cause : void 0;
      }
    }
    return {
      ErrorType: this.errorType,
      ErrorMessage: this.message,
      ErrorData: errorData,
      StackTrace: void 0
    };
  }
};
var StepError = class extends DurableOperationError {
  errorType = "StepError";
  constructor(message, cause, errorData) {
    super(message || "Step failed", cause, errorData);
  }
};
var CallbackError = class extends DurableOperationError {
  errorType = "CallbackError";
  constructor(message, cause, errorData) {
    super(message || "Callback failed", cause, errorData);
  }
};
var CallbackExternalError = class extends CallbackError {
  errorType = "CallbackExternalError";
  constructor(message, cause, errorData) {
    super(message || "Callback failed", cause, errorData);
  }
};
var CallbackTimeoutError = class extends CallbackError {
  errorType = "CallbackTimeoutError";
  constructor(message, cause, errorData) {
    super(message || "Callback timed out", cause, errorData);
  }
};
var CallbackSubmitterError = class extends CallbackError {
  errorType = "CallbackSubmitterError";
  constructor(message, cause, errorData) {
    super(message || "Callback submitter failed", cause, errorData);
  }
};
var InvokeError = class extends DurableOperationError {
  errorType = "InvokeError";
  constructor(message, cause, errorData) {
    super(message || "Invoke failed", cause, errorData);
  }
};
var ChildContextError = class extends DurableOperationError {
  errorType = "ChildContextError";
  constructor(message, cause, errorData) {
    super(message || "Child context failed", cause, errorData);
  }
};
var PromiseCombinatorError = class extends DurableOperationError {
  errorType = "PromiseCombinatorError";
  constructor(message, cause, errorData) {
    super(message || "Promise combinator failed", cause, errorData);
  }
};
var WaitForConditionError = class extends DurableOperationError {
  errorType = "WaitForConditionError";
  constructor(message, cause, errorData) {
    super(message || "Wait for condition failed", cause, errorData);
  }
};
var BatchCompletionError = class extends DurableOperationError {
  completionReason;
  errorType = "BatchCompletionError";
  constructor(completionReason, message, cause, errorData) {
    super(message || `Batch completed as failed by shouldComplete (${completionReason})`, cause, errorData);
    this.completionReason = completionReason;
  }
};
var defaultSerdes = {
  serialize: async (value, _context) => value !== void 0 ? JSON.stringify(value) : void 0,
  deserialize: async (data, _context) => data !== void 0 ? JSON.parse(data) : void 0
};
var TerminationReason;
(function(TerminationReason2) {
  TerminationReason2["OPERATION_TERMINATED"] = "OPERATION_TERMINATED";
  TerminationReason2["RETRY_SCHEDULED"] = "RETRY_SCHEDULED";
  TerminationReason2["RETRY_INTERRUPTED_STEP"] = "RETRY_INTERRUPTED_STEP";
  TerminationReason2["WAIT_SCHEDULED"] = "WAIT_SCHEDULED";
  TerminationReason2["CALLBACK_PENDING"] = "CALLBACK_PENDING";
  TerminationReason2["EXECUTION_SUSPENDED_BY_SERVICE"] = "EXECUTION_SUSPENDED_BY_SERVICE";
  TerminationReason2["CHECKPOINT_FAILED"] = "CHECKPOINT_FAILED";
  TerminationReason2["SERDES_FAILED"] = "SERDES_FAILED";
  TerminationReason2["CONTEXT_VALIDATION_ERROR"] = "CONTEXT_VALIDATION_ERROR";
  TerminationReason2["CONFIG_VALIDATION_ERROR"] = "CONFIG_VALIDATION_ERROR";
  TerminationReason2["NON_DETERMINISM"] = "NON_DETERMINISM";
  TerminationReason2["CUSTOM"] = "CUSTOM";
})(TerminationReason || (TerminationReason = {}));
var TERMINATION_CLASS = {
  [TerminationReason.OPERATION_TERMINATED]: "suspend",
  [TerminationReason.RETRY_SCHEDULED]: "suspend",
  [TerminationReason.RETRY_INTERRUPTED_STEP]: "suspend",
  [TerminationReason.WAIT_SCHEDULED]: "suspend",
  [TerminationReason.CALLBACK_PENDING]: "suspend",
  // A withdrawn checkpoint token says this invocation can record nothing further. It does
  // not say the execution cannot continue, which is what a fault would claim, so this is a
  // suspend like any other: the invocation answers PENDING and stops.
  //
  // A suspend leaves it to the service to invoke again, and the SDK cannot see whether
  // anything will. Both answers are still accounted for. Where the token was withdrawn
  // because a newer invocation took over -- the case this exists for -- that invocation is
  // already driving the execution, and only a suspend lets it carry on. Where nothing at all
  // is outstanding, the service rejects a PENDING response with "Cannot return PENDING
  // status with no pending operations" and the execution fails after its deterministic
  // retries, which is where a fault would have left it anyway. So the suspend is right when
  // it matters and costs nothing when it is not.
  [TerminationReason.EXECUTION_SUSPENDED_BY_SERVICE]: "suspend",
  [TerminationReason.CHECKPOINT_FAILED]: "fault",
  [TerminationReason.SERDES_FAILED]: "fault",
  [TerminationReason.CONTEXT_VALIDATION_ERROR]: "fault",
  [TerminationReason.CONFIG_VALIDATION_ERROR]: "fault",
  [TerminationReason.NON_DETERMINISM]: "fault",
  // Deliberately unclassified in meaning: CUSTOM says nothing about whether the execution
  // can continue, so it is treated as a fault. Reporting a fault that was really a suspend
  // costs one failed execution; the reverse asks the service to retry something that can
  // never progress, and hides the error while doing so.
  [TerminationReason.CUSTOM]: "fault"
};
var classifyTermination = (reason) => TERMINATION_CLASS[reason] ?? "fault";
var UnrecoverableError = class extends Error {
  originalError;
  isUnrecoverable = true;
  constructor(message, originalError) {
    super(message);
    this.originalError = originalError;
    this.name = this.constructor.name;
    if (originalError?.stack) {
      this.stack = `${this.stack}
Caused by: ${originalError.stack}`;
    }
  }
};
var UnrecoverableExecutionError = class extends UnrecoverableError {
  isUnrecoverableExecution = true;
  constructor(message, originalError) {
    super(`[Unrecoverable Execution] ${message}`, originalError);
  }
};
var UnrecoverableInvocationError = class extends UnrecoverableError {
  isUnrecoverableInvocation = true;
  constructor(message, originalError) {
    super(`[Unrecoverable Invocation] ${message}`, originalError);
  }
};
function isUnrecoverableError(error) {
  return error instanceof Error && "isUnrecoverable" in error && error.isUnrecoverable === true;
}
function isUnrecoverableInvocationError(error) {
  return error instanceof Error && "isUnrecoverableInvocation" in error && error.isUnrecoverableInvocation === true;
}
var SerdesFailedError = class extends UnrecoverableInvocationError {
  terminationReason = TerminationReason.SERDES_FAILED;
  constructor(message, originalError) {
    super(message || "Serdes operation failed", originalError);
  }
};
async function safeSerialize(serdes, value, stepId, stepName, terminationManager, durableExecutionArn) {
  try {
    const context = {
      entityId: stepId,
      durableExecutionArn
    };
    return await serdes.serialize(value, context);
  } catch (error) {
    const message = `Serialization failed for step ${stepName ? `"${stepName}" ` : ""}(${stepId}): ${error instanceof Error ? error.message : "Unknown serialization error"}`;
    log("\u{1F4A5}", "Serialization failed - terminating execution:", {
      stepId,
      stepName,
      error: error instanceof Error ? error.message : String(error)
    });
    terminationManager.terminate({
      reason: TerminationReason.SERDES_FAILED,
      message
    });
    return new Promise(() => {
    });
  }
}
async function safeDeserialize(serdes, data, stepId, stepName, terminationManager, durableExecutionArn) {
  try {
    const context = {
      entityId: stepId,
      durableExecutionArn
    };
    return await serdes.deserialize(data, context);
  } catch (error) {
    const message = `Deserialization failed for step ${stepName ? `"${stepName}" ` : ""}(${stepId}): ${error instanceof Error ? error.message : "Unknown deserialization error"}`;
    log("\u{1F4A5}", "Deserialization failed - terminating execution:", {
      stepId,
      stepName,
      error: error instanceof Error ? error.message : String(error)
    });
    terminationManager.terminate({
      reason: TerminationReason.SERDES_FAILED,
      message
    });
    return new Promise(() => {
    });
  }
}
var RuntimeAsyncLocalStorage = asyncHooks.AsyncLocalStorage;
var SynchronousContextStorage = class {
  store = void 0;
  run(store, fn) {
    const previous = this.store;
    this.store = store;
    try {
      return fn();
    } finally {
      this.store = previous;
    }
  }
  getStore() {
    return this.store;
  }
};
var createContextStorage = () => RuntimeAsyncLocalStorage ? new RuntimeAsyncLocalStorage() : new SynchronousContextStorage();
var isContextStorageDegraded = () => !RuntimeAsyncLocalStorage;
var degradationWarningEmitted = false;
var warnOnceIfContextStorageIsDegraded = (logger) => {
  if (!isContextStorageDegraded() || degradationWarningEmitted) {
    return;
  }
  degradationWarningEmitted = true;
  logger.warn("This runtime does not provide AsyncLocalStorage, so the SDK cannot track which durable operation is active across await boundaries. Checkpointing and replay are unaffected. Degraded: log records emitted after an await lose operationId, operationName and attempt; replayed log records are no longer suppressed; and using a parent or sibling context inside runInChildContext is only detected when it happens synchronously. Enable the no-nested-durable-operations rule from @aws/durable-execution-sdk-js-eslint-plugin to catch the remaining cases at build time.");
};
var asyncLocalStorage = createContextStorage();
var getActiveContext = () => {
  return asyncLocalStorage.getStore();
};
var runWithContext = (contextId, parentId, fn, attempt, durableExecutionMode, operationName) => {
  return asyncLocalStorage.run({
    contextId,
    parentId,
    attempt,
    durableExecutionMode,
    operationName,
    execution: asyncLocalStorage.getStore()?.execution
  }, fn);
};
var runWithRootContext = (execution, fn) => {
  return asyncLocalStorage.run({ contextId: "root", execution }, fn);
};
var validateContextUsage = (operationContextId, operationName, terminationManager) => {
  const contextId = operationContextId || "root";
  const activeContext = getActiveContext();
  if (!activeContext) {
    return;
  }
  if (activeContext.contextId !== contextId) {
    const errorMessage2 = `Context usage error in "${operationName}": You are using a parent or sibling context instead of the current child context. Expected context ID: "${activeContext.contextId}", but got: "${operationContextId}". When inside runInChildContext(), you must use the child context parameter, not the parent context.`;
    terminationManager.terminate({
      reason: TerminationReason.CONTEXT_VALIDATION_ERROR,
      message: errorMessage2,
      error: new Error(errorMessage2)
    });
  }
};
function isErrorLike(obj) {
  return obj instanceof Error || obj != null && typeof obj === "object" && "message" in obj && "name" in obj;
}
function createErrorObjectFromError(error, data) {
  if (error instanceof DurableOperationError) {
    const errorObject = error.toErrorObject();
    return errorObject;
  }
  if (isErrorLike(error)) {
    return {
      ErrorData: data,
      ErrorMessage: error.message,
      ErrorType: error.name,
      StackTrace: void 0
    };
  }
  return {
    ErrorData: data,
    ErrorMessage: "Unknown error"
  };
}
var NonDeterministicExecutionError = class extends UnrecoverableExecutionError {
  terminationReason = TerminationReason.NON_DETERMINISM;
  constructor(message) {
    super(message);
    this.name = "NonDeterministicExecutionError";
  }
};
var validateReplayConsistency = (stepId, currentOperation, checkpointData, context) => {
  if (!checkpointData || !checkpointData.Type) {
    return;
  }
  if (checkpointData.Type !== currentOperation.type) {
    const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation type mismatch for step "${stepId}". Expected type "${checkpointData.Type}", but got "${currentOperation.type}". This indicates non-deterministic control flow in your workflow code.`);
    terminateForUnrecoverableError(context, error, stepId);
  }
  if (checkpointData.Name !== currentOperation.name) {
    const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation name mismatch for step "${stepId}". Expected name "${checkpointData.Name ?? "undefined"}", but got "${currentOperation.name ?? "undefined"}". This indicates non-deterministic control flow in your workflow code.`);
    terminateForUnrecoverableError(context, error, stepId);
  }
  if (checkpointData.SubType !== currentOperation.subType) {
    const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation subtype mismatch for step "${stepId}". Expected subtype "${checkpointData.SubType}", but got "${currentOperation.subType}". This indicates non-deterministic control flow in your workflow code.`);
    terminateForUnrecoverableError(context, error, stepId);
  }
};
function toOperationInfo(operation) {
  const errorObject = operation?.StepDetails?.Error ?? operation?.CallbackDetails?.Error ?? operation?.ContextDetails?.Error ?? operation?.ChainedInvokeDetails?.Error;
  return {
    id: operation?.Id ?? "",
    name: operation?.Name,
    type: operation?.Type ?? "",
    subType: operation?.SubType,
    parentId: operation?.ParentId,
    status: operation?.Status,
    startTimestamp: operation?.StartTimestamp,
    endTimestamp: operation?.EndTimestamp,
    result: operation?.StepDetails?.Result ?? operation?.CallbackDetails?.Result ?? operation?.ContextDetails?.Result ?? operation?.ChainedInvokeDetails?.Result,
    // An undefined field supplies no diagnostic detail, regardless of its name.
    // Defined values retain the existing converter behavior; this does not
    // add support for exposing arbitrary unknown fields on the resulting Error.
    error: errorObject && Object.values(errorObject).some((value) => value !== void 0) ? DurableOperationError.fromErrorObject(errorObject) : void 0,
    attempt: operation?.StepDetails?.Attempt,
    isReplay: false
  };
}
function toOperationInfoMap(operations) {
  const result = {};
  for (const [key, op] of Object.entries(operations)) {
    result[key] = toOperationInfo(op);
  }
  return result;
}
function toAttemptInfo(operation, attempt) {
  return {
    ...toOperationInfo(operation),
    attempt: attempt ?? (operation?.StepDetails?.Attempt || 0)
  };
}
function toAttemptEndInfo(operation, outcome, options) {
  return {
    ...toAttemptInfo(operation, options?.attempt),
    outcome,
    error: options?.error
  };
}
function backfillOperationInfo(info, defaults) {
  if (!info.id)
    info.id = defaults.id ?? "";
  if (!info.type)
    info.type = defaults.type ?? "";
  if (!info.subType)
    info.subType = defaults.subType;
  if (!info.name)
    info.name = defaults.name;
  if (!info.parentId)
    info.parentId = defaults.parentId;
  if (!info.startTimestamp)
    info.startTimestamp = defaults.startTimestamp;
  if (!info.endTimestamp)
    info.endTimestamp = defaults.endTimestamp;
  return info;
}
var HASH_LENGTH = 16;
var MAX_HASH_CACHE_SIZE = 1e4;
var hashCache = /* @__PURE__ */ new Map();
var hashId = (input) => {
  let hash = hashCache.get(input);
  if (hash === void 0) {
    hash = (0, import_crypto.createHash)("md5").update(input).digest("hex").substring(0, HASH_LENGTH);
    if (hashCache.size >= MAX_HASH_CACHE_SIZE) {
      hashCache.clear();
    }
    hashCache.set(input, hash);
  }
  return hash;
};
var getStepData = (stepData, stepId) => {
  const hashedId = hashId(stepId);
  return stepData[hashedId];
};
var createStepHandler = (context, checkpoint, parentContext, createStepId, logger, parentId, getDefaultSerdes, plugin = {}, pluginOperationName) => {
  return (nameOrFn, fnOrOptions, maybeOptions) => {
    let name;
    let fn;
    let options;
    if (typeof nameOrFn === "string" || nameOrFn === void 0) {
      name = nameOrFn;
      fn = fnOrOptions;
      options = maybeOptions;
    } else {
      fn = nameOrFn;
      options = fnOrOptions;
    }
    const stepId = createStepId();
    const semantics = options?.semantics || StepSemantics.AtLeastOncePerRetry;
    const subType = options?.subType || OperationSubType.STEP;
    const serdes = options?.serdes || (getDefaultSerdes ? getDefaultSerdes() : defaultSerdes);
    const phase1Promise = (async () => {
      let stepData = context.getStepData(stepId);
      validateReplayConsistency(stepId, { type: OperationType.STEP, name, subType }, stepData, context);
      const opInfo = {
        id: hashId(stepId),
        name: pluginOperationName ?? name,
        type: OperationType.STEP,
        subType,
        parentId: parentId ? hashId(parentId) : void 0
      };
      if (stepData?.Status === OperationStatus.SUCCEEDED) {
        log("\u23ED\uFE0F", "Step already completed:", { stepId });
        const result = stepData.StepDetails?.Result;
        return await completeAfter(checkpoint, stepId, () => safeDeserialize(serdes, result, stepId, name, context.terminationManager, context.durableExecutionArn), { stepId, name, type: OperationType.STEP, subType, parentId });
      }
      if (stepData?.Status === OperationStatus.FAILED) {
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
          metadata: {
            stepId,
            name,
            type: OperationType.STEP,
            subType,
            parentId
          }
        });
        if (stepData.StepDetails?.Error) {
          throw DurableOperationError.fromErrorObject(stepData.StepDetails.Error);
        }
        throw new StepError("Unknown error");
      }
      if (stepData?.Status === OperationStatus.PENDING) {
        checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
          metadata: {
            stepId,
            name,
            type: OperationType.STEP,
            subType,
            parentId
          },
          endTimestamp: stepData.StepDetails?.NextAttemptTimestamp
        });
        return (async () => {
          await checkpoint.waitForRetryTimer(stepId);
          stepData = context.getStepData(stepId);
          return await executeStepLogic();
        })();
      }
      if (stepData?.Status === OperationStatus.STARTED && semantics === StepSemantics.AtMostOncePerRetry) {
        const error = new StepInterruptedError(stepId, name);
        const currentAttempt = (stepData.StepDetails?.Attempt || 0) + 1;
        const retryDecision = options?.retryStrategy?.(error, currentAttempt) ?? retryPresets.default(error, currentAttempt);
        if (!retryDecision.shouldRetry) {
          await checkpoint.checkpoint(stepId, {
            Id: stepId,
            ParentId: parentId,
            Action: OperationAction.FAIL,
            SubType: subType,
            Type: OperationType.STEP,
            Error: createErrorObjectFromError(error),
            Name: name
          });
          checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
            metadata: {
              stepId,
              name,
              type: OperationType.STEP,
              subType,
              parentId
            }
          });
          throw DurableOperationError.fromErrorObject(createErrorObjectFromError(error));
        }
        await checkpoint.checkpoint(stepId, {
          Id: stepId,
          ParentId: parentId,
          Action: OperationAction.RETRY,
          SubType: subType,
          Type: OperationType.STEP,
          Error: createErrorObjectFromError(error),
          Name: name,
          StepOptions: {
            NextAttemptDelaySeconds: retryDecision.delay ? durationToSeconds(retryDecision.delay) : 1
          }
        });
        checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
          metadata: {
            stepId,
            name,
            type: OperationType.STEP,
            subType,
            parentId
          },
          endTimestamp: context.getStepData(stepId)?.StepDetails?.NextAttemptTimestamp
        });
        return (async () => {
          await checkpoint.waitForRetryTimer(stepId);
          stepData = context.getStepData(stepId);
          return await executeStepLogic();
        })();
      }
      return await executeStepLogic();
      async function executeStepLogic() {
        stepData = context.getStepData(stepId);
        if (stepData?.Status !== OperationStatus.STARTED) {
          if (semantics === StepSemantics.AtMostOncePerRetry) {
            await checkpoint.checkpoint(stepId, {
              Id: stepId,
              ParentId: parentId,
              Action: OperationAction.START,
              SubType: subType,
              Type: OperationType.STEP,
              Name: name
            });
            stepData = context.getStepData(stepId);
            const operationInfo = toOperationInfo(stepData);
            backfillOperationInfo(operationInfo, opInfo);
            const isRetryAttempt = (stepData?.StepDetails?.Attempt || 0) >= 1;
            await plugin.onOperationStart?.({
              ...operationInfo,
              isReplay: isRetryAttempt
            });
          } else {
            const isRetryAttempt = (stepData?.StepDetails?.Attempt || 0) >= 1;
            checkpoint.checkpoint(stepId, {
              Id: stepId,
              ParentId: parentId,
              Action: OperationAction.START,
              SubType: subType,
              Type: OperationType.STEP,
              Name: name
            });
            const operationInfo = toOperationInfo(stepData);
            backfillOperationInfo(operationInfo, opInfo);
            await plugin.onOperationStart?.({
              ...opInfo,
              status: PluginOperationStatus.STARTED,
              isReplay: isRetryAttempt
            });
          }
        } else {
          const operationInfo = toOperationInfo(stepData);
          backfillOperationInfo(operationInfo, opInfo);
          await plugin.onOperationStart?.({ ...operationInfo, isReplay: true });
        }
        try {
          stepData = context.getStepData(stepId);
          const currentAttempt = (stepData?.StepDetails?.Attempt || 0) + 1;
          const stepContext = {
            logger,
            attempt: currentAttempt
          };
          checkpoint.markOperationState(stepId, OperationLifecycleState.EXECUTING, {
            metadata: {
              stepId,
              name,
              type: OperationType.STEP,
              subType,
              parentId
            }
          });
          const attemptInfo = toAttemptInfo(stepData, currentAttempt);
          backfillOperationInfo(attemptInfo, opInfo);
          attemptInfo.startTimestamp = /* @__PURE__ */ new Date();
          await plugin.onOperationAttemptStart?.(attemptInfo);
          let result;
          const stepFn = () => fn(stepContext);
          result = await runWithContext(stepId, parentId, plugin.wrapOperationAttemptFn ? () => plugin.wrapOperationAttemptFn(attemptInfo, stepFn) : stepFn, currentAttempt, DurableExecutionMode.ExecutionMode, name);
          const serializedResult = await safeSerialize(serdes, result, stepId, name, context.terminationManager, context.durableExecutionArn);
          await checkpoint.checkpoint(stepId, {
            Id: stepId,
            ParentId: parentId,
            Action: OperationAction.SUCCEED,
            SubType: subType,
            Type: OperationType.STEP,
            Payload: serializedResult,
            Name: name
          });
          stepData = context.getStepData(stepId);
          const attemptEndInfo = toAttemptEndInfo(stepData, AttemptEndInfoOutcome.SUCCEEDED, {
            attempt: currentAttempt
          });
          backfillOperationInfo(attemptEndInfo, opInfo);
          await plugin.onOperationAttemptEnd?.(attemptEndInfo);
          await plugin.onOperationEnd?.({ ...attemptEndInfo, isReplay: false });
          return await completeAfter(checkpoint, stepId, () => safeDeserialize(serdes, serializedResult, stepId, name, context.terminationManager, context.durableExecutionArn));
        } catch (error) {
          if (isUnrecoverableError(error)) {
            return terminateForUnrecoverableError(context, error, name || stepId);
          }
          stepData = context.getStepData(stepId);
          const currentAttempt = (stepData?.StepDetails?.Attempt || 0) + 1;
          const retryDecision = options?.retryStrategy?.(error instanceof Error ? error : new Error("Unknown Error"), currentAttempt) ?? retryPresets.default(error instanceof Error ? error : new Error("Unknown Error"), currentAttempt);
          if (!retryDecision.shouldRetry) {
            await checkpoint.checkpoint(stepId, {
              Id: stepId,
              ParentId: parentId,
              Action: OperationAction.FAIL,
              SubType: subType,
              Type: OperationType.STEP,
              Error: createErrorObjectFromError(error),
              Name: name
            });
            checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
            stepData = context.getStepData(stepId);
            const attemptEndInfo2 = toAttemptEndInfo(stepData, AttemptEndInfoOutcome.FAILED, {
              attempt: currentAttempt,
              error: error instanceof Error ? error : new Error(String(error))
            });
            backfillOperationInfo(attemptEndInfo2, opInfo);
            await plugin.onOperationAttemptEnd?.(attemptEndInfo2);
            await plugin.onOperationEnd?.({
              ...attemptEndInfo2,
              isReplay: false,
              error: error instanceof Error ? error : new Error(String(error))
            });
            throw DurableOperationError.fromErrorObject(createErrorObjectFromError(error));
          }
          const nextAttemptDelaySeconds = retryDecision.delay ? durationToSeconds(retryDecision.delay) : 1;
          await checkpoint.checkpoint(stepId, {
            Id: stepId,
            ParentId: parentId,
            Action: OperationAction.RETRY,
            SubType: subType,
            Type: OperationType.STEP,
            Error: createErrorObjectFromError(error),
            Name: name,
            StepOptions: {
              NextAttemptDelaySeconds: nextAttemptDelaySeconds
            }
          });
          stepData = context.getStepData(stepId);
          const attemptEndInfo = toAttemptEndInfo(stepData, AttemptEndInfoOutcome.FAILED, {
            attempt: currentAttempt,
            error: error instanceof Error ? error : new Error(String(error))
          });
          backfillOperationInfo(attemptEndInfo, opInfo);
          await plugin.onOperationAttemptEnd?.(attemptEndInfo);
          checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
            metadata: {
              stepId,
              name,
              type: OperationType.STEP,
              subType,
              parentId
            },
            endTimestamp: context.getStepData(stepId)?.StepDetails?.NextAttemptTimestamp
          });
          await checkpoint.waitForRetryTimer(stepId);
          return await executeStepLogic();
        }
      }
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      checkpoint.markOperationAwaited(stepId);
      return await phase1Promise;
    });
  };
};
function toInvokeError(error) {
  if (!error)
    return new InvokeError("Invoke failed");
  let cause;
  if (error.ErrorMessage || error.ErrorType) {
    cause = new Error(error.ErrorMessage);
    cause.name = error.ErrorType || "Error";
    cause.stack = error.StackTrace?.join("\n");
  }
  return new InvokeError(error.ErrorMessage || "Invoke failed", cause, error.ErrorData);
}
var createInvokeHandler = (context, checkpoint, createStepId, parentId, checkAndUpdateReplayMode, getDefaultSerdes, plugin = {}) => {
  function invokeHandler(nameOrFuncId, funcIdOrInput, inputOrConfig, maybeConfig) {
    const isNameFirst = typeof funcIdOrInput === "string";
    const name = isNameFirst ? nameOrFuncId : void 0;
    const funcId = isNameFirst ? funcIdOrInput : nameOrFuncId;
    const input = isNameFirst ? inputOrConfig : funcIdOrInput;
    const config = isNameFirst ? maybeConfig : inputOrConfig;
    const stepId = createStepId();
    const opInfo = {
      id: hashId(stepId),
      name,
      type: OperationType.CHAINED_INVOKE,
      subType: OperationSubType.CHAINED_INVOKE,
      parentId: parentId ? hashId(parentId) : void 0
    };
    let isCompleted = false;
    const phase1Promise = (async () => {
      log("\u{1F517}", "Invoke phase 1:", { stepId, name: name || funcId });
      let stepData = context.getStepData(stepId);
      validateReplayConsistency(stepId, {
        type: OperationType.CHAINED_INVOKE,
        name,
        subType: OperationSubType.CHAINED_INVOKE
      }, stepData, context);
      if (stepData?.Status === OperationStatus.SUCCEEDED) {
        log("\u23ED\uFE0F", "Invoke already completed:", { stepId });
        checkAndUpdateReplayMode?.();
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
          metadata: {
            stepId,
            name,
            type: OperationType.CHAINED_INVOKE,
            subType: OperationSubType.CHAINED_INVOKE,
            parentId
          }
        });
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        const isUpdatedBetweenInvocation = context.isOperationUpdatedBetweenInvocation(opInfo.id);
        await plugin.onOperationEnd?.({
          ...operationInfo,
          isReplay: !isUpdatedBetweenInvocation
        });
        isCompleted = true;
        return;
      }
      if (stepData?.Status === OperationStatus.FAILED || stepData?.Status === OperationStatus.TIMED_OUT || stepData?.Status === OperationStatus.STOPPED) {
        log("\u274C", "Invoke already failed:", { stepId });
        checkAndUpdateReplayMode?.();
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
          metadata: {
            stepId,
            name,
            type: OperationType.CHAINED_INVOKE,
            subType: OperationSubType.CHAINED_INVOKE,
            parentId
          }
        });
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        const isUpdatedBetweenInvocation = context.isOperationUpdatedBetweenInvocation(opInfo.id);
        await plugin.onOperationEnd?.({
          ...operationInfo,
          isReplay: !isUpdatedBetweenInvocation
        });
        isCompleted = true;
        return;
      }
      if (!stepData) {
        const serializedPayload = await safeSerialize(config?.payloadSerdes || (getDefaultSerdes ? getDefaultSerdes() : defaultSerdes), input, stepId, name, context.terminationManager, context.durableExecutionArn);
        const metadata = plugin.providePropagationMetadata?.({
          executionArn: context.durableExecutionArn,
          operationId: opInfo.id,
          parentOperationId: opInfo.parentId,
          targetFunctionName: funcId
        });
        await checkpoint.checkpoint(stepId, {
          Id: stepId,
          ParentId: parentId,
          Action: OperationAction.START,
          SubType: OperationSubType.CHAINED_INVOKE,
          Type: OperationType.CHAINED_INVOKE,
          Name: name,
          Payload: serializedPayload,
          ChainedInvokeOptions: {
            FunctionName: funcId,
            ...config?.tenantId && { TenantId: config.tenantId },
            ...metadata?.xAmznTraceId !== void 0 && {
              XAmznTraceId: metadata.xAmznTraceId
            }
          }
        });
        stepData = context.getStepData(stepId);
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        await plugin.onOperationStart?.({ ...operationInfo, isReplay: false });
      } else {
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        await plugin.onOperationStart?.({ ...operationInfo, isReplay: true });
      }
      checkpoint.markOperationState(stepId, OperationLifecycleState.IDLE_NOT_AWAITED, {
        metadata: {
          stepId,
          name,
          type: OperationType.CHAINED_INVOKE,
          subType: OperationSubType.CHAINED_INVOKE,
          parentId
        }
      });
      log("\u2705", "Invoke phase 1 complete:", { stepId });
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      await phase1Promise;
      if (isCompleted) {
        const stepData2 = context.getStepData(stepId);
        if (stepData2?.Status === OperationStatus.SUCCEEDED) {
          const invokeDetails = stepData2.ChainedInvokeDetails;
          return await completeAfter(checkpoint, stepId, () => safeDeserialize(config?.resultSerdes || (getDefaultSerdes ? getDefaultSerdes() : defaultSerdes), invokeDetails?.Result, stepId, name, context.terminationManager, context.durableExecutionArn));
        }
        throw toInvokeError(stepData2?.ChainedInvokeDetails?.Error);
      }
      log("\u{1F517}", "Invoke phase 2:", { stepId });
      checkpoint.markOperationAwaited(stepId);
      await checkpoint.waitForStatusChange(stepId);
      const stepData = context.getStepData(stepId);
      if (stepData?.Status === OperationStatus.SUCCEEDED) {
        log("\u2705", "Invoke completed:", { stepId });
        checkAndUpdateReplayMode?.();
        return await completeAfter(checkpoint, stepId, async () => {
          const operationInfo2 = toOperationInfo(stepData);
          backfillOperationInfo(operationInfo2, opInfo);
          await plugin.onOperationEnd?.({ ...operationInfo2, isReplay: false });
          const invokeDetails = stepData.ChainedInvokeDetails;
          return await safeDeserialize(config?.resultSerdes || (getDefaultSerdes ? getDefaultSerdes() : defaultSerdes), invokeDetails?.Result, stepId, name, context.terminationManager, context.durableExecutionArn);
        });
      }
      log("\u274C", "Invoke failed:", { stepId, status: stepData?.Status });
      checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
      const invokeError = stepData?.ChainedInvokeDetails?.Error;
      const operationInfo = toOperationInfo(stepData);
      backfillOperationInfo(operationInfo, opInfo);
      await plugin.onOperationEnd?.({
        ...operationInfo,
        isReplay: false
      });
      throw toInvokeError(invokeError);
    });
  }
  return invokeHandler;
};
function resolveChildArgs(nameOrFn, fnOrOptions, maybeOptions) {
  if (typeof nameOrFn === "string" || nameOrFn === void 0) {
    return {
      name: nameOrFn,
      fn: fnOrOptions,
      options: maybeOptions
    };
  }
  return {
    name: void 0,
    fn: nameOrFn,
    options: fnOrOptions
  };
}
var determineChildReplayMode = (context, stepId) => {
  const stepData = context.getStepData(stepId);
  if (!stepData) {
    return DurableExecutionMode.ExecutionMode;
  }
  if (stepData.Status === OperationStatus.SUCCEEDED && stepData.ContextDetails?.ReplayChildren) {
    return DurableExecutionMode.ReplaySucceededContext;
  }
  if (stepData.Status === OperationStatus.SUCCEEDED || stepData.Status === OperationStatus.FAILED) {
    return DurableExecutionMode.ReplayMode;
  }
  return DurableExecutionMode.ExecutionMode;
};
var createRunInChildContextHandler = (context, checkpoint, parentContext, createStepId, getParentLogger, createChildContext, parentId, getDefaultSerdes, plugin = {}, childPreserveDepth = 0) => {
  return (nameOrFn, fnOrOptions, maybeOptions) => {
    const { name, fn, options } = resolveChildArgs(nameOrFn, fnOrOptions, maybeOptions);
    const entityId = createStepId();
    log("\u{1F504}", "Running child context:", {
      entityId,
      name
    });
    const stepData = context.getStepData(entityId);
    validateReplayConsistency(entityId, {
      type: OperationType.CONTEXT,
      name,
      subType: options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT
    }, stepData, context);
    let phase1Result;
    let phase1Error;
    const phase1Promise = (async () => {
      const currentStepData = context.getStepData(entityId);
      if (currentStepData?.Status === OperationStatus.SUCCEEDED || currentStepData?.Status === OperationStatus.FAILED) {
        checkpoint.markAncestorFinished(entityId);
        return handleCompletedChildContext(context, checkpoint, parentContext, entityId, name, fn, options, getParentLogger, createChildContext, getDefaultSerdes, parentId);
      }
      return executeChildContext(context, checkpoint, parentContext, entityId, name, fn, options, getParentLogger, createChildContext, parentId, getDefaultSerdes, plugin, childPreserveDepth);
    })().then((result) => {
      phase1Result = result;
    }).catch((error) => {
      phase1Error = error;
    });
    return new DurablePromise(async () => {
      await phase1Promise;
      if (phase1Error !== void 0) {
        throw phase1Error;
      }
      return phase1Result;
    });
  };
};
var handleCompletedChildContext = async (context, checkpoint, parentContext, entityId, stepName, fn, options, getParentLogger, createChildContext, getDefaultSerdes, parentId) => {
  const serdes = options?.serdes || (getDefaultSerdes ? getDefaultSerdes() : defaultSerdes);
  const errorMapper = options?.errorMapper;
  const stepData = context.getStepData(entityId);
  const result = stepData?.ContextDetails?.Result;
  const whileExecuting = (work) => completeAfter(checkpoint, entityId, work, {
    stepId: entityId,
    name: stepName,
    type: OperationType.CONTEXT,
    subType: options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT,
    parentId
  });
  if (stepData?.Status === OperationStatus.FAILED) {
    if (stepData.ContextDetails?.Error) {
      const originalError = DurableOperationError.fromErrorObject(stepData.ContextDetails.Error);
      if (errorMapper) {
        throw errorMapper(originalError);
      }
      throw new ChildContextError(originalError.message, originalError);
    } else {
      throw new ChildContextError("Child context failed");
    }
  }
  if (stepData?.ContextDetails?.ReplayChildren) {
    log("\u{1F504}", "ReplayChildren mode: Re-executing child context due to large payload:", { entityId, stepName });
    const durableChildContext = createChildContext(context, parentContext, DurableExecutionMode.ReplaySucceededContext, getParentLogger(), entityId, void 0, entityId);
    const replayedResult = await runWithContext(entityId, entityId, () => fn(durableChildContext), void 0, void 0, stepName);
    return await whileExecuting(async () => {
      const reserialized = await safeSerialize(serdes, replayedResult, entityId, stepName, context.terminationManager, context.durableExecutionArn);
      return await safeDeserialize(serdes, reserialized, entityId, stepName, context.terminationManager, context.durableExecutionArn);
    });
  }
  log("\u23ED\uFE0F", "Child context already finished, returning cached result:", {
    entityId
  });
  return await whileExecuting(() => safeDeserialize(serdes, result, entityId, stepName, context.terminationManager, context.durableExecutionArn));
};
var executeChildContext = async (context, checkpoint, parentContext, entityId, name, fn, options, getParentLogger, createChildContext, parentId, getDefaultSerdes, plugin = {}, preserveChildDepth = 0) => {
  const serdes = options?.serdes || (getDefaultSerdes ? getDefaultSerdes() : defaultSerdes);
  const errorMapper = options?.errorMapper;
  const isVirtual = options?.virtualContext === true;
  const opInfo = {
    id: hashId(entityId),
    name,
    type: OperationType.CONTEXT,
    subType: options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT,
    parentId: parentId ? hashId(parentId) : void 0
  };
  if (!isVirtual && context.getStepData(entityId) === void 0) {
    const subType = options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT;
    checkpoint.checkpoint(entityId, {
      Id: entityId,
      ParentId: parentId,
      Action: OperationAction.START,
      SubType: subType,
      Type: OperationType.CONTEXT,
      Name: name
    });
    await plugin.onOperationStart?.({
      ...opInfo,
      status: PluginOperationStatus.STARTED,
      isReplay: false
    });
  } else {
    await plugin.onOperationStart?.({ ...opInfo, isReplay: true });
  }
  const childReplayMode = determineChildReplayMode(context, entityId);
  const durableChildContext = createChildContext(
    context,
    parentContext,
    childReplayMode,
    getParentLogger(),
    entityId,
    // stepPrefix: use entityId for unique step IDs
    void 0,
    // parentId: this parameter is used for checkpointing, and should point to
    // valid parentId tthat is already checkpointed.
    // If this runInChildContext is a virtual, then we will use the parentId  (the ancestor)
    // But if this runInChildContext is not virtual, then it's entityId can be used
    isVirtual ? parentId : entityId
  );
  let markedExecuting = false;
  const markExecuting = () => {
    if (markedExecuting)
      return;
    checkpoint.markOperationState(entityId, OperationLifecycleState.EXECUTING, {
      metadata: {
        stepId: entityId,
        name,
        type: OperationType.CONTEXT,
        subType: opInfo.subType,
        parentId
      }
    });
    markedExecuting = true;
  };
  try {
    const childContextFn = () => {
      let settled;
      try {
        settled = fn(durableChildContext);
      } catch (error) {
        markExecuting();
        throw error;
      }
      void Promise.resolve(settled).then(markExecuting, markExecuting);
      return settled;
    };
    const wrapInfo = {
      ...opInfo,
      isReplay: childReplayMode !== DurableExecutionMode.ExecutionMode
    };
    const result = await runWithContext(entityId, parentId, plugin.wrapChildContextFn ? () => plugin.wrapChildContextFn(wrapInfo, childContextFn) : childContextFn, void 0, childReplayMode, name);
    markExecuting();
    if (!isVirtual) {
      checkpoint.markAncestorFinished(entityId);
    }
    const serializedResult = await safeSerialize(serdes, result, entityId, name, context.terminationManager, context.durableExecutionArn);
    let payloadToCheckpoint = serializedResult;
    let replayChildren = false;
    if (serializedResult && Buffer.byteLength(serializedResult, "utf8") > CHECKPOINT_SIZE_LIMIT_BYTES) {
      replayChildren = true;
      if (options?.summaryGenerator) {
        payloadToCheckpoint = options.summaryGenerator(result);
      } else {
        payloadToCheckpoint = "";
      }
      log("\u{1F4E6}", "Large payload detected, using ReplayChildren mode:", {
        entityId,
        name,
        payloadSize: Buffer.byteLength(serializedResult, "utf8"),
        limit: CHECKPOINT_SIZE_LIMIT_BYTES
      });
    }
    if (preserveChildDepth >= 1) {
      replayChildren = true;
    }
    if (!isVirtual) {
      const subType = options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT;
      checkpoint.checkpoint(entityId, {
        Id: entityId,
        ParentId: parentId,
        Action: OperationAction.SUCCEED,
        SubType: subType,
        Type: OperationType.CONTEXT,
        Payload: payloadToCheckpoint,
        ContextOptions: replayChildren ? { ReplayChildren: true } : void 0,
        Name: name
      });
      const currentStepData = context.getStepData(entityId);
      const onOperationEndInfo = toOperationInfo(currentStepData);
      backfillOperationInfo(onOperationEndInfo, opInfo);
      await plugin.onOperationEnd?.({
        ...onOperationEndInfo,
        status: PluginOperationStatus.SUCCEEDED,
        isReplay: false
      });
      log("\u2705", "Child context completed successfully:", {
        entityId,
        name
      });
    } else {
      log("\u2705", "Virtual child context completed successfully:", {
        entityId,
        name
      });
      await plugin.onOperationEnd?.({
        ...opInfo,
        status: PluginOperationStatus.SUCCEEDED,
        isReplay: true
      });
    }
    return await safeDeserialize(serdes, serializedResult, entityId, name, context.terminationManager, context.durableExecutionArn);
  } catch (error) {
    markExecuting();
    log("\u274C", isVirtual ? "Virtual child context failed:" : "Child context failed:", {
      entityId,
      name,
      error
    });
    const errorObject = createErrorObjectFromError(error);
    const reconstructedError = DurableOperationError.fromErrorObject(errorObject);
    if (!isVirtual) {
      checkpoint.markAncestorFinished(entityId);
      const subType = options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT;
      checkpoint.checkpoint(entityId, {
        Id: entityId,
        ParentId: parentId,
        Action: OperationAction.FAIL,
        SubType: subType,
        Type: OperationType.CONTEXT,
        Error: createErrorObjectFromError(error),
        // Preserve the children of a FAILED context too when within the
        // configured depth — failures are often the most important thing to
        // observe (e.g. emitMode "on-failure"). A failed context throws its
        // checkpointed error on replay (ReplayMode) and is never re-executed,
        // so this only asks the backend to retain the children; it adds no
        // replay cost. See pluginsConfig.childOperationsDepth.
        ContextOptions: preserveChildDepth >= 1 ? { ReplayChildren: true } : void 0,
        Name: name
      });
      const currentStepData = context.getStepData(entityId);
      const onOperationEndInfo = toOperationInfo(currentStepData);
      backfillOperationInfo(onOperationEndInfo, opInfo);
      await plugin.onOperationEnd?.({
        ...onOperationEndInfo,
        status: PluginOperationStatus.FAILED,
        isReplay: false,
        error: reconstructedError
      });
    } else {
      await plugin.onOperationEnd?.({
        ...opInfo,
        status: PluginOperationStatus.FAILED,
        isReplay: true,
        error: reconstructedError
      });
    }
    if (errorMapper) {
      throw errorMapper(reconstructedError);
    }
    throw new ChildContextError(reconstructedError.message, reconstructedError);
  } finally {
    if (markedExecuting) {
      checkpoint.markOperationState(entityId, OperationLifecycleState.COMPLETED);
    }
  }
};
var createWaitHandler = (context, checkpoint, createStepId, parentId, checkAndUpdateReplayMode, plugin = {}) => {
  function waitHandler(nameOrDuration, duration) {
    const isNameFirst = typeof nameOrDuration === "string";
    const actualName = isNameFirst ? nameOrDuration : void 0;
    const actualDuration = isNameFirst ? duration : nameOrDuration;
    const actualSeconds = durationToSeconds(actualDuration);
    const stepId = createStepId();
    const opInfo = {
      id: hashId(stepId),
      name: actualName,
      type: OperationType.WAIT,
      subType: OperationSubType.WAIT,
      parentId: parentId ? hashId(parentId) : void 0
    };
    let isCompleted = false;
    const phase1Promise = (async () => {
      log("\u23F2\uFE0F", "Wait phase 1:", {
        stepId,
        name: actualName,
        seconds: actualSeconds
      });
      let stepData = context.getStepData(stepId);
      validateReplayConsistency(stepId, {
        type: OperationType.WAIT,
        name: actualName,
        subType: OperationSubType.WAIT
      }, stepData, context);
      if (stepData?.Status === OperationStatus.SUCCEEDED) {
        log("\u23ED\uFE0F", "Wait already completed:", { stepId });
        checkAndUpdateReplayMode?.();
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
          metadata: {
            stepId,
            name: actualName,
            type: OperationType.WAIT,
            subType: OperationSubType.WAIT,
            parentId
          }
        });
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        const isUpdatedBetweenInvocation = context.isOperationUpdatedBetweenInvocation(opInfo.id);
        await plugin.onOperationEnd?.({
          ...operationInfo,
          isReplay: !isUpdatedBetweenInvocation
        });
        isCompleted = true;
        return;
      }
      if (!stepData) {
        await checkpoint.checkpoint(stepId, {
          Id: stepId,
          ParentId: parentId,
          Action: OperationAction.START,
          SubType: OperationSubType.WAIT,
          Type: OperationType.WAIT,
          Name: actualName,
          WaitOptions: {
            WaitSeconds: actualSeconds
          }
        });
        stepData = context.getStepData(stepId);
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        await plugin.onOperationStart?.({ ...operationInfo, isReplay: false });
      } else {
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        await plugin.onOperationStart?.({ ...operationInfo, isReplay: true });
      }
      stepData = context.getStepData(stepId);
      checkpoint.markOperationState(stepId, OperationLifecycleState.IDLE_NOT_AWAITED, {
        metadata: {
          stepId,
          name: actualName,
          type: OperationType.WAIT,
          subType: OperationSubType.WAIT,
          parentId
        },
        endTimestamp: stepData?.WaitDetails?.ScheduledEndTimestamp
      });
      log("\u2705", "Wait phase 1 complete:", { stepId });
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      await phase1Promise;
      if (isCompleted) {
        return;
      }
      log("\u23F2\uFE0F", "Wait phase 2:", { stepId });
      checkpoint.markOperationAwaited(stepId);
      await checkpoint.waitForStatusChange(stepId);
      const stepData = context.getStepData(stepId);
      if (stepData?.Status === OperationStatus.SUCCEEDED) {
        log("\u2705", "Wait completed:", { stepId });
        checkAndUpdateReplayMode?.();
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        await plugin.onOperationEnd?.({ ...operationInfo, isReplay: false });
        return;
      }
      log("\u26A0\uFE0F", "Wait ended with unexpected status:", {
        stepId,
        status: stepData?.Status
      });
    });
  }
  return waitHandler;
};
var createWaitForConditionHandler = (context, checkpoint, createStepId, logger, parentId, getDefaultSerdes, plugin = {}) => {
  return (nameOrCheck, checkOrConfig, maybeConfig) => {
    let name;
    let check;
    let config;
    if (typeof nameOrCheck === "string" || nameOrCheck === void 0) {
      name = nameOrCheck;
      check = checkOrConfig;
      config = maybeConfig;
    } else {
      check = nameOrCheck;
      config = checkOrConfig;
    }
    if (!config?.waitStrategy || config.initialState === void 0) {
      throw new Error("waitForCondition requires config with waitStrategy and initialState");
    }
    const stepId = createStepId();
    const serdes = config.serdes || (getDefaultSerdes ? getDefaultSerdes() : defaultSerdes);
    const phase1Promise = (async () => {
      let stepData = context.getStepData(stepId);
      const opInfo = {
        id: hashId(stepId),
        name,
        type: OperationType.STEP,
        subType: OperationSubType.WAIT_FOR_CONDITION,
        parentId: parentId ? hashId(parentId) : void 0
      };
      if (stepData?.Status === OperationStatus.SUCCEEDED) {
        log("\u23ED\uFE0F", "WaitForCondition already completed:", { stepId });
        const result = stepData.StepDetails?.Result;
        return await completeAfter(checkpoint, stepId, () => safeDeserialize(serdes, result, stepId, name, context.terminationManager, context.durableExecutionArn), {
          stepId,
          name,
          type: OperationType.STEP,
          subType: OperationSubType.WAIT_FOR_CONDITION,
          parentId
        });
      }
      if (stepData?.Status === OperationStatus.FAILED) {
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
          metadata: {
            stepId,
            name,
            type: OperationType.STEP,
            subType: OperationSubType.WAIT_FOR_CONDITION,
            parentId
          }
        });
        if (stepData.StepDetails?.Error) {
          throw DurableOperationError.fromErrorObject(stepData.StepDetails.Error);
        }
        throw new WaitForConditionError("waitForCondition failed");
      }
      if (stepData?.Status === OperationStatus.PENDING) {
        checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
          metadata: {
            stepId,
            name,
            type: OperationType.STEP,
            subType: OperationSubType.WAIT_FOR_CONDITION,
            parentId
          },
          endTimestamp: stepData.StepDetails?.NextAttemptTimestamp
        });
        return (async () => {
          await checkpoint.waitForRetryTimer(stepId);
          stepData = context.getStepData(stepId);
          return await executeCheckLogic();
        })();
      }
      return await executeCheckLogic();
      async function executeCheckLogic() {
        stepData = context.getStepData(stepId);
        checkpoint.markOperationState(stepId, OperationLifecycleState.EXECUTING, {
          metadata: {
            stepId,
            name,
            type: OperationType.STEP,
            subType: OperationSubType.WAIT_FOR_CONDITION,
            parentId
          }
        });
        const checkpointData = stepData?.Status === OperationStatus.STARTED || stepData?.Status === OperationStatus.READY ? stepData.StepDetails?.Result : void 0;
        let currentState;
        if (checkpointData) {
          currentState = await safeDeserialize(serdes, checkpointData, stepId, name, context.terminationManager, context.durableExecutionArn);
        } else {
          const serializedInitialState = await safeSerialize(serdes, config.initialState, stepId, name, context.terminationManager, context.durableExecutionArn);
          currentState = await safeDeserialize(serdes, serializedInitialState, stepId, name, context.terminationManager, context.durableExecutionArn);
        }
        const currentAttempt = (stepData?.StepDetails?.Attempt ?? 0) + 1;
        if (stepData?.Status !== OperationStatus.STARTED) {
          const isRetryAttempt = (stepData?.StepDetails?.Attempt || 0) >= 1;
          checkpoint.checkpoint(stepId, {
            Id: stepId,
            ParentId: parentId,
            Action: OperationAction.START,
            SubType: OperationSubType.WAIT_FOR_CONDITION,
            Type: OperationType.STEP,
            Name: name
          });
          const operationInfo = toOperationInfo(stepData);
          backfillOperationInfo(operationInfo, opInfo);
          await plugin.onOperationStart?.({
            ...opInfo,
            status: PluginOperationStatus.STARTED,
            isReplay: isRetryAttempt
          });
        } else {
          const operationInfo = toOperationInfo(stepData);
          backfillOperationInfo(operationInfo, opInfo);
          await plugin.onOperationStart?.({ ...operationInfo, isReplay: true });
        }
        try {
          const waitForConditionContext = {
            logger,
            attempt: currentAttempt
          };
          const attemptInfo = toAttemptInfo(stepData, currentAttempt);
          backfillOperationInfo(attemptInfo, opInfo);
          attemptInfo.startTimestamp = /* @__PURE__ */ new Date();
          const checkFunc = () => check(currentState, waitForConditionContext);
          await plugin.onOperationAttemptStart?.(attemptInfo);
          const newState = await runWithContext(stepId, parentId, plugin.wrapOperationAttemptFn ? () => plugin.wrapOperationAttemptFn(attemptInfo, checkFunc) : checkFunc, currentAttempt, DurableExecutionMode.ExecutionMode, name);
          const serializedState = await safeSerialize(serdes, newState, stepId, name, context.terminationManager, context.durableExecutionArn);
          const deserializedState = await safeDeserialize(serdes, serializedState, stepId, name, context.terminationManager, context.durableExecutionArn);
          const decision = config.waitStrategy(deserializedState, currentAttempt);
          if (!decision.shouldContinue) {
            await checkpoint.checkpoint(stepId, {
              Id: stepId,
              ParentId: parentId,
              Action: OperationAction.SUCCEED,
              SubType: OperationSubType.WAIT_FOR_CONDITION,
              Type: OperationType.STEP,
              Payload: serializedState,
              Name: name
            });
            stepData = context.getStepData(stepId);
            const attemptEndInfo2 = toAttemptEndInfo(stepData, AttemptEndInfoOutcome.SUCCEEDED, {
              attempt: currentAttempt
            });
            backfillOperationInfo(attemptEndInfo2, opInfo);
            await plugin.onOperationAttemptEnd?.({
              ...attemptEndInfo2,
              startTimestamp: attemptEndInfo2.endTimestamp
            });
            await plugin.onOperationEnd?.({
              ...attemptEndInfo2,
              isReplay: false
            });
            return await completeAfter(checkpoint, stepId, () => safeDeserialize(serdes, serializedState, stepId, name, context.terminationManager, context.durableExecutionArn));
          }
          const nextAttemptDelaySeconds = durationToSeconds(decision.delay);
          await checkpoint.checkpoint(stepId, {
            Id: stepId,
            ParentId: parentId,
            Action: OperationAction.RETRY,
            SubType: OperationSubType.WAIT_FOR_CONDITION,
            Type: OperationType.STEP,
            Payload: serializedState,
            Name: name,
            StepOptions: {
              NextAttemptDelaySeconds: nextAttemptDelaySeconds
            }
          });
          stepData = context.getStepData(stepId);
          const attemptEndInfo = toAttemptEndInfo(stepData, AttemptEndInfoOutcome.SUCCEEDED, {
            attempt: currentAttempt
          });
          backfillOperationInfo(attemptEndInfo, opInfo);
          await plugin.onOperationAttemptEnd?.({
            ...attemptEndInfo,
            startTimestamp: attemptEndInfo.endTimestamp
          });
          checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
            metadata: {
              stepId,
              name,
              type: OperationType.STEP,
              subType: OperationSubType.WAIT_FOR_CONDITION,
              parentId
            },
            endTimestamp: context.getStepData(stepId)?.StepDetails?.NextAttemptTimestamp
          });
          await checkpoint.waitForRetryTimer(stepId);
          return await executeCheckLogic();
        } catch (error) {
          await checkpoint.checkpoint(stepId, {
            Id: stepId,
            ParentId: parentId,
            Action: OperationAction.FAIL,
            SubType: OperationSubType.WAIT_FOR_CONDITION,
            Type: OperationType.STEP,
            Error: createErrorObjectFromError(error),
            Name: name
          });
          checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
          stepData = context.getStepData(stepId);
          const attemptEndInfo = toAttemptEndInfo(stepData, AttemptEndInfoOutcome.FAILED, {
            attempt: currentAttempt,
            error: error instanceof Error ? error : new Error(String(error))
          });
          backfillOperationInfo(attemptEndInfo, opInfo);
          await plugin.onOperationAttemptEnd?.({
            ...attemptEndInfo,
            startTimestamp: attemptEndInfo.endTimestamp
          });
          await plugin.onOperationEnd?.({
            ...attemptEndInfo,
            isReplay: false,
            error: error instanceof Error ? error : new Error(String(error))
          });
          throw DurableOperationError.fromErrorObject(createErrorObjectFromError(error));
        }
      }
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      checkpoint.markOperationAwaited(stepId);
      return await phase1Promise;
    });
  };
};
var createCallbackPromise = (context, checkpoint, stepId, stepName, serdes, checkAndUpdateReplayMode, plugin = {}, opInfo = {}) => {
  return new DurablePromise(async () => {
    log("\u{1F504}", "Callback promise phase 2:", { stepId, stepName });
    checkpoint.markOperationAwaited(stepId);
    await checkpoint.waitForStatusChange(stepId);
    const stepData = context.getStepData(stepId);
    if (stepData?.Status === OperationStatus.SUCCEEDED) {
      log("\u2705", "Callback completed:", { stepId });
      checkAndUpdateReplayMode();
      return await completeAfter(checkpoint, stepId, async () => {
        const operationInfo2 = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo2, opInfo);
        await plugin.onOperationEnd?.({ ...operationInfo2, isReplay: false });
        const callbackData2 = stepData.CallbackDetails;
        if (!callbackData2) {
          throw new CallbackError(`No callback data found for completed callback: ${stepId}`);
        }
        const result = await safeDeserialize(serdes, callbackData2.Result, stepId, stepName, context.terminationManager, context.durableExecutionArn);
        return result;
      });
    }
    log("\u274C", "Callback failed:", { stepId, status: stepData?.Status });
    checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
    const callbackData = stepData?.CallbackDetails;
    const error = callbackData?.Error;
    const isTimeout = stepData?.Status === OperationStatus.TIMED_OUT;
    const callbackError = error ? (() => {
      const cause = new Error(error.ErrorMessage);
      cause.name = error.ErrorType || "Error";
      cause.stack = error.StackTrace?.join("\n");
      if (isTimeout) {
        return new CallbackTimeoutError(error.ErrorMessage || "Callback timed out", cause, error.ErrorData);
      }
      return new CallbackExternalError(error.ErrorMessage || "Callback failed", cause, error.ErrorData);
    })() : isTimeout ? new CallbackTimeoutError("Callback timed out") : new CallbackExternalError("Callback failed");
    const operationInfo = toOperationInfo(stepData);
    backfillOperationInfo(operationInfo, opInfo);
    await plugin.onOperationEnd?.({
      ...operationInfo,
      isReplay: false,
      // Keep synthesized caller failures out of backend error metadata when
      // the callback completed without error details.
      error: operationInfo.error ? callbackError : void 0
    });
    throw callbackError;
  });
};
var createPassThroughSerdes = () => ({
  serialize: async (value) => value,
  deserialize: async (data) => data
});
var createCallback = (context, checkpoint, createStepId, checkAndUpdateReplayMode, parentId, getDefaultCallbackDeserializer, plugin = {}, pluginOperationName) => {
  return (nameOrConfig, maybeConfig) => {
    let name;
    let config;
    if (typeof nameOrConfig === "string" || nameOrConfig === void 0) {
      name = nameOrConfig;
      config = maybeConfig;
    } else {
      config = nameOrConfig;
    }
    const stepId = createStepId();
    const subType = config?.subType || OperationSubType.CALLBACK;
    const serdes = config?.serdes || (getDefaultCallbackDeserializer ? getDefaultCallbackDeserializer() : createPassThroughSerdes());
    const opInfo = {
      id: hashId(stepId),
      name: pluginOperationName ?? name,
      type: OperationType.CALLBACK,
      subType,
      parentId: parentId ? hashId(parentId) : void 0
    };
    let isCompleted = false;
    const phase1Promise = (async () => {
      log("\u{1F4DE}", "Callback phase 1:", { stepId, name });
      let stepData = context.getStepData(stepId);
      validateReplayConsistency(stepId, {
        type: OperationType.CALLBACK,
        name,
        subType
      }, stepData, context);
      if (stepData?.Status === OperationStatus.SUCCEEDED) {
        log("\u23ED\uFE0F", "Callback already completed:", { stepId });
        checkAndUpdateReplayMode();
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
          metadata: {
            stepId,
            name,
            type: OperationType.CALLBACK,
            subType,
            parentId
          }
        });
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        const isUpdatedBetweenInvocation = context.isOperationUpdatedBetweenInvocation(opInfo.id);
        await plugin.onOperationEnd?.({
          ...operationInfo,
          isReplay: !isUpdatedBetweenInvocation
        });
        isCompleted = true;
        return;
      }
      if (stepData?.Status === OperationStatus.FAILED || stepData?.Status === OperationStatus.TIMED_OUT) {
        log("\u274C", "Callback already failed:", { stepId });
        checkAndUpdateReplayMode();
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
          metadata: {
            stepId,
            name,
            type: OperationType.CALLBACK,
            subType,
            parentId
          }
        });
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        const isUpdatedBetweenInvocation = context.isOperationUpdatedBetweenInvocation(opInfo.id);
        await plugin.onOperationEnd?.({
          ...operationInfo,
          isReplay: !isUpdatedBetweenInvocation
        });
        isCompleted = true;
        return;
      }
      if (!stepData) {
        await checkpoint.checkpoint(stepId, {
          Id: stepId,
          ParentId: parentId,
          Action: "START",
          SubType: subType,
          Type: OperationType.CALLBACK,
          Name: name,
          CallbackOptions: {
            TimeoutSeconds: config?.timeout ? durationToSeconds(config.timeout) : void 0,
            HeartbeatTimeoutSeconds: config?.heartbeatTimeout ? durationToSeconds(config.heartbeatTimeout) : void 0
          }
        });
        stepData = context.getStepData(stepId);
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        await plugin.onOperationStart?.({ ...operationInfo, isReplay: false });
      } else {
        const operationInfo = toOperationInfo(stepData);
        backfillOperationInfo(operationInfo, opInfo);
        await plugin.onOperationStart?.({ ...operationInfo, isReplay: true });
      }
      checkpoint.markOperationState(stepId, OperationLifecycleState.IDLE_NOT_AWAITED, {
        metadata: {
          stepId,
          name,
          type: OperationType.CALLBACK,
          subType,
          parentId
        }
      });
      log("\u2705", "Callback phase 1 complete:", { stepId });
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      await phase1Promise;
      if (isCompleted) {
        const stepData2 = context.getStepData(stepId);
        const callbackData2 = stepData2?.CallbackDetails;
        if (!callbackData2?.CallbackId) {
          throw new CallbackError(`No callback ID found for callback: ${stepId}`);
        }
        if (stepData2?.Status === OperationStatus.SUCCEEDED) {
          const deserializedResult = await completeAfter(checkpoint, stepId, () => safeDeserialize(serdes, callbackData2.Result, stepId, name, context.terminationManager, context.durableExecutionArn));
          const resolvedPromise = new DurablePromise(async () => deserializedResult);
          return [resolvedPromise, callbackData2.CallbackId];
        }
        const error = stepData2?.CallbackDetails?.Error;
        const isTimeout = stepData2?.Status === OperationStatus.TIMED_OUT;
        const callbackError = error ? (() => {
          const cause = new Error(error.ErrorMessage);
          cause.name = error.ErrorType || "Error";
          cause.stack = error.StackTrace?.join("\n");
          if (isTimeout) {
            return new CallbackTimeoutError(error.ErrorMessage || "Callback timed out", cause, error.ErrorData);
          }
          return new CallbackExternalError(error.ErrorMessage || "Callback failed", cause, error.ErrorData);
        })() : isTimeout ? new CallbackTimeoutError("Callback timed out") : new CallbackExternalError("Callback failed");
        const rejectedPromise = new DurablePromise(async () => {
          throw callbackError;
        });
        return [rejectedPromise, callbackData2.CallbackId];
      }
      log("\u{1F4DE}", "Callback phase 2:", { stepId });
      const stepData = context.getStepData(stepId);
      const callbackData = stepData?.CallbackDetails;
      if (!callbackData?.CallbackId) {
        throw new CallbackError(`No callback ID found for started callback: ${stepId}`);
      }
      const callbackId = callbackData.CallbackId;
      const callbackPromise = createCallbackPromise(context, checkpoint, stepId, name, serdes, checkAndUpdateReplayMode, plugin, opInfo);
      log("\u2705", "Callback created:", { stepId, name, callbackId });
      return [callbackPromise, callbackId];
    });
  };
};
var createWaitForCallbackHandler = (context, checkpoint, peekStepId, runInChildContext, getDefaultCallbackDeserializer) => {
  return (nameOrSubmitter, submitterOrConfig, maybeConfig) => {
    let name;
    let submitter;
    let config;
    if (typeof nameOrSubmitter === "string" || nameOrSubmitter === void 0) {
      name = nameOrSubmitter;
      if (typeof submitterOrConfig === "function") {
        submitter = submitterOrConfig;
        config = maybeConfig;
      } else {
        return new DurablePromise(() => Promise.reject(new Error("waitForCallback requires a submitter function when name is provided")));
      }
    } else if (typeof nameOrSubmitter === "function") {
      submitter = nameOrSubmitter;
      config = submitterOrConfig;
    } else {
      return new DurablePromise(() => Promise.reject(new Error("waitForCallback requires a submitter function")));
    }
    const phase1Promise = (async () => {
      log("\u{1F4DE}", "WaitForCallback requested:", {
        name,
        hasSubmitter: !!submitter,
        config
      });
      const childFunction = async (childCtx) => {
        const createCallbackConfig = config || getDefaultCallbackDeserializer ? {
          timeout: config?.timeout,
          heartbeatTimeout: config?.heartbeatTimeout,
          ...getDefaultCallbackDeserializer && {
            serdes: createPassThroughSerdes()
          }
        } : void 0;
        const internalCtx = childCtx;
        const [callbackPromise, callbackId] = await internalCtx._createCallbackWithPluginOperationName(name ? `${name}-callback` : void 0, createCallbackConfig);
        log("\u{1F194}", "Callback created:", {
          callbackId,
          name
        });
        const submitterOptions = config?.retryStrategy ? { retryStrategy: config.retryStrategy } : void 0;
        await internalCtx._stepWithPluginOperationName(name ? `${name}-submitter` : void 0, async (stepContext) => {
          const callbackContext = {
            logger: stepContext.logger
          };
          log("\u{1F4E4}", "Executing submitter:", {
            callbackId,
            name
          });
          await submitter(callbackId, callbackContext);
          log("\u2705", "Submitter completed:", {
            callbackId,
            name
          });
        }, submitterOptions);
        log("\u23F3", "Waiting for callback completion:", {
          callbackId,
          name
        });
        return await callbackPromise;
      };
      const stepId = peekStepId();
      return {
        result: await runInChildContext(name, childFunction, {
          subType: OperationSubType.WAIT_FOR_CALLBACK,
          // When a defaultCallbackDeserializer is configured, use passthrough serdes
          // so the raw callback string is preserved through the runInChildContext
          // round-trip and phase 2 can apply the deserializer exactly once.
          // Without this, defaultSerdes (JSON) would add an extra encode/decode layer.
          ...getDefaultCallbackDeserializer && {
            serdes: createPassThroughSerdes()
          },
          errorMapper: (originalError) => {
            if (originalError.errorType === "CallbackTimeoutError" || originalError.errorType === "CallbackExternalError" || originalError.errorType === "CallbackError") {
              return originalError;
            }
            if (originalError.errorType === "StepError") {
              return new CallbackSubmitterError(originalError.message, originalError);
            }
            return new ChildContextError(originalError.message, originalError);
          }
        }),
        stepId
      };
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      const { result, stepId } = await phase1Promise;
      return await completeAfter(checkpoint, stepId, () => safeDeserialize(config?.serdes ?? (getDefaultCallbackDeserializer ? getDefaultCallbackDeserializer() : createPassThroughSerdes()), result, stepId, name, context.terminationManager, context.durableExecutionArn), {
        stepId,
        name,
        type: OperationType.CONTEXT,
        subType: OperationSubType.WAIT_FOR_CALLBACK
      });
    });
  };
};
var ITEM_STATUS_SUCCEEDED = "S";
var ITEM_STATUS_FAILED = "F";
var ITEM_STATUS_INCOMPLETE = "-";
var encodeItemStatuses = (result) => {
  const items = result.all ?? [];
  if (items.length === 0) {
    return "";
  }
  let maxIndex = -1;
  for (const item of items) {
    if (typeof item.index === "number" && item.index > maxIndex) {
      maxIndex = item.index;
    }
  }
  if (maxIndex < 0) {
    return "";
  }
  const encoded = new Array(maxIndex + 1).fill(ITEM_STATUS_INCOMPLETE);
  for (const item of items) {
    if (typeof item.index !== "number") {
      continue;
    }
    if (item.status === BatchItemStatus.SUCCEEDED) {
      encoded[item.index] = ITEM_STATUS_SUCCEEDED;
    } else if (item.status === BatchItemStatus.FAILED) {
      encoded[item.index] = ITEM_STATUS_FAILED;
    }
  }
  return encoded.join("");
};
var createParallelSummaryGenerator = () => (result) => {
  return JSON.stringify({
    type: "ParallelResult",
    totalCount: result.totalCount,
    successCount: result.successCount,
    failureCount: result.failureCount,
    startedCount: result.startedCount,
    completionReason: result.completionReason,
    status: result.status,
    itemStatuses: encodeItemStatuses(result)
  });
};
var createMapSummaryGenerator = () => (result) => {
  return JSON.stringify({
    type: "MapResult",
    totalCount: result.totalCount,
    successCount: result.successCount,
    failureCount: result.failureCount,
    completionReason: result.completionReason,
    status: result.status,
    itemStatuses: encodeItemStatuses(result)
  });
};
var composeSummaryGenerator = (internalGenerator, customGenerator) => (result) => {
  const internal = internalGenerator(result);
  if (!customGenerator) {
    return internal;
  }
  let record;
  try {
    const parsed = JSON.parse(internal);
    record = parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    record = {};
  }
  record.summary = customGenerator(result);
  return JSON.stringify(record);
};
var createMapHandler = (context, executeConcurrently) => {
  return (nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig) => {
    const phase1Promise = (async () => {
      let name;
      let items;
      let mapFunc;
      let config;
      if (typeof nameOrItems === "string" || nameOrItems === void 0) {
        name = nameOrItems;
        items = itemsOrMapFunc;
        mapFunc = mapFuncOrConfig;
        config = maybeConfig;
      } else {
        items = nameOrItems;
        mapFunc = itemsOrMapFunc;
        config = mapFuncOrConfig;
      }
      log("\u{1F5FA}\uFE0F", "Starting map operation:", {
        name,
        itemCount: items.length,
        maxConcurrency: config?.maxConcurrency
      });
      if (!Array.isArray(items)) {
        throw new Error("Map operation requires an array of items");
      }
      if (typeof mapFunc !== "function") {
        throw new Error("Map operation requires a function to process items");
      }
      const executionItems = items.map((item, index) => ({
        id: `map-item-${index}`,
        data: item,
        index,
        name: config?.itemNamer ? config.itemNamer(item, index) : void 0
      }));
      const executor = async (executionItem, childContext) => mapFunc(childContext, executionItem.data, executionItem.index, items);
      const result = await executeConcurrently(name, executionItems, executor, {
        maxConcurrency: config?.maxConcurrency,
        topLevelSubType: OperationSubType.MAP,
        iterationSubType: OperationSubType.MAP_ITERATION,
        summaryGenerator: composeSummaryGenerator(createMapSummaryGenerator(), config?.summaryGenerator),
        completionConfig: config?.completionConfig,
        serdes: config?.serdes,
        itemSerdes: config?.itemSerdes,
        nesting: config?.nesting
      });
      log("\u{1F5FA}\uFE0F", "Map operation completed successfully:", {
        resultCount: result.totalCount
      });
      return result;
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      return await phase1Promise;
    });
  };
};
var createParallelHandler = (context, executeConcurrently) => {
  return (nameOrBranches, branchesOrConfig, maybeConfig) => {
    const phase1Promise = (async () => {
      let name;
      let branches;
      let config;
      if (typeof nameOrBranches === "string" || nameOrBranches === void 0) {
        name = nameOrBranches;
        branches = branchesOrConfig;
        config = maybeConfig;
      } else {
        branches = nameOrBranches;
        config = branchesOrConfig;
      }
      if (!Array.isArray(branches)) {
        throw new Error("Parallel operation requires an array of branch functions");
      }
      log("\u{1F500}", "Starting parallel operation:", {
        name,
        branchCount: branches.length,
        maxConcurrency: config?.maxConcurrency
      });
      if (branches.some((branch) => typeof branch !== "function" && (typeof branch !== "object" || typeof branch.func !== "function"))) {
        throw new Error("All branches must be functions or NamedParallelBranch objects");
      }
      const executionItems = branches.map((branch, index) => {
        const isNamedBranch = typeof branch === "object" && "func" in branch;
        const func = isNamedBranch ? branch.func : branch;
        const branchName = isNamedBranch ? branch.name : void 0;
        return {
          id: `parallel-branch-${index}`,
          data: func,
          index,
          name: branchName
        };
      });
      const executor = async (executionItem, childContext) => {
        log("\u{1F500}", "Processing parallel branch:", {
          index: executionItem.index
        });
        const result2 = await executionItem.data(childContext);
        log("\u2705", "Parallel branch completed:", {
          index: executionItem.index,
          result: result2
        });
        return result2;
      };
      const result = await executeConcurrently(name, executionItems, executor, {
        maxConcurrency: config?.maxConcurrency,
        topLevelSubType: OperationSubType.PARALLEL,
        iterationSubType: OperationSubType.PARALLEL_BRANCH,
        summaryGenerator: composeSummaryGenerator(createParallelSummaryGenerator(), config?.summaryGenerator),
        completionConfig: config?.completionConfig,
        serdes: config?.serdes,
        itemSerdes: config?.itemSerdes,
        nesting: config?.nesting
      });
      log("\u{1F500}", "Parallel operation completed successfully:", {
        resultCount: result.totalCount
      });
      return result;
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      return await phase1Promise;
    });
  };
};
function decorateErrors(value) {
  return value.map((item) => {
    if (item && item.status === "rejected" && item.reason instanceof Error) {
      return {
        ...item,
        reason: {
          message: item.reason.message,
          name: item.reason.name,
          stack: item.reason.stack
        }
      };
    }
    return item;
  });
}
function restoreErrors(value) {
  return value.map((item) => {
    if (item && item.status === "rejected" && item.reason && typeof item.reason === "object" && item.reason.message) {
      const error = new Error(item.reason.message);
      error.name = item.reason.name || "Error";
      if (item.reason.stack)
        error.stack = item.reason.stack;
      return {
        ...item,
        reason: error
      };
    }
    return item;
  });
}
function createErrorAwareSerdes() {
  return {
    serialize: async (value, _context) => value !== void 0 ? JSON.stringify(decorateErrors(value)) : void 0,
    deserialize: async (data, _context) => data !== void 0 ? restoreErrors(JSON.parse(data)) : void 0
  };
}
var createPromiseHandler = (runInChildContext) => {
  const parseParams = (nameOrPromises, maybePromises) => {
    if (typeof nameOrPromises === "string" || nameOrPromises === void 0) {
      return { name: nameOrPromises, promises: maybePromises };
    }
    return { name: void 0, promises: nameOrPromises };
  };
  const all = (nameOrPromises, maybePromises) => {
    return new DurablePromise(async () => {
      const { name, promises } = parseParams(nameOrPromises, maybePromises);
      return await runInChildContext(name, () => Promise.all(promises), {
        errorMapper: (error) => new PromiseCombinatorError(error.message, error)
      });
    });
  };
  const allSettled = (nameOrPromises, maybePromises) => {
    return new DurablePromise(async () => {
      const { name, promises } = parseParams(nameOrPromises, maybePromises);
      return await runInChildContext(name, () => Promise.allSettled(promises), {
        serdes: createErrorAwareSerdes(),
        errorMapper: (error) => new PromiseCombinatorError(error.message, error)
      });
    });
  };
  const any = (nameOrPromises, maybePromises) => {
    return new DurablePromise(async () => {
      const { name, promises } = parseParams(nameOrPromises, maybePromises);
      return await runInChildContext(name, () => Promise.any(promises), {
        errorMapper: (error) => new PromiseCombinatorError(error.message, error)
      });
    });
  };
  const race = (nameOrPromises, maybePromises) => {
    return new DurablePromise(async () => {
      const { name, promises } = parseParams(nameOrPromises, maybePromises);
      return await runInChildContext(name, () => Promise.race(promises), {
        errorMapper: (error) => new PromiseCombinatorError(error.message, error)
      });
    });
  };
  return {
    all,
    allSettled,
    any,
    race
  };
};
var KNOWN_DURABLE_ERROR_TYPES = /* @__PURE__ */ new Set([
  "StepError",
  "CallbackError",
  "CallbackExternalError",
  "CallbackTimeoutError",
  "CallbackSubmitterError",
  "InvokeError",
  "ChildContextError",
  "PromiseCombinatorError",
  "WaitForConditionError"
]);
function serializeBatchError(error) {
  if (!error) {
    return void 0;
  }
  const serialized = error instanceof DurableOperationError ? error.toErrorObject() : { ErrorType: error.name, ErrorMessage: error.message };
  const cause = error.cause;
  if (cause instanceof Error) {
    serialized.Cause = serializeBatchError(cause);
  }
  return serialized;
}
function reconstructBatchError(errorObject) {
  let error;
  if (errorObject.ErrorType && KNOWN_DURABLE_ERROR_TYPES.has(errorObject.ErrorType)) {
    error = DurableOperationError.fromErrorObject(errorObject);
  } else {
    error = new Error(errorObject.ErrorMessage);
    error.name = errorObject.ErrorType || "Error";
    error.stack = errorObject.StackTrace?.join("\n");
  }
  if (errorObject.Cause) {
    error.cause = reconstructBatchError(errorObject.Cause);
  }
  return error;
}
var BatchResultImpl = class {
  all;
  completionReason;
  // Counts are computed in a single pass at construction and filtered views
  // are memoized on first access. `all` must therefore not be mutated after
  // construction (readonly prevents reassignment, not push()/element writes) —
  // all internal construction sites pass locally-built arrays. The public
  // contract is documented on BatchResult.all.
  // Native #private fields keep these out of JSON.stringify output so the
  // serialized shape is identical to the previous getter-based implementation.
  #successCount;
  #failureCount;
  #startedCount;
  #succeededMemo;
  #failedMemo;
  #startedMemo;
  constructor(all, completionReason) {
    this.all = all;
    this.completionReason = completionReason;
    let success = 0;
    let failure = 0;
    let started = 0;
    for (const item of all) {
      if (item.status === BatchItemStatus.SUCCEEDED) {
        success++;
      } else if (item.status === BatchItemStatus.FAILED) {
        failure++;
      } else if (item.status === BatchItemStatus.STARTED) {
        started++;
      }
    }
    this.#successCount = success;
    this.#failureCount = failure;
    this.#startedCount = started;
  }
  succeeded() {
    this.#succeededMemo ??= this.all.filter((item) => item.status === BatchItemStatus.SUCCEEDED);
    return this.#succeededMemo.slice();
  }
  failed() {
    this.#failedMemo ??= this.all.filter((item) => item.status === BatchItemStatus.FAILED);
    return this.#failedMemo.slice();
  }
  started() {
    this.#startedMemo ??= this.all.filter((item) => item.status === BatchItemStatus.STARTED);
    return this.#startedMemo.slice();
  }
  get status() {
    if (this.completionReason === "CUSTOM_COMPLETION_FAILED") {
      return BatchItemStatus.FAILED;
    }
    if (this.completionReason === "CUSTOM_COMPLETION_SUCCEEDED") {
      return BatchItemStatus.SUCCEEDED;
    }
    return this.hasFailure ? BatchItemStatus.FAILED : BatchItemStatus.SUCCEEDED;
  }
  get hasFailure() {
    return this.#failureCount > 0;
  }
  throwIfError() {
    const firstError = this.all.find((item) => item.status === BatchItemStatus.FAILED)?.error;
    if (firstError) {
      throw firstError;
    }
    if (this.status === BatchItemStatus.FAILED) {
      throw new BatchCompletionError(this.completionReason);
    }
  }
  getResults() {
    return this.succeeded().map((item) => item.result);
  }
  getErrors() {
    return this.failed().map((item) => item.error);
  }
  get successCount() {
    return this.#successCount;
  }
  get failureCount() {
    return this.#failureCount;
  }
  get startedCount() {
    return this.#startedCount;
  }
  get totalCount() {
    return this.all.length;
  }
};
function restoreBatchResult(data) {
  if (data instanceof BatchResultImpl) {
    return data;
  }
  if (data && typeof data === "object" && "all" in data && Array.isArray(data.all)) {
    const serializedData = data;
    const restoredItems = serializedData.all.map((item) => ({
      ...item,
      result: item.result,
      error: item.error ? reconstructBatchError(item.error) : void 0
    }));
    return new BatchResultImpl(restoredItems, serializedData.completionReason);
  }
  return new BatchResultImpl([], "ALL_COMPLETED");
}
function createBatchResultSerdes() {
  return {
    serialize: async (value, _context) => {
      if (!value)
        return void 0;
      const serialized = {
        all: value.all.map((item) => ({
          ...item,
          error: item.error instanceof Error ? serializeBatchError(item.error) : void 0
        })),
        completionReason: value.completionReason
      };
      return JSON.stringify(serialized);
    },
    deserialize: async (data, _context) => {
      if (!data)
        return void 0;
      return restoreBatchResult(JSON.parse(data));
    }
  };
}
var VALID_COMPLETION_REASONS = {
  ALL_COMPLETED: true,
  MIN_SUCCESSFUL_REACHED: true,
  FAILURE_TOLERANCE_EXCEEDED: true,
  CUSTOM_COMPLETION_SUCCEEDED: true,
  CUSTOM_COMPLETION_FAILED: true
};
function validateCompletionConfig(completion, terminationManager) {
  if (completion?.shouldComplete !== void 0 && (completion.minSuccessful !== void 0 || completion.toleratedFailureCount !== void 0 || completion.toleratedFailurePercentage !== void 0)) {
    const message = "completionConfig.shouldComplete is mutually exclusive with minSuccessful, toleratedFailureCount, and toleratedFailurePercentage";
    terminationManager.terminate({
      reason: TerminationReason.CONFIG_VALIDATION_ERROR,
      message,
      error: new Error(message)
    });
    return false;
  }
  return true;
}
function validateMaxConcurrency(maxConcurrency, terminationManager) {
  if (maxConcurrency !== void 0 && maxConcurrency !== null && maxConcurrency <= 0) {
    const message = `Invalid maxConcurrency: ${maxConcurrency}. Must be a positive number or undefined for unlimited concurrency.`;
    terminationManager.terminate({
      reason: TerminationReason.CONFIG_VALIDATION_ERROR,
      message,
      error: new Error(message)
    });
    return false;
  }
  return true;
}
var ConcurrencyController = class {
  operationName;
  getDefaultSerdes;
  constructor(operationName, getDefaultSerdes) {
    this.operationName = operationName;
    this.getDefaultSerdes = getDefaultSerdes;
  }
  /**
   * Advance the step cursor of the context that {@link replayItems} re-drives
   * child operations on, for a non-terminal item that is NOT re-executed on
   * replay (one that was in flight at suspension, or never started).
   *
   * This MUST advance the SAME context that runInChildContext runs on
   * (`parentContext` — the map/parallel child context), not the outer context
   * that owns the map/parallel call. If a skipped in-flight item does not
   * advance this cursor, the next terminal item's runInChildContext peeks the
   * pending non-terminal step, `checkForNonResolvingPromise` returns a
   * never-resolving promise, and replay hangs (issue #751). `skipNextOperation`
   * is internal to the durable context, so it is reached through a narrow cast
   * (the same pattern used to read `_stepPrefix`/`durableExecutionMode`).
   */
  skipReplayStep(parentContext) {
    parentContext.skipNextOperation();
  }
  getCompletionReason(failureCount, successCount, completedCount, items, config, itemStatuses) {
    const completion = config.completionConfig;
    if (completion?.shouldComplete) {
      const decision = completion.shouldComplete({
        successCount,
        failureCount,
        completedCount,
        totalCount: items.length,
        items: itemStatuses
      });
      if (decision.complete) {
        return decision.outcome === CompletionOutcome.FAILED ? "CUSTOM_COMPLETION_FAILED" : "CUSTOM_COMPLETION_SUCCEEDED";
      }
      return "ALL_COMPLETED";
    }
    if (!completion) {
      if (failureCount > 0)
        return "FAILURE_TOLERANCE_EXCEEDED";
    } else {
      const hasAnyCompletionCriteria = Object.values(completion).some((value) => value !== void 0);
      if (!hasAnyCompletionCriteria) {
        if (failureCount > 0)
          return "FAILURE_TOLERANCE_EXCEEDED";
      } else {
        if (completion.toleratedFailureCount !== void 0 && failureCount > completion.toleratedFailureCount) {
          return "FAILURE_TOLERANCE_EXCEEDED";
        }
        if (completion.toleratedFailurePercentage !== void 0) {
          const failurePercentage = failureCount / items.length * 100;
          if (failurePercentage > completion.toleratedFailurePercentage) {
            return "FAILURE_TOLERANCE_EXCEEDED";
          }
        }
      }
    }
    if (completedCount === items.length)
      return "ALL_COMPLETED";
    if (config.completionConfig?.minSuccessful !== void 0 && successCount >= config.completionConfig.minSuccessful)
      return "MIN_SUCCESSFUL_REACHED";
    return "ALL_COMPLETED";
  }
  async executeItems(items, executor, parentContext, config, durableExecutionMode = DurableExecutionMode.ExecutionMode, entityId, executionContext) {
    if (durableExecutionMode === DurableExecutionMode.ReplaySucceededContext) {
      log("\u{1F504}", `Replay mode: Reconstructing ${this.operationName} result:`, {
        itemCount: items.length
      });
      let recordedCompletionReason;
      let recordedItemStatuses;
      if (entityId && executionContext) {
        const stepData = executionContext.getStepData(entityId);
        const summaryPayload = stepData?.ContextDetails?.Result;
        if (summaryPayload) {
          recordedCompletionReason = this.parseRecordedCompletionReason(summaryPayload);
          recordedItemStatuses = this.parseRecordedItemStatuses(summaryPayload);
          log("\u{1F4CA}", "Recovered completion reason from summary:", {
            recordedCompletionReason,
            hasRecordedItemStatuses: recordedItemStatuses !== void 0
          });
        }
      }
      if (entityId && executionContext) {
        return await this.replayItems(items, executor, parentContext, config, recordedCompletionReason, recordedItemStatuses, executionContext, entityId);
      } else {
        log("\u26A0\uFE0F", "No entity id or execution context found, falling back to concurrent execution");
      }
    }
    return await this.executeItemsConcurrently(items, executor, parentContext, config, entityId, executionContext);
  }
  /**
   * Extracts a recorded `completionReason` from a checkpointed batch summary.
   *
   * The summary is stored as a raw JSON string (written by the composed summary
   * generator), so it is parsed directly rather than routed through a
   * BatchResult serdes. Returns `undefined` when the payload is missing,
   * unparseable, or does not carry a string `completionReason` (e.g. an old
   * checkpoint written by a pre-fix custom generator that returned a free-form
   * string) — in that case replayItems re-infers the reason from the
   * reconstructed items.
   */
  parseRecordedCompletionReason(summaryPayload) {
    if (typeof summaryPayload !== "string") {
      return void 0;
    }
    try {
      const parsed = JSON.parse(summaryPayload);
      if (parsed && typeof parsed === "object") {
        const reason = parsed.completionReason;
        if (typeof reason === "string" && Object.hasOwn(VALID_COMPLETION_REASONS, reason)) {
          return reason;
        }
      }
    } catch {
      log("\u26A0\uFE0F", "Could not parse batch summary for completion reason");
    }
    return void 0;
  }
  /**
   * Extracts the recorded per-item completion markers from a checkpointed batch
   * payload. One character per item in index order (`S`/`F`/`-`).
   *
   * Two payload shapes are recognised, because ReplayChildren is reached two
   * ways:
   *
   *  - The summary written when the result exceeded the checkpoint size limit,
   *    which carries `itemStatuses` directly.
   *  - The FULL serialized BatchResult written when `childOperationsDepth` opts
   *    a context into child preservation. That path sets ReplayChildren while
   *    checkpointing the whole result, so the summary generator never runs and
   *    there is no `itemStatuses` — but the payload already contains
   *    `all: [{ index, status }]`, which carries the same information.
   *
   * Validated as strictly as `parseRecordedCompletionReason`: legacy checkpoints
   * can carry arbitrary JSON (including free-form strings from pre-fix custom
   * generators), and the consequence here is terminality decisions rather than a
   * display field. `Object.hasOwn` keeps inherited keys like `constructor` out,
   * and the marker alphabet is checked so a crafted value cannot be read as
   * terminality.
   *
   * Returns undefined when the payload is absent, unparseable, or carries
   * neither shape — in which case replay falls back to probing.
   */
  parseRecordedItemStatuses(summaryPayload) {
    if (typeof summaryPayload !== "string") {
      return void 0;
    }
    let parsed;
    try {
      parsed = JSON.parse(summaryPayload);
    } catch {
      return void 0;
    }
    if (!parsed || typeof parsed !== "object") {
      return void 0;
    }
    const record = parsed;
    if (Object.hasOwn(record, "itemStatuses")) {
      const statuses = record.itemStatuses;
      if (typeof statuses === "string" && statuses.length > 0 && /^[SF-]+$/.test(statuses)) {
        return statuses;
      }
      return void 0;
    }
    if (Object.hasOwn(record, "all") && Array.isArray(record.all)) {
      return this.encodeStatusesFromBatchItems(record.all);
    }
    return void 0;
  }
  /**
   * Derives the per-item markers from a checkpointed `all` array, so the
   * `childOperationsDepth` path (which checkpoints the full result and therefore
   * has no summary envelope) gets the same treatment as a summarized batch.
   */
  encodeStatusesFromBatchItems(items) {
    let maxIndex = -1;
    for (const entry of items) {
      if (!entry || typeof entry !== "object") {
        continue;
      }
      const index = entry.index;
      if (typeof index === "number" && index > maxIndex) {
        maxIndex = index;
      }
    }
    if (maxIndex < 0) {
      return void 0;
    }
    const encoded = new Array(maxIndex + 1).fill("-");
    for (const entry of items) {
      if (!entry || typeof entry !== "object") {
        continue;
      }
      const item = entry;
      if (typeof item.index !== "number") {
        continue;
      }
      if (item.status === BatchItemStatus.SUCCEEDED) {
        encoded[item.index] = "S";
      } else if (item.status === BatchItemStatus.FAILED) {
        encoded[item.index] = "F";
      }
    }
    return encoded.join("");
  }
  /**
   * Whether a virtual item finished, inferred from its own checkpointed
   * operations. Used ONLY for summaries written before per-item statuses were
   * recorded.
   *
   * A virtual (FLAT) item has no context checkpoint, so its operations are
   * probed directly. Probing only the first operation would be unsound: an item
   * that was still in flight can have a SUCCEEDED first operation and would be
   * misread as finished. Every recorded operation is therefore walked, and the
   * item counts as finished only if all of them are terminal.
   *
   * Step ids come from a per-context counter starting at 1 and increasing by one
   * per operation, so the recorded ids are contiguous and the walk stops at the
   * first gap.
   *
   * Residual limitation, unavoidable without recorded statuses: an item whose
   * body creates no durable operation leaves nothing to probe and is
   * indistinguishable from one that never started, so it reads as unfinished and
   * is not rebuilt.
   */
  isVirtualItemTerminalByProbe(executionContext, childEntityId) {
    let found = false;
    for (let opIndex = 1; ; opIndex++) {
      const op = executionContext.getStepData(`${childEntityId}-${opIndex}`);
      if (!op) {
        break;
      }
      found = true;
      if (op.Status !== OperationStatus.SUCCEEDED && op.Status !== OperationStatus.FAILED) {
        return false;
      }
    }
    return found;
  }
  async replayItems(items, executor, parentContext, config, recordedCompletionReason, recordedItemStatuses, executionContext, parentEntityId) {
    const resultItems = [];
    log("\u{1F504}", `Replaying ${items.length} items from child checkpoints`, {
      recordedCompletionReason
    });
    let stepCounter = 0;
    for (const item of items) {
      const childEntityId = `${parentEntityId}-${stepCounter + 1}`;
      const childStepData = executionContext.getStepData(childEntityId);
      const childRecordIsTerminal = !childStepData || childStepData.Status === OperationStatus.SUCCEEDED || childStepData.Status === OperationStatus.FAILED;
      let isTerminal;
      if (recordedItemStatuses !== void 0) {
        const marker = recordedItemStatuses[item.index];
        isTerminal = (marker === "S" || marker === "F") && childRecordIsTerminal;
      } else if (childStepData) {
        isTerminal = childStepData.Status === OperationStatus.SUCCEEDED || childStepData.Status === OperationStatus.FAILED;
      } else {
        isTerminal = this.isVirtualItemTerminalByProbe(executionContext, childEntityId);
      }
      if (isTerminal) {
        try {
          const result = await parentContext.runInChildContext(item.name || item.id, (childContext) => executor(item, childContext), {
            subType: config.iterationSubType,
            serdes: config.itemSerdes,
            virtualContext: config.nesting === NestingType.FLAT
          });
          resultItems.push({
            result,
            index: item.index,
            status: BatchItemStatus.SUCCEEDED
          });
          log("\u2705", `Replayed ${this.operationName} item:`, {
            index: item.index,
            itemId: item.id
          });
        } catch (error) {
          const err = error instanceof ChildContextError ? error : new ChildContextError(error instanceof Error ? error.message : String(error), error instanceof Error ? error : void 0);
          resultItems.push({
            error: err,
            index: item.index,
            status: BatchItemStatus.FAILED
          });
          log("\u274C", `Replay failed for ${this.operationName} item:`, {
            index: item.index,
            itemId: item.id,
            error: err.message
          });
        }
        stepCounter++;
      } else {
        this.skipReplayStep(parentContext);
        stepCounter++;
        log("\u23ED\uFE0F", `Skipping non-terminal item during replay:`, {
          index: item.index,
          itemId: item.id,
          childEntityId
        });
      }
    }
    const successCount = resultItems.filter((item) => item.status === BatchItemStatus.SUCCEEDED).length;
    const failureCount = resultItems.filter((item) => item.status === BatchItemStatus.FAILED).length;
    const completedCount = successCount + failureCount;
    log("\u{1F389}", `${this.operationName} replay completed:`, {
      successCount,
      failureCount,
      startedCount: resultItems.filter((item) => item.status === BatchItemStatus.STARTED).length,
      totalCount: resultItems.length
    });
    let completionReason = recordedCompletionReason;
    if (completionReason === void 0) {
      const statusByIndex = /* @__PURE__ */ new Map();
      for (const r of resultItems) {
        statusByIndex.set(r.index, r.status);
      }
      const itemStatuses = items.map((item) => ({
        index: item.index,
        name: item.name,
        status: statusByIndex.get(item.index)
      }));
      completionReason = this.getCompletionReason(failureCount, successCount, completedCount, items, config, itemStatuses);
    }
    return new BatchResultImpl(resultItems, completionReason);
  }
  /**
   * Runs the items and decides when the batch completes.
   *
   * A batch can resume after an earlier invocation ended between the item
   * checkpoints and the batch checkpoint. Then several items already have a
   * terminal record. Most of them finished before that invocation's
   * completion decision. Up to maxConcurrency - 1 of them can be racers: items
   * that recorded their outcome after the decision but before the batch
   * context finished, which the live result reported STARTED (issue #967). On
   * resume, the recorded items settle again in index order, not in their
   * original order. So an early recorded success could reach minSuccessful
   * before another recorded item settles, and that item would be reported
   * STARTED.
   *
   * So while any recorded item has not settled, the controller does not
   * resolve. During that time it starts items only up to the last recorded
   * index, because each recorded item needs its own start to get its id. It
   * starts no later item, because the original invocation may have stopped
   * before it.
   *
   * The built-in rules stay met once they are met, because the counts only
   * grow. So for them the controller decides on the full set, once every
   * recorded item has settled. A custom shouldComplete predicate need not stay
   * met. So the controller keeps the first complete decision the predicate
   * returns while recorded items settle, and resolves with it. Once every
   * recorded item has settled, the controller evaluates completion before it
   * starts later items.
   *
   * A gap item is an item below the last recorded index that has no terminal
   * record. Once the outcome is known while recorded items settle, the
   * controller reserves a gap item's child id without running it, so its code
   * does not run again for a result the batch will not use.
   *
   * So every recorded outcome is kept. For the built-in rules, and for a
   * predicate that stays complete once it is complete as the counts grow, no
   * item starts that the completion rule would not start. Other predicates can
   * decide differently on resume, because the original settle order is not
   * recorded, and the resumed order can differ: a cached failure settles
   * faster than a cached success. For example, `successCount === 1 &&
   * failureCount === 0` can see (0, 1) and then (1, 1) on resume, and never
   * complete.
   */
  async executeItemsConcurrently(items, executor, parentContext, config, batchEntityId, executionContext) {
    const maxConcurrency = config.maxConcurrency || Infinity;
    const resultItems = new Array(items.length);
    const startedItems = /* @__PURE__ */ new Set();
    let activeCount = 0;
    let currentIndex = 0;
    let completedCount = 0;
    let successCount = 0;
    let failureCount = 0;
    const recordedTerminal = /* @__PURE__ */ new Set();
    let lastRecorded = -1;
    if (batchEntityId !== void 0 && executionContext !== void 0 && config.nesting !== NestingType.FLAT) {
      for (let i = 0; i < items.length; i++) {
        const status = executionContext.getStepData(`${batchEntityId}-${i + 1}`)?.Status;
        if (status === OperationStatus.SUCCEEDED || status === OperationStatus.FAILED) {
          recordedTerminal.add(i);
          lastRecorded = i;
        }
      }
    }
    let unsettledRecorded = recordedTerminal.size;
    const reconciling = () => unsettledRecorded > 0;
    let latchedReason;
    let resolved = false;
    let outcomeKnown = () => false;
    log("\u{1F680}", `Starting ${this.operationName} with concurrency control:`, {
      itemCount: items.length,
      maxConcurrency
    });
    return new Promise((resolve) => {
      const buildItemStatuses = () => items.map((item) => ({
        index: item.index,
        name: item.name,
        status: resultItems[item.index]?.status
      }));
      const buildCompletionStatus = () => ({
        successCount,
        failureCount,
        completedCount,
        totalCount: items.length,
        items: buildItemStatuses()
      });
      const shouldContinue = () => {
        const completion = config.completionConfig;
        if (!completion)
          return failureCount === 0;
        if (completion.shouldComplete) {
          return !completion.shouldComplete(buildCompletionStatus()).complete;
        }
        const hasAnyCompletionCriteria = Object.values(completion).some((value) => value !== void 0);
        if (!hasAnyCompletionCriteria) {
          return failureCount === 0;
        }
        if (completion.toleratedFailureCount !== void 0 && failureCount > completion.toleratedFailureCount)
          return false;
        if (completion.toleratedFailurePercentage !== void 0) {
          const failurePercentage = failureCount / items.length * 100;
          if (failurePercentage > completion.toleratedFailurePercentage)
            return false;
        }
        return true;
      };
      const isComplete = () => {
        if (completedCount === items.length) {
          return true;
        }
        const completion = config.completionConfig;
        if (completion?.shouldComplete) {
          return completion.shouldComplete(buildCompletionStatus()).complete;
        }
        if (completion?.minSuccessful !== void 0 && successCount >= completion.minSuccessful) {
          return true;
        }
        return false;
      };
      const getCompletionReason = (failureCount2) => {
        return this.getCompletionReason(failureCount2, successCount, completedCount, items, config, buildItemStatuses());
      };
      outcomeKnown = () => latchedReason !== void 0 || !config.completionConfig?.shouldComplete && (isComplete() || !shouldContinue());
      const tryStartNext = () => {
        while (activeCount < maxConcurrency && currentIndex < items.length && (reconciling() ? currentIndex <= lastRecorded : shouldContinue())) {
          const index = currentIndex++;
          const item = items[index];
          if (reconciling() && !recordedTerminal.has(index) && outcomeKnown()) {
            this.skipReplayStep(parentContext);
            log("\u23ED", `Skipping unfinished ${this.operationName} item:`, {
              index,
              itemId: item.id
            });
            continue;
          }
          startedItems.add(index);
          activeCount++;
          resultItems[index] = { index, status: BatchItemStatus.STARTED };
          log("\u25B6\uFE0F", `Starting ${this.operationName} item:`, {
            index,
            itemId: item.id,
            itemName: item.name
          });
          parentContext.runInChildContext(item.name || item.id, (childContext) => executor(item, childContext), {
            subType: config.iterationSubType,
            serdes: config.itemSerdes,
            virtualContext: config.nesting === NestingType.FLAT
          }).then((result) => {
            resultItems[index] = {
              result,
              index,
              status: BatchItemStatus.SUCCEEDED
            };
            successCount++;
            log("\u2705", `${this.operationName} item completed:`, {
              index,
              itemId: item.id,
              itemName: item.name
            });
            onComplete(index);
          }, (error) => {
            const err = error instanceof ChildContextError ? error : new ChildContextError(error instanceof Error ? error.message : String(error), error instanceof Error ? error : void 0);
            resultItems[index] = {
              error: err,
              index,
              status: BatchItemStatus.FAILED
            };
            failureCount++;
            log("\u274C", `${this.operationName} item failed:`, {
              index,
              itemId: item.id,
              itemName: item.name,
              error: err.message
            });
            onComplete(index);
          });
        }
      };
      const onComplete = (index) => {
        activeCount--;
        completedCount++;
        if (recordedTerminal.has(index)) {
          unsettledRecorded--;
        }
        if (resolved) {
          return;
        }
        if (reconciling()) {
          if (latchedReason === void 0 && config.completionConfig?.shouldComplete && isComplete()) {
            latchedReason = getCompletionReason(failureCount);
          }
          tryStartNext();
          return;
        }
        if (latchedReason !== void 0 || isComplete() || !shouldContinue()) {
          resolved = true;
          const finalBatchItems = [];
          for (let i = 0; i < resultItems.length; i++) {
            if (resultItems[i] !== void 0) {
              finalBatchItems.push({ ...resultItems[i] });
            }
          }
          log("\u{1F389}", `${this.operationName} completed:`, {
            successCount,
            failureCount,
            startedCount: finalBatchItems.filter((item) => item.status === BatchItemStatus.STARTED).length,
            totalCount: finalBatchItems.length
          });
          const result = new BatchResultImpl(finalBatchItems, latchedReason ?? getCompletionReason(failureCount));
          resolve(result);
        } else {
          tryStartNext();
        }
      };
      if (items.length === 0) {
        log("\u{1F389}", `${this.operationName} completed with no items`);
        resolve(new BatchResultImpl([], getCompletionReason(0)));
      } else {
        tryStartNext();
        if (activeCount === 0 && completedCount === 0) {
          resolve(new BatchResultImpl([], getCompletionReason(0)));
        }
      }
    });
  }
};
var createConcurrentExecutionHandler = (context, runInChildContext, getDefaultSerdes) => {
  return (nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig) => {
    const phase1Promise = (async () => {
      let name;
      let items;
      let executor;
      let config;
      if (typeof nameOrItems === "string" || nameOrItems === void 0) {
        name = nameOrItems;
        items = itemsOrExecutor;
        executor = executorOrConfig;
        config = maybeConfig;
      } else {
        items = nameOrItems;
        executor = itemsOrExecutor;
        config = executorOrConfig;
      }
      log("\u{1F504}", "Starting concurrent execution:", {
        name,
        itemCount: items.length,
        maxConcurrency: config?.maxConcurrency
      });
      if (!Array.isArray(items)) {
        throw new Error("Concurrent execution requires an array of items");
      }
      if (typeof executor !== "function") {
        throw new Error("Concurrent execution requires an executor function");
      }
      if (!validateMaxConcurrency(config?.maxConcurrency, context.terminationManager)) {
        return new Promise(() => {
        });
      }
      if (!validateCompletionConfig(config?.completionConfig, context.terminationManager)) {
        return new Promise(() => {
        });
      }
      const executeOperation = async (executionContext) => {
        const concurrencyController = new ConcurrencyController("concurrent-execution", getDefaultSerdes);
        const durableExecutionMode = executionContext.durableExecutionMode;
        const entityId = executionContext._stepPrefix;
        log("\u{1F504}", "Concurrent execution mode:", {
          mode: durableExecutionMode,
          itemCount: items.length,
          entityId
        });
        return await concurrencyController.executeItems(items, executor, executionContext, config || {}, durableExecutionMode, entityId, context);
      };
      const result = await runInChildContext(name, executeOperation, {
        subType: config?.topLevelSubType,
        summaryGenerator: config?.summaryGenerator,
        // Use BatchResult serdes to preserve Error types through serialization.
        serdes: config?.serdes || createBatchResultSerdes()
      });
      if (result && typeof result === "object" && "all" in result && Array.isArray(result.all)) {
        return restoreBatchResult(result);
      }
      return result;
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      return await phase1Promise;
    });
  };
};
var ModeManagement = class {
  captureExecutionState;
  checkAndUpdateReplayMode;
  checkForNonResolvingPromise;
  getDurableExecutionMode;
  setDurableExecutionMode;
  constructor(captureExecutionState, checkAndUpdateReplayMode, checkForNonResolvingPromise, getDurableExecutionMode, setDurableExecutionMode) {
    this.captureExecutionState = captureExecutionState;
    this.checkAndUpdateReplayMode = checkAndUpdateReplayMode;
    this.checkForNonResolvingPromise = checkForNonResolvingPromise;
    this.getDurableExecutionMode = getDurableExecutionMode;
    this.setDurableExecutionMode = setDurableExecutionMode;
  }
  withModeManagement(operation) {
    const shouldSwitchToExecutionMode = this.captureExecutionState();
    this.checkAndUpdateReplayMode();
    const nonResolvingPromise = this.checkForNonResolvingPromise();
    if (nonResolvingPromise)
      return nonResolvingPromise;
    try {
      return operation();
    } finally {
      if (shouldSwitchToExecutionMode) {
        this.setDurableExecutionMode(DurableExecutionMode.ExecutionMode);
      }
    }
  }
  withDurableModeManagement(operation) {
    const shouldSwitchToExecutionMode = this.captureExecutionState();
    this.checkAndUpdateReplayMode();
    const nonResolvingPromise = this.checkForNonResolvingPromise();
    if (nonResolvingPromise) {
      return new DurablePromise(async () => {
        await nonResolvingPromise;
        throw new Error("Unreachable code");
      });
    }
    try {
      return operation();
    } finally {
      if (shouldSwitchToExecutionMode) {
        this.setDurableExecutionMode(DurableExecutionMode.ExecutionMode);
      }
    }
  }
};
var DURABLE_CONTEXT_BRAND = /* @__PURE__ */ Symbol.for("@aws/durable-execution-sdk-js/durable-context");
var DurableContextImpl = class {
  _executionContext;
  lambdaContext;
  [DURABLE_CONTEXT_BRAND] = true;
  _stepPrefix;
  _stepCounter = 0;
  durableLogger;
  modeAwareLoggingEnabled = true;
  checkpoint;
  durableExecutionMode;
  _parentId;
  modeManagement;
  durableExecution;
  /**
   * Remaining depth budget for preserving child-context operations across
   * suspend/resume. A context sets `ReplayChildren` on a child it runs when the
   * child's budget (this value minus 1) is >= 1. Decremented by one for each
   * nested context. `0` (default) disables preservation; `Infinity` preserves
   * the whole tree. Seeded at the root from
   * `DurableExecutionConfig.pluginsConfig.childOperationsDepth`.
   * @internal
   */
  _preserveChildDepth = 0;
  _defaultSerdes = defaultSerdes;
  _defaultCallbackDeserializer = createPassThroughSerdes();
  _customCallbackDeserializerSet = false;
  logger;
  executionContext;
  get [Symbol.toStringTag]() {
    return "DurableContext";
  }
  constructor(_executionContext, lambdaContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId, preserveChildDepth = 0) {
    this._executionContext = _executionContext;
    this.lambdaContext = lambdaContext;
    this._stepPrefix = stepPrefix;
    this._parentId = parentId;
    this._preserveChildDepth = preserveChildDepth;
    this.durableExecution = durableExecution;
    this.durableLogger = inheritedLogger;
    this.durableLogger.configureDurableLoggingContext?.(this.getDurableLoggingContext());
    this.logger = this.createModeAwareLogger(inheritedLogger);
    this.executionContext = {
      durableExecutionArn: _executionContext.durableExecutionArn
    };
    this.durableExecutionMode = durableExecutionMode;
    this.checkpoint = durableExecution.checkpointManager;
    this.modeManagement = new ModeManagement(this.captureExecutionState.bind(this), this.checkAndUpdateReplayMode.bind(this), this.checkForNonResolvingPromise.bind(this), () => this.durableExecutionMode, (mode) => {
      this.durableExecutionMode = mode;
    });
  }
  getDurableLoggingContext() {
    return {
      getDurableLogData: () => {
        const activeContext = getActiveContext();
        const execution = activeContext?.execution ?? {
          executionArn: this._executionContext.durableExecutionArn,
          requestId: this._executionContext.requestId,
          tenantId: this._executionContext.tenantId
        };
        const result = {
          executionArn: execution.executionArn,
          requestId: execution.requestId,
          tenantId: execution.tenantId,
          operationId: !activeContext || activeContext?.contextId === "root" ? void 0 : hashId(activeContext.contextId)
        };
        if (activeContext && activeContext.contextId !== "root" && activeContext.operationName !== void 0) {
          result.operationName = activeContext.operationName;
        }
        if (activeContext?.attempt !== void 0) {
          result.attempt = activeContext.attempt;
        }
        return result;
      },
      getLogEnrichment: () => {
        const execution = getActiveContext()?.execution;
        try {
          return execution ? execution.enrichLogContext?.() : this.durableExecution.plugin?.enrichLogContext?.();
        } catch {
          return void 0;
        }
      }
    };
  }
  shouldLog() {
    const activeContext = getActiveContext();
    if (!this.modeAwareLoggingEnabled || !activeContext) {
      return true;
    }
    if (activeContext.contextId === "root") {
      return this.durableExecutionMode === DurableExecutionMode.ExecutionMode;
    }
    return activeContext.durableExecutionMode === DurableExecutionMode.ExecutionMode;
  }
  createModeAwareLogger(logger) {
    const durableContextLogger = {
      warn: (...args) => {
        if (this.shouldLog()) {
          return logger.warn(...args);
        }
      },
      debug: (...args) => {
        if (this.shouldLog()) {
          return logger.debug(...args);
        }
      },
      info: (...args) => {
        if (this.shouldLog()) {
          return logger.info(...args);
        }
      },
      error: (...args) => {
        if (this.shouldLog()) {
          return logger.error(...args);
        }
      }
    };
    if ("log" in logger) {
      durableContextLogger.log = (level, ...args) => {
        if (this.shouldLog()) {
          return logger.log?.(level, ...args);
        }
      };
    }
    return durableContextLogger;
  }
  createStepId() {
    this._stepCounter++;
    return this._stepPrefix ? `${this._stepPrefix}-${this._stepCounter}` : `${this._stepCounter}`;
  }
  /**
   * Returns the step ID that the next {@link createStepId} call will mint,
   * WITHOUT advancing the counter. At operation boundaries (before the current
   * operation has claimed its ID) this is the ID of the current pending
   * operation — the one about to run.
   */
  peekStepId() {
    const nextCounter = this._stepCounter + 1;
    return this._stepPrefix ? `${this._stepPrefix}-${nextCounter}` : `${nextCounter}`;
  }
  /**
   * Advances this context's step cursor by one without running an operation.
   *
   * Used by the concurrent-execution handler during summarized replay: when it
   * reconstructs a batch it reaches this method on the map/parallel child
   * context (via a narrow internal cast) to skip an item it does not
   * re-execute — one that was never started, or an in-flight item rebuilt as
   * STARTED. Advancing THIS context's cursor keeps the next terminal item's
   * runInChildContext aligned with its own step, so the non-resolving-promise
   * gate does not fire on the pending in-flight step (issue #751).
   * @internal
   */
  skipNextOperation() {
    this._stepCounter++;
  }
  checkAndUpdateReplayMode() {
    if (this.durableExecutionMode === DurableExecutionMode.ReplayMode) {
      const pendingStepId = this.peekStepId();
      const pendingStepData = this._executionContext.getStepData(pendingStepId);
      const hasCheckpointedChild = !pendingStepData && this._executionContext.getStepData(`${pendingStepId}-1`) !== void 0;
      if (!pendingStepData && !hasCheckpointedChild) {
        this.durableExecutionMode = DurableExecutionMode.ExecutionMode;
      }
    }
  }
  captureExecutionState() {
    const wasInReplayMode = this.durableExecutionMode === DurableExecutionMode.ReplayMode;
    const pendingStepId = this.peekStepId();
    const stepData = this._executionContext.getStepData(pendingStepId);
    const wasNotFinished = !!(stepData && stepData.Status !== OperationStatus.SUCCEEDED && stepData.Status !== OperationStatus.FAILED);
    return wasInReplayMode && wasNotFinished;
  }
  checkForNonResolvingPromise() {
    if (this.durableExecutionMode === DurableExecutionMode.ReplaySucceededContext) {
      const pendingStepId = this.peekStepId();
      const pendingStepData = this._executionContext.getStepData(pendingStepId);
      if (pendingStepData && pendingStepData.Status !== OperationStatus.SUCCEEDED && pendingStepData.Status !== OperationStatus.FAILED) {
        return new Promise(() => {
        });
      }
    }
    return null;
  }
  withModeManagement(operation) {
    return this.modeManagement.withModeManagement(operation);
  }
  withDurableModeManagement(operation) {
    return this.modeManagement.withDurableModeManagement(operation);
  }
  step(nameOrFn, fnOrOptions, maybeOptions) {
    return this.stepInternal(void 0, nameOrFn, fnOrOptions, maybeOptions);
  }
  /**
   * {@link step} variant that also labels the span with a plugin-only name.
   * Never checkpointed. See {@link InternalDurableContext}.
   * @internal
   */
  _stepWithPluginOperationName(pluginOperationName, nameOrFn, fnOrOptions, maybeOptions) {
    return this.stepInternal(pluginOperationName, nameOrFn, fnOrOptions, maybeOptions);
  }
  stepInternal(pluginOperationName, nameOrFn, fnOrOptions, maybeOptions) {
    validateContextUsage(this._stepPrefix, "step", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const stepHandler = createStepHandler(this._executionContext, this.checkpoint, this.lambdaContext, this.createStepId.bind(this), this.durableLogger, this._parentId, () => this._defaultSerdes, this.durableExecution.plugin, pluginOperationName);
      return stepHandler(nameOrFn, fnOrOptions, maybeOptions);
    });
  }
  invoke(nameOrFuncId, funcIdOrInput, inputOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "invoke", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const invokeHandler = createInvokeHandler(this._executionContext, this.checkpoint, this.createStepId.bind(this), this._parentId, this.checkAndUpdateReplayMode.bind(this), () => this._defaultSerdes, this.durableExecution.plugin);
      return invokeHandler(...[
        nameOrFuncId,
        funcIdOrInput,
        inputOrConfig,
        maybeConfig
      ]);
    });
  }
  runInChildContext(nameOrFn, fnOrOptions, maybeOptions) {
    validateContextUsage(this._stepPrefix, "runInChildContext", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const { options: childOptions } = resolveChildArgs(nameOrFn, fnOrOptions, maybeOptions);
      const isVirtualChild = childOptions?.virtualContext === true;
      const childPreserveDepth = isVirtualChild ? this._preserveChildDepth : this._preserveChildDepth === Infinity ? Infinity : Math.max(0, this._preserveChildDepth - 1);
      const blockHandler = createRunInChildContextHandler(
        this._executionContext,
        this.checkpoint,
        this.lambdaContext,
        this.createStepId.bind(this),
        () => this.durableLogger,
        // Adapter function to maintain compatibility
        (executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, _checkpointToken, parentId) => {
          const childCtx = createDurableContext(executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, this.durableExecution, parentId, childPreserveDepth);
          childCtx.configureSerdes({
            defaultSerdes: this._defaultSerdes,
            ...this._customCallbackDeserializerSet && {
              defaultCallbackDeserializer: this._defaultCallbackDeserializer
            }
          });
          return childCtx;
        },
        this._parentId,
        () => this._defaultSerdes,
        this.durableExecution.plugin,
        childPreserveDepth
      );
      return blockHandler(nameOrFn, fnOrOptions, maybeOptions);
    });
  }
  wait(nameOrDuration, maybeDuration) {
    validateContextUsage(this._stepPrefix, "wait", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const waitHandler = createWaitHandler(this._executionContext, this.checkpoint, this.createStepId.bind(this), this._parentId, this.checkAndUpdateReplayMode.bind(this), this.durableExecution.plugin);
      return typeof nameOrDuration === "string" ? waitHandler(nameOrDuration, maybeDuration) : waitHandler(nameOrDuration);
    });
  }
  /**
   * Configure logger behavior for this context
   *
   * This method allows partial configuration - only the properties provided will be updated.
   * For example, calling configureLogger(\{ modeAware: false \}) will only change the modeAware
   * setting without affecting any previously configured custom logger.
   *
   * @param config - Logger configuration options including customLogger and modeAware settings (default: modeAware=true)
   * @example
   * // Set custom logger and enable mode-aware logging
   * context.configureLogger(\{ customLogger: myLogger, modeAware: true \});
   *
   * // Later, disable mode-aware logging without changing the custom logger
   * context.configureLogger(\{ modeAware: false \});
   */
  configureLogger(config) {
    if (config.customLogger !== void 0) {
      this.durableLogger = config.customLogger;
      this.durableLogger.configureDurableLoggingContext?.(this.getDurableLoggingContext());
      this.logger = this.createModeAwareLogger(this.durableLogger);
    }
    if (config.modeAware !== void 0) {
      this.modeAwareLoggingEnabled = config.modeAware;
    }
  }
  configureSerdes(config) {
    if (config.defaultSerdes !== void 0) {
      this._defaultSerdes = config.defaultSerdes;
    }
    if (config.defaultCallbackDeserializer !== void 0) {
      this._defaultCallbackDeserializer = config.defaultCallbackDeserializer;
      this._customCallbackDeserializerSet = true;
    }
  }
  createCallback(nameOrConfig, maybeConfig) {
    return this.createCallbackInternal(void 0, nameOrConfig, maybeConfig);
  }
  /**
   * {@link createCallback} variant that also labels the span with a
   * plugin-only name. Never checkpointed. See {@link InternalDurableContext}.
   * @internal
   */
  _createCallbackWithPluginOperationName(pluginOperationName, nameOrConfig, maybeConfig) {
    return this.createCallbackInternal(pluginOperationName, nameOrConfig, maybeConfig);
  }
  createCallbackInternal(pluginOperationName, nameOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "createCallback", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const callbackFactory = createCallback(this._executionContext, this.checkpoint, this.createStepId.bind(this), this.checkAndUpdateReplayMode.bind(this), this._parentId, () => this._defaultCallbackDeserializer, this.durableExecution.plugin, pluginOperationName);
      return callbackFactory(nameOrConfig, maybeConfig);
    });
  }
  waitForCallback(nameOrSubmitter, submitterOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "waitForCallback", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const waitForCallbackHandler = createWaitForCallbackHandler(
        this._executionContext,
        this.checkpoint,
        this.peekStepId.bind(this),
        this.runInChildContext.bind(this),
        // Only pass the getter when the user has explicitly configured a custom
        // deserializer. The default is createPassThroughSerdes() which matches
        // the original behavior, so no injection is needed in that case.
        this._customCallbackDeserializerSet ? () => this._defaultCallbackDeserializer : void 0
      );
      return waitForCallbackHandler(nameOrSubmitter, submitterOrConfig, maybeConfig);
    });
  }
  waitForCondition(nameOrCheckFunc, checkFuncOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "waitForCondition", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const waitForConditionHandler = createWaitForConditionHandler(this._executionContext, this.checkpoint, this.createStepId.bind(this), this.durableLogger, this._parentId, () => this._defaultSerdes, this.durableExecution.plugin);
      return typeof nameOrCheckFunc === "string" || nameOrCheckFunc === void 0 ? waitForConditionHandler(nameOrCheckFunc, checkFuncOrConfig, maybeConfig) : waitForConditionHandler(nameOrCheckFunc, checkFuncOrConfig);
    });
  }
  map(nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "map", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const mapHandler = createMapHandler(this._executionContext, this._executeConcurrently.bind(this));
      return mapHandler(nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig);
    });
  }
  parallel(nameOrBranches, branchesOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "parallel", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const parallelHandler = createParallelHandler(this._executionContext, this._executeConcurrently.bind(this));
      return parallelHandler(nameOrBranches, branchesOrConfig, maybeConfig);
    });
  }
  _executeConcurrently(nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "_executeConcurrently", this._executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const concurrentExecutionHandler = createConcurrentExecutionHandler(this._executionContext, this.runInChildContext.bind(this), () => this._defaultSerdes);
      const promise = concurrentExecutionHandler(nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig);
      promise?.catch(() => {
      });
      return promise;
    });
  }
  get promise() {
    return createPromiseHandler(this.runInChildContext.bind(this));
  }
};
var createDurableContext = (executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId, preserveChildDepth = 0) => {
  return new DurableContextImpl(executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId, preserveChildDepth);
};
var CheckpointUnrecoverableInvocationError = class extends UnrecoverableInvocationError {
  terminationReason = TerminationReason.CHECKPOINT_FAILED;
  constructor(message, originalError) {
    super(message || "Checkpoint operation failed", originalError);
  }
};
var CheckpointUnrecoverableExecutionError = class extends UnrecoverableExecutionError {
  terminationReason = TerminationReason.CHECKPOINT_FAILED;
  constructor(message, originalError) {
    super(message || "Checkpoint operation failed", originalError);
  }
};
var NON_RETRYABLE_CUSTOMER_ERRORS = /* @__PURE__ */ new Set([
  "KMSAccessDeniedException",
  "KMSDisabledException",
  "KMSInvalidStateException",
  "KMSNotFoundException"
]);
function isNonRetryableCustomerError(error) {
  const name = error?.name;
  return !!name && NON_RETRYABLE_CUSTOMER_ERRORS.has(name);
}
var DurableExecutionClientErrorScope = {
  /**
   * The current invocation cannot continue, but the execution can resume in a new one.
   * Appropriate for transient conditions: timeouts, throttling, connection failures, or a
   * backend returning a server-side error.
   */
  INVOCATION: "INVOCATION",
  /**
   * The execution cannot proceed at all and must fail. Appropriate for conditions that
   * retrying cannot resolve: a rejected request, missing permissions, an unknown or
   * finished execution, or misconfiguration.
   */
  EXECUTION: "EXECUTION"
};
function isDurableExecutionClientError(error) {
  if (!(error instanceof Error) || !("isDurableExecutionClientError" in error)) {
    return false;
  }
  const candidate = error;
  return candidate.isDurableExecutionClientError === true && (candidate.scope === DurableExecutionClientErrorScope.INVOCATION || candidate.scope === DurableExecutionClientErrorScope.EXECUTION);
}
var toDate = (timestamp) => {
  if (timestamp === void 0) {
    return void 0;
  }
  if (timestamp instanceof Date) {
    return Number.isNaN(timestamp.getTime()) ? void 0 : timestamp;
  }
  const parsed = new Date(timestamp);
  return Number.isNaN(parsed.getTime()) ? void 0 : parsed;
};
var normalizeOperation = (operation) => {
  const { StartTimestamp, EndTimestamp, StepDetails, WaitDetails, ...rest } = operation;
  const normalized = {
    ...rest,
    StartTimestamp: toDate(StartTimestamp)
  };
  if ("EndTimestamp" in operation) {
    normalized.EndTimestamp = toDate(EndTimestamp);
  }
  if (StepDetails !== void 0) {
    normalized.StepDetails = {
      ...StepDetails,
      NextAttemptTimestamp: toDate(StepDetails.NextAttemptTimestamp)
    };
  } else if ("StepDetails" in operation) {
    normalized.StepDetails = StepDetails;
  }
  if (WaitDetails !== void 0) {
    normalized.WaitDetails = {
      ...WaitDetails,
      ScheduledEndTimestamp: toDate(WaitDetails.ScheduledEndTimestamp)
    };
  } else if ("WaitDetails" in operation) {
    normalized.WaitDetails = WaitDetails;
  }
  return normalized;
};
var normalizeOperations = (operations) => operations.map(normalizeOperation);
var STEP_DATA_UPDATED_EVENT = "stepDataUpdated";
var TERMINAL_STATUSES = [
  OperationStatus.SUCCEEDED,
  OperationStatus.CANCELLED,
  OperationStatus.FAILED,
  OperationStatus.STOPPED,
  OperationStatus.TIMED_OUT
];
var CheckpointManager = class {
  durableExecutionArn;
  stepData;
  storage;
  terminationManager;
  stepDataEmitter;
  logger;
  finishedAncestors;
  plugin;
  requestId;
  getRemainingTimeMs;
  queue = [];
  isProcessing = false;
  currentTaskToken;
  forceCheckpointPromises = [];
  queueCompletionResolver = null;
  MAX_PAYLOAD_SIZE = 750 * 1024;
  // 750KB in bytes
  MAX_ITEMS_IN_BATCH = 250;
  isTerminating = false;
  disposed = false;
  /**
   * Set once the service answers a checkpoint without a token. See
   * {@link CheckpointManager.handleRevokedCheckpointToken}.
   */
  checkpointTokenRevoked = false;
  // Operation lifecycle tracking
  operations = /* @__PURE__ */ new Map();
  // Reverse index: hashed step ID → original operations-map key. Keeps
  // resolveWaitingOperation O(1) instead of hashing every tracked operation.
  hashedIdIndex = /* @__PURE__ */ new Map();
  // Termination cooldown
  terminationTimer = null;
  terminationReason = null;
  constructor(durableExecutionArn, stepData, storage, terminationManager, initialTaskToken, stepDataEmitter, logger, finishedAncestors, plugin, requestId, getRemainingTimeMs) {
    this.durableExecutionArn = durableExecutionArn;
    this.stepData = stepData;
    this.storage = storage;
    this.terminationManager = terminationManager;
    this.stepDataEmitter = stepDataEmitter;
    this.logger = logger;
    this.finishedAncestors = finishedAncestors;
    this.plugin = plugin;
    this.requestId = requestId;
    this.getRemainingTimeMs = getRemainingTimeMs;
    this.currentTaskToken = initialTaskToken;
  }
  setTerminating() {
    this.isTerminating = true;
    log("\u{1F6D1}", "Checkpoint manager marked as terminating");
  }
  /**
   * Whether the service has withdrawn this invocation's checkpoint token. Once it has, the
   * invocation can record nothing further, including its own result. See
   * {@link CheckpointManager.handleRevokedCheckpointToken}.
   */
  isCheckpointTokenRevoked() {
    return this.checkpointTokenRevoked;
  }
  /**
   * Releases everything this manager armed, and refuses to arm anything further.
   *
   * Timers outlive the invocation that armed them. Nothing else clears them on the normal
   * path: cleanupAllOperations is only reached through executeTermination, and
   * setTerminating merely sets a flag, so a handler that completes without suspending
   * returns with its poll timers still pending. In a reused execution environment those
   * fire during a later invocation and checkpoint against a task token that has since been
   * replaced. Bounding timers by the reported deadline narrows this but cannot close it: a
   * timer armed for five minutes is legitimate right up until the handler returns after ten
   * seconds, and where no deadline is reported a timer can be armed for as long as
   * MAX_TIMER_DELAY_MS allows.
   *
   * Deliberately per-manager rather than a module-level "current invocation" marker. A
   * process-wide marker identifies the newest invocation rather than a particular execution,
   * and executions already run concurrently in one process -- the local test runner's factory
   * creates nested runners for exactly that. Such a marker would make an earlier execution's
   * manager stale, silently stopping its polling while leaving its operations awaited and
   * unresolved. State on the manager cannot conflate two executions, because each invocation
   * has its own.
   *
   * Idempotent.
   */
  dispose() {
    if (this.disposed)
      return;
    this.disposed = true;
    if (this.terminationTimer) {
      clearTimeout(this.terminationTimer);
      this.terminationTimer = null;
      this.terminationReason = null;
    }
    this.cleanupAllOperations();
    log("\u{1F9F9}", "Checkpoint manager disposed");
  }
  /**
   * Mark an ancestor as finished (for run-in-child-context operations)
   */
  markAncestorFinished(stepId) {
    this.finishedAncestors.add(stepId);
  }
  /**
   * Extract parent ID from hierarchical stepId (e.g., "1-2-3" -\> "1-2")
   */
  getParentId(stepId) {
    const lastDashIndex = stepId.lastIndexOf("-");
    return lastDashIndex > 0 ? stepId.substring(0, lastDashIndex) : void 0;
  }
  /**
   * Checks if any ancestor of the given stepId is finished
   * Only applies to operations that are descendants of run-in-child-context operations
   */
  hasFinishedAncestor(stepId) {
    let currentParentId = this.getParentId(stepId);
    while (currentParentId) {
      if (this.finishedAncestors.has(currentParentId)) {
        return true;
      }
      currentParentId = this.getParentId(currentParentId);
    }
    return false;
  }
  async forceCheckpoint() {
    if (this.isTerminating) {
      log("\u26A0\uFE0F", "Force checkpoint skipped - termination in progress");
      return new Promise(() => {
      });
    }
    return new Promise((resolve, reject) => {
      this.forceCheckpointPromises.push({ resolve, reject });
      if (!this.isProcessing) {
        setImmediate(() => {
          this.processQueue();
        });
      }
    });
  }
  async waitForQueueCompletion() {
    if (this.queue.length === 0 && !this.isProcessing) {
      return;
    }
    return new Promise((resolve) => {
      this.queueCompletionResolver = resolve;
    });
  }
  clearQueue() {
    const abandoned = this.queue;
    this.queue = [];
    this.forceCheckpointPromises = [];
    this.notifyQueueCompletion();
    this.notifyAbandoned(abandoned);
  }
  /**
   * Tells the callers that asked to hear about it that their updates were never sent.
   *
   * Without this, such a caller waits for a promise nothing settles. That is the intended
   * outcome for handler code, because the termination ends the invocation instead. It is not
   * the outcome for a caller that runs after the handler has settled: nothing else will end
   * its wait, so the invocation would run until Lambda stops it.
   */
  notifyAbandoned(items) {
    for (const item of items) {
      item.onAbandon?.();
    }
  }
  // Alias for backward compatibility with Checkpoint interface
  async force() {
    return this.forceCheckpoint();
  }
  /**
   * Sends the execution's own terminal update and reports whether the service accepted it.
   *
   * For `withDurableExecution`'s oversized-result path, which checkpoints the handler's
   * result after the handler has returned. That caller is past the point where a termination
   * can end its wait, so it needs an answer in every case rather than a promise that another
   * path settles.
   *
   * Returns `"sent"` once the service has accepted the update. The execution is then
   * recorded as finished, whatever else has happened in this invocation, so the caller
   * reports success. A termination that arrived while the update was in flight does not
   * change that.
   *
   * Returns `"abandoned"` when the manager cannot send the update: it is already
   * terminating, the token is already withdrawn, or the queue was cleared before the update
   * went out. The termination details are set by then, so the caller decides its answer from
   * the termination reason.
   */
  async checkpointExecutionResult(stepId, data) {
    if (this.isTerminating || this.checkpointTokenRevoked) {
      log("\u26A0\uFE0F", "Execution result not checkpointed - manager is terminating:", {
        stepId,
        checkpointTokenRevoked: this.checkpointTokenRevoked
      });
      return "abandoned";
    }
    return new Promise((resolve, reject) => {
      const queuedItem = {
        stepId,
        data,
        sizeBytes: Buffer.byteLength(JSON.stringify({ stepId, data }), "utf8"),
        resolve: () => {
          resolve("sent");
        },
        reject: (error) => {
          reject(error);
        },
        onAbandon: () => {
          log("\u26A0\uFE0F", "Execution result was never sent:", { stepId });
          resolve("abandoned");
        }
      };
      this.queue.push(queuedItem);
      if (!this.isProcessing) {
        setImmediate(() => {
          this.processQueue();
        });
      }
    });
  }
  async checkpoint(stepId, data) {
    if (this.isTerminating) {
      log("\u26A0\uFE0F", "Checkpoint skipped - termination in progress:", { stepId });
      return new Promise(() => {
      });
    }
    if (this.hasFinishedAncestor(stepId)) {
      log("\u26A0\uFE0F", "Checkpoint skipped - ancestor already finished:", { stepId });
      this.releaseAbandonedOperation(stepId, data);
      return new Promise(() => {
      });
    }
    return new Promise((resolve, reject) => {
      const queuedItem = {
        stepId,
        data,
        // Same shape the previous per-batch estimation serialized (functions
        // were dropped by JSON.stringify), computed once instead of on every
        // processQueue pass. Buffer.byteLength avoids allocating an encoded
        // copy just to measure it.
        sizeBytes: Buffer.byteLength(JSON.stringify({ stepId, data }), "utf8"),
        resolve: () => {
          resolve();
        },
        reject: (error) => {
          reject(error);
        }
      };
      this.queue.push(queuedItem);
      log("\u{1F4E5}", "Checkpoint queued:", () => ({
        stepId,
        queueLength: this.queue.length,
        isProcessing: this.isProcessing
      }));
      if (!this.isProcessing) {
        setImmediate(() => {
          this.processQueue();
        });
      }
    });
  }
  classifyCheckpointError(error) {
    const originalError = error instanceof Error ? error : new Error(String(error));
    if (isDurableExecutionClientError(error)) {
      log("\u{1F50D}", "Classifying checkpoint error from client-stated scope:", {
        scope: error.scope,
        errorName: error.name,
        errorMessage: error.message
      });
      return error.scope === DurableExecutionClientErrorScope.EXECUTION ? new CheckpointUnrecoverableExecutionError(`Checkpoint failed: ${error.message}`, originalError) : new CheckpointUnrecoverableInvocationError(`Checkpoint failed: ${error.message}`, originalError);
    }
    const awsError = error;
    const statusCode = awsError.$metadata?.httpStatusCode;
    const errorName = awsError.name;
    const errorMessage2 = awsError.message || originalError.message;
    log("\u{1F50D}", "Classifying checkpoint error:", {
      statusCode,
      errorName,
      errorMessage: errorMessage2
    });
    const is4xxStatusCode = statusCode && statusCode >= 400 && statusCode < 500;
    if (is4xxStatusCode && errorName === "InvalidParameterValueException" && errorMessage2.startsWith("Invalid checkpoint token")) {
      return new CheckpointUnrecoverableInvocationError(`Checkpoint failed: ${errorMessage2}`, originalError);
    }
    if (is4xxStatusCode && statusCode !== 429) {
      return new CheckpointUnrecoverableExecutionError(`Checkpoint failed: ${errorMessage2}`, originalError);
    }
    if (isNonRetryableCustomerError(error)) {
      return new CheckpointUnrecoverableExecutionError(`Checkpoint failed: ${errorMessage2}`, originalError);
    }
    return new CheckpointUnrecoverableInvocationError(`Checkpoint failed: ${errorMessage2}`, originalError);
  }
  async processQueue() {
    if (this.isProcessing) {
      return;
    }
    if (this.checkpointTokenRevoked) {
      log("\u26A0\uFE0F", "Checkpoint skipped - checkpoint token was withdrawn", {
        queueLength: this.queue.length
      });
      this.clearQueue();
      return;
    }
    const hasQueuedItems = this.queue.length > 0;
    const hasForceRequests = this.forceCheckpointPromises.length > 0;
    if (!hasQueuedItems && !hasForceRequests) {
      return;
    }
    this.isProcessing = true;
    const batch = [];
    const baseSize = this.currentTaskToken.length + 100;
    let currentSize = baseSize;
    let consumed = 0;
    while (consumed < this.queue.length) {
      const nextItem = this.queue[consumed];
      if ((currentSize + nextItem.sizeBytes > this.MAX_PAYLOAD_SIZE || batch.length >= this.MAX_ITEMS_IN_BATCH) && batch.length > 0) {
        break;
      }
      batch.push(nextItem);
      currentSize += nextItem.sizeBytes;
      consumed++;
    }
    if (consumed > 0) {
      this.queue = this.queue.slice(consumed);
    }
    log("\u{1F504}", "Processing checkpoint batch:", () => ({
      batchSize: batch.length,
      remainingInQueue: this.queue.length,
      estimatedSize: currentSize,
      maxSize: this.MAX_PAYLOAD_SIZE
    }));
    try {
      if (batch.length > 0 || this.forceCheckpointPromises.length > 0) {
        await this.processBatch(batch);
      }
      if (this.checkpointTokenRevoked) {
        return;
      }
      batch.forEach((item) => {
        item.resolve();
      });
      const forcePromises = this.forceCheckpointPromises.splice(0);
      forcePromises.forEach((promise) => {
        promise.resolve();
      });
      log("\u2705", "Checkpoint batch processed successfully:", {
        batchSize: batch.length,
        forceRequests: forcePromises.length,
        newTaskToken: this.currentTaskToken
      });
    } catch (error) {
      log("\u274C", "Checkpoint batch failed:", {
        batchSize: batch.length,
        error
      });
      const checkpointError = this.classifyCheckpointError(error);
      this.clearQueue();
      this.terminationManager.terminate({
        reason: TerminationReason.CHECKPOINT_FAILED,
        message: checkpointError.message,
        error: checkpointError
      });
      this.notifyAbandoned(batch);
    } finally {
      this.isProcessing = false;
      if (this.queue.length > 0) {
        setImmediate(() => {
          this.processQueue();
        });
      } else {
        this.notifyQueueCompletion();
        if (!this.terminationTimer) {
          this.checkAndTerminate();
        }
      }
    }
  }
  notifyQueueCompletion() {
    if (this.queueCompletionResolver) {
      this.queueCompletionResolver();
      this.queueCompletionResolver = null;
    }
  }
  async processBatch(batch) {
    const updates = batch.map((item) => {
      const hashedStepId = hashId(item.stepId);
      const update = {
        Type: item.data.Type || "STEP",
        Action: item.data.Action || "START",
        ...item.data,
        Id: hashedStepId,
        ...item.data.ParentId && { ParentId: hashId(item.data.ParentId) }
      };
      return update;
    });
    const checkpointData = {
      DurableExecutionArn: this.durableExecutionArn,
      CheckpointToken: this.currentTaskToken,
      Updates: updates
    };
    log("\u23FA\uFE0F", "Creating checkpoint batch:", () => ({
      batchSize: updates.length,
      checkpointToken: this.currentTaskToken,
      updates: updates.map((u) => ({
        Id: u.Id,
        Action: u.Action,
        Type: u.Type
      }))
    }));
    const response = await this.storage.checkpoint(checkpointData, this.logger);
    if (!response.CheckpointToken) {
      if (updates.some((update) => update.Type === OperationType.EXECUTION)) {
        log("\u2139\uFE0F", "No CheckpointToken after the execution's terminal update");
        return;
      }
      this.handleRevokedCheckpointToken();
      return;
    }
    this.currentTaskToken = response.CheckpointToken;
    if (response.NewExecutionState?.Operations) {
      await this.updateStepDataFromCheckpointResponse(normalizeOperations(response.NewExecutionState.Operations));
    }
  }
  /**
   * Ends the invocation when the service answers a checkpoint without a token.
   *
   * Each checkpoint response carries the token for the next one. A response without one
   * withdraws this invocation's ability to record anything further: the token just spent is
   * consumed, and sending it again earns `InvalidParameterValueException: Invalid checkpoint
   * token`. Before this, the manager kept the spent token and did exactly that, turning a
   * condition it could recognise into a Lambda error one call later.
   *
   * The checkpoint that prompted this response was accepted, so the updates in it are
   * durable. In-flight operations are not: they are abandoned rather than checkpointed, and
   * replay on the next invocation. That is correct for AT_LEAST_ONCE. An AT_MOST_ONCE step
   * whose START reached the last accepted checkpoint will not run again, which is what
   * AT_MOST_ONCE means.
   *
   * `NewExecutionState` from this response is deliberately not applied, and the callers of
   * the accepted batch are deliberately not resolved. Either one lets the handler run on --
   * start its next step, or reach a result -- past the point where the service can be told
   * about any of it, so that work runs for nothing and then again on the next invocation.
   * Terminating instead keeps the invocation's answer to PENDING, which is the only answer
   * left that is true.
   *
   * A batch carrying the execution's own terminal update never reaches here: see the
   * EXECUTION check in processBatch.
   */
  handleRevokedCheckpointToken() {
    this.checkpointTokenRevoked = true;
    const message = "Checkpoint response contained no CheckpointToken: the service will accept no further checkpoints from this invocation. Suspending; the execution continues on the next invocation.";
    this.logger.warn(message, {
      durableExecutionArn: this.durableExecutionArn,
      requestId: this.requestId
    });
    log("\u{1F6D1}", "Checkpoint token withdrawn by service - suspending invocation", {
      durableExecutionArn: this.durableExecutionArn
    });
    this.clearQueue();
    this.terminationManager.terminate({
      reason: TerminationReason.EXECUTION_SUSPENDED_BY_SERVICE,
      message
    });
  }
  async updateStepDataFromCheckpointResponse(operations) {
    log("\u{1F504}", "Updating stepData from checkpoint response:", () => ({
      operationCount: operations.length,
      operationIds: operations.map((op) => op.Id).filter(Boolean)
    }));
    const updatedOperations = {};
    operations.forEach((operation) => {
      if (operation.Id) {
        const oldStatus = this.stepData[operation.Id]?.Status;
        const newStatus = operation.Status;
        this.stepData[operation.Id] = operation;
        log("\u{1F4DD}", "Updated stepData entry:", operation);
        this.stepDataEmitter.emit(STEP_DATA_UPDATED_EVENT, operation.Id);
        if (oldStatus !== newStatus) {
          this.resolveWaitingOperation(operation.Id);
          updatedOperations[operation.Id] = operation;
        }
      }
    });
    if (Object.keys(updatedOperations).length > 0 && this.plugin.onOperationChange) {
      await this.plugin.onOperationChange({
        executionArn: this.durableExecutionArn,
        updatedOperations: toOperationInfoMap(updatedOperations),
        operations: toOperationInfoMap(this.stepData)
      });
    }
    log("\u2705", "StepData update completed:", {
      totalStepDataEntries: Object.keys(this.stepData).length
    });
  }
  resolveWaitingOperation(hashedStepId) {
    const stepId = this.hashedIdIndex.get(hashedStepId);
    if (stepId === void 0) {
      return;
    }
    const op = this.operations.get(stepId);
    if (op?.resolver) {
      log("\u2705", `Resolving waiting operation ${stepId} due to status change`);
      op.resolver();
      op.resolver = void 0;
      if (op.timer) {
        clearTimeout(op.timer);
        op.timer = void 0;
      }
    }
  }
  getQueueStatus() {
    return {
      queueLength: this.queue.length,
      isProcessing: this.isProcessing
    };
  }
  // ===== New Lifecycle & Termination Methods =====
  markOperationState(stepId, state, options) {
    let op = this.operations.get(stepId);
    if (!op) {
      if (!options?.metadata) {
        throw new Error(`metadata required on first call for ${stepId}`);
      }
      op = {
        stepId,
        state,
        metadata: options.metadata,
        endTimestamp: options.endTimestamp
      };
      this.operations.set(stepId, op);
      this.hashedIdIndex.set(hashId(stepId), stepId);
    } else {
      op.state = state;
      if (options?.endTimestamp !== void 0) {
        op.endTimestamp = options.endTimestamp;
      }
    }
    if (state === OperationLifecycleState.COMPLETED) {
      this.cleanupOperation(stepId);
    }
    if (state !== OperationLifecycleState.IDLE_NOT_AWAITED) {
      this.checkAndTerminate();
    }
  }
  waitForRetryTimer(stepId) {
    const op = this.operations.get(stepId);
    if (!op) {
      throw new Error(`Operation ${stepId} not found`);
    }
    if (op.state !== OperationLifecycleState.RETRY_WAITING) {
      throw new Error(`Operation ${stepId} must be in RETRY_WAITING state, got ${op.state}`);
    }
    const stepData = this.stepData[hashId(stepId)];
    if (stepData?.Status && TERMINAL_STATUSES.includes(stepData.Status)) {
      return Promise.resolve();
    }
    this.startTimerWithPolling(stepId, op.endTimestamp);
    return new Promise((resolve) => {
      op.resolver = resolve;
    });
  }
  waitForStatusChange(stepId) {
    const op = this.operations.get(stepId);
    if (!op) {
      throw new Error(`Operation ${stepId} not found`);
    }
    if (op.state !== OperationLifecycleState.IDLE_AWAITED) {
      throw new Error(`Operation ${stepId} must be in IDLE_AWAITED state, got ${op.state}`);
    }
    const stepData = this.stepData[hashId(stepId)];
    if (stepData?.Status && TERMINAL_STATUSES.includes(stepData.Status)) {
      return Promise.resolve();
    }
    this.startTimerWithPolling(stepId, op.endTimestamp);
    return new Promise((resolve) => {
      op.resolver = resolve;
    });
  }
  markOperationAwaited(stepId) {
    const op = this.operations.get(stepId);
    if (!op) {
      log("\u26A0\uFE0F", `Cannot mark operation as awaited: ${stepId} not found`);
      return;
    }
    if (op.state === OperationLifecycleState.IDLE_NOT_AWAITED) {
      op.state = OperationLifecycleState.IDLE_AWAITED;
      log("\u{1F4CD}", `Operation marked as awaited: ${stepId}`);
      this.checkAndTerminate();
    }
  }
  getOperationState(stepId) {
    return this.operations.get(stepId)?.state;
  }
  getAllOperations() {
    return new Map(this.operations);
  }
  // ===== Private Helper Methods =====
  /**
   * Stops counting an operation as EXECUTING after its checkpoint was dropped
   * because an ancestor finished, when the operation is parked on that
   * checkpoint.
   *
   * 1. The dropped checkpoint returns a promise that never settles.
   * 2. A step or waitForCondition awaits its SUCCEED, FAIL or RETRY checkpoint
   *    while it is EXECUTING. So it would stay EXECUTING for the rest of the
   *    invocation.
   * 3. Rule 4 of shouldTerminate blocks suspension while any operation is
   *    EXECUTING. Rule 5 cleans up only waiting and idle operations.
   * 4. So a later wait or callback could not suspend the invocation, and the
   *    invocation would run until the Lambda timeout.
   *
   * The finished ancestor never reads this operation's outcome. So the parked
   * operation is marked COMPLETED. It stays in the map, so a later
   * markOperationState call for it still finds its metadata.
   *
   * Two kinds of caller do not wait for the checkpoint. They keep running, so
   * they must stay EXECUTING until they settle (AGENTS.md invariants 1 and 2):
   *
   * - A child context queues every checkpoint without waiting, then runs
   *   plugin hooks and deserializes its result. Its own code marks it
   *   COMPLETED when it settles.
   * - A START checkpoint is queued without waiting by a step or
   *   waitForCondition that then runs its function.
   *
   * So only the awaited actions of non-context operations are released.
   */
  releaseAbandonedOperation(stepId, data) {
    const op = this.operations.get(stepId);
    if (op?.state !== OperationLifecycleState.EXECUTING) {
      return;
    }
    if (op.metadata.type === OperationType.CONTEXT) {
      return;
    }
    if (data.Action !== OperationAction.SUCCEED && data.Action !== OperationAction.FAIL && data.Action !== OperationAction.RETRY) {
      return;
    }
    this.markOperationState(stepId, OperationLifecycleState.COMPLETED);
  }
  cleanupOperation(stepId) {
    const op = this.operations.get(stepId);
    if (!op)
      return;
    if (op.timer) {
      clearTimeout(op.timer);
      op.timer = void 0;
    }
    op.resolver = void 0;
  }
  cleanupAllOperations() {
    for (const op of this.operations.values()) {
      if (op.timer) {
        clearTimeout(op.timer);
        op.timer = void 0;
      }
      op.resolver = void 0;
    }
  }
  /**
   * Determines if the function should terminate.
   * @returns TerminationReason if the function should terminate, or undefined if the function should not terminate
   */
  shouldTerminate() {
    if (this.queue.length > 0) {
      return void 0;
    }
    if (this.isProcessing) {
      return void 0;
    }
    if (this.forceCheckpointPromises.length > 0) {
      return void 0;
    }
    const allOps = Array.from(this.operations.values());
    const hasExecuting = allOps.some((op) => op.state === OperationLifecycleState.EXECUTING);
    if (hasExecuting) {
      return void 0;
    }
    for (const op of allOps) {
      if (op.state === OperationLifecycleState.RETRY_WAITING || op.state === OperationLifecycleState.IDLE_NOT_AWAITED || op.state === OperationLifecycleState.IDLE_AWAITED) {
        const originalStepId = op.metadata.stepId;
        if (this.hasFinishedAncestor(originalStepId)) {
          log("\u{1F9F9}", `Cleaning up operation with completed ancestor: ${originalStepId}`);
          this.cleanupOperation(op.stepId);
          this.operations.delete(op.stepId);
          this.hashedIdIndex.delete(hashId(op.stepId));
        }
      }
    }
    const remainingOps = Array.from(this.operations.values());
    const hasWaiting = remainingOps.some((op) => op.state === OperationLifecycleState.RETRY_WAITING || op.state === OperationLifecycleState.IDLE_NOT_AWAITED || op.state === OperationLifecycleState.IDLE_AWAITED);
    if (hasWaiting) {
      return this.determineTerminationReason(remainingOps);
    }
    return void 0;
  }
  checkAndTerminate() {
    if (this.checkpointTokenRevoked) {
      return;
    }
    const terminationReason = this.shouldTerminate();
    if (terminationReason) {
      this.scheduleTermination(terminationReason);
      return;
    }
    this.abortTermination();
  }
  abortTermination() {
    if (this.terminationTimer) {
      clearTimeout(this.terminationTimer);
      this.terminationTimer = null;
      this.terminationReason = null;
      log("\u{1F504}", "Termination aborted - conditions changed");
    }
  }
  scheduleTermination(reason) {
    if (this.terminationTimer && this.terminationReason === reason) {
      return;
    }
    this.abortTermination();
    this.terminationReason = reason;
    log("\u23F1\uFE0F", "Scheduling termination", {
      reason,
      cooldownMs: CHECKPOINT_TERMINATION_COOLDOWN_MS
    });
    this.terminationTimer = setTimeout(() => {
      if (!this.shouldTerminate()) {
        log("\u{1F504}", "Termination conditions no longer valid after cooldown, aborting termination");
        this.abortTermination();
        return;
      }
      this.executeTermination(reason);
    }, CHECKPOINT_TERMINATION_COOLDOWN_MS);
  }
  executeTermination(reason) {
    log("\u{1F6D1}", "Executing termination after cooldown", { reason });
    this.terminationTimer = null;
    this.terminationReason = null;
    this.cleanupAllOperations();
    this.terminationManager.terminate({ reason });
  }
  determineTerminationReason(ops) {
    if (ops.some((op) => op.state === OperationLifecycleState.RETRY_WAITING && op.metadata.type === OperationType.STEP)) {
      return TerminationReason.RETRY_SCHEDULED;
    }
    if (ops.some((op) => (op.state === OperationLifecycleState.IDLE_NOT_AWAITED || op.state === OperationLifecycleState.IDLE_AWAITED) && op.metadata.subType === "Wait")) {
      return TerminationReason.WAIT_SCHEDULED;
    }
    return TerminationReason.CALLBACK_PENDING;
  }
  startTimerWithPolling(stepId, endTimestamp) {
    if (this.disposed)
      return;
    const op = this.operations.get(stepId);
    if (!op)
      return;
    let delay;
    if (endTimestamp) {
      const timestamp = endTimestamp instanceof Date ? endTimestamp : new Date(endTimestamp);
      delay = Math.max(0, timestamp.getTime() - Date.now());
    } else {
      delay = INITIAL_POLL_DELAY_MS;
    }
    const schedulableDelayMs = Math.min(this.getRemainingTimeMs() - MIN_REMAINING_TIME_TO_POLL_MS, MAX_TIMER_DELAY_MS);
    if (delay > schedulableDelayMs) {
      return;
    }
    op.pollCount ??= 0;
    op.timer = setTimeout(() => {
      this.forceRefreshAndCheckStatus(stepId);
    }, delay);
  }
  async forceRefreshAndCheckStatus(stepId) {
    if (this.disposed)
      return;
    const op = this.operations.get(stepId);
    if (!op)
      return;
    const remainingTimeMs = this.getRemainingTimeMs();
    if (remainingTimeMs < MIN_REMAINING_TIME_TO_POLL_MS) {
      log("\u23F1\uFE0F", `Only ${remainingTimeMs}ms left in this invocation, stopping poll for ${stepId}`);
      if (op.timer) {
        clearTimeout(op.timer);
        op.timer = void 0;
      }
      return;
    }
    const oldStatus = this.stepData[hashId(stepId)]?.Status;
    await this.forceCheckpoint();
    const newStatus = this.stepData[hashId(stepId)]?.Status;
    if (newStatus !== oldStatus) {
      log("\u2705", `Status changed for ${stepId}: ${oldStatus} \u2192 ${newStatus}`);
      op.resolver?.();
      op.resolver = void 0;
      if (op.timer) {
        clearTimeout(op.timer);
        op.timer = void 0;
      }
    } else {
      op.pollCount = (op.pollCount || 0) + 1;
      const intervalCeilingMs = op.pollCount > POLLS_BEFORE_EXTENDED_INTERVAL ? EXTENDED_POLL_INTERVAL_CEILING_MS : POLL_INTERVAL_CEILING_MS;
      const nextDelay = Math.min(op.pollCount * 1e3, intervalCeilingMs);
      op.timer = setTimeout(() => {
        this.forceRefreshAndCheckStatus(stepId);
      }, nextDelay);
    }
  }
};
var TerminationManager = class extends import_events.EventEmitter {
  isTerminated = false;
  terminationDetails;
  resolveTermination;
  terminationPromise;
  setCheckpointTerminating;
  constructor(setCheckpointTerminating) {
    super();
    this.setCheckpointTerminating = setCheckpointTerminating;
    this.terminationPromise = new Promise((resolve) => {
      this.resolveTermination = resolve;
    });
  }
  setCheckpointTerminatingCallback(callback) {
    this.setCheckpointTerminating = callback;
  }
  terminate(options = {}) {
    if (this.isTerminated)
      return;
    this.setCheckpointTerminating?.();
    this.isTerminated = true;
    this.terminationDetails = {
      reason: options.reason ?? TerminationReason.OPERATION_TERMINATED,
      message: options.message ?? "Operation terminated",
      error: options.error,
      cleanup: options.cleanup
    };
    if (this.resolveTermination) {
      this.handleTermination(this.terminationDetails).then(this.resolveTermination);
    }
  }
  getTerminationPromise() {
    return this.terminationPromise;
  }
  async handleTermination(details) {
    if (details.cleanup) {
      try {
        await details.cleanup();
      } catch {
      }
    }
    return {
      reason: details.reason,
      message: details.message,
      error: details.error
    };
  }
};
var FORMAT_OPTIONS = { breakLength: Infinity };
var formatWithOptions = (options, ...args) => typeof import_node_util.default.formatWithOptions === "function" ? import_node_util.default.formatWithOptions(options, ...args) : import_node_util.default.format(...args);
function jsonErrorReplacer(_key, value) {
  if (value instanceof Error) {
    return Object.assign({
      errorType: value?.constructor?.name ?? "UnknownError",
      errorMessage: value.message,
      stackTrace: typeof value.stack === "string" ? value.stack.split("\n") : value.stack
    }, value);
  }
  return value;
}
function formatDurableLogData(level, logData, enrichLogContext, ...messageParams) {
  const result = {
    requestId: logData.requestId,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    level: level.toUpperCase(),
    executionArn: logData.executionArn
  };
  const tenantId = logData.tenantId;
  if (tenantId != null) {
    result.tenantId = tenantId;
  }
  if (logData.operationId !== void 0) {
    result.operationId = logData.operationId;
  }
  if (logData.operationName !== void 0) {
    result.operationName = logData.operationName;
  }
  if (logData.attempt !== void 0) {
    result.attempt = logData.attempt;
  }
  if (enrichLogContext) {
    try {
      const extra = enrichLogContext();
      if (extra) {
        Object.assign(result, extra);
      }
    } catch {
    }
  }
  if (messageParams.length === 1) {
    result.message = messageParams[0];
    try {
      return JSON.stringify(result, jsonErrorReplacer);
    } catch (_) {
      result.message = formatWithOptions(FORMAT_OPTIONS, result.message);
      return JSON.stringify(result);
    }
  }
  result.message = formatWithOptions(FORMAT_OPTIONS, ...messageParams);
  for (const param of messageParams) {
    if (param instanceof Error) {
      result.errorType = param?.constructor?.name ?? "UnknownError";
      result.errorMessage = param.message;
      result.stackTrace = typeof param.stack === "string" ? param.stack.split("\n") : [];
      break;
    }
  }
  return JSON.stringify(result);
}
var DefaultLogger = class {
  consoleLogger;
  durableLoggingContext = void 0;
  executionContext;
  enrichLogContext;
  noOpLog = () => {
  };
  constructor(executionContext, enrichLogContext) {
    this.executionContext = executionContext;
    this.enrichLogContext = enrichLogContext;
    this.consoleLogger = new import_node_console.Console({
      stdout: process.stdout,
      stderr: process.stderr
    });
    this.info = this.noOpLog;
    this.error = this.noOpLog;
    this.warn = this.noOpLog;
    this.debug = this.noOpLog;
    this.configureLogLevel();
  }
  configureLogLevel() {
    const levels = {
      DEBUG: { name: "DEBUG", priority: 2 },
      INFO: { name: "INFO", priority: 3 },
      WARN: { name: "WARN", priority: 4 },
      ERROR: { name: "ERROR", priority: 5 }
      // Not implemented yet. Can be implemented later
      // TRACE: { name: "TRACE", priority: 1 },
      // FATAL: { name: "FATAL", priority: 6 },
    };
    const logLevelEnvVariable = process.env["AWS_LAMBDA_LOG_LEVEL"]?.toUpperCase();
    const lambdaLogLevel = logLevelEnvVariable && logLevelEnvVariable in levels ? levels[logLevelEnvVariable] : levels.DEBUG;
    if (levels.DEBUG.priority >= lambdaLogLevel.priority) {
      this.debug = (message, ...optionalParams) => {
        const loggingContext = this.ensureDurableLoggingContext();
        const params = message !== void 0 ? [message, ...optionalParams] : optionalParams;
        this.consoleLogger.debug(formatDurableLogData(DurableLogLevel.DEBUG, loggingContext.getDurableLogData(), this.enrichLogContext, ...params));
      };
    }
    if (levels.INFO.priority >= lambdaLogLevel.priority) {
      this.info = (message, ...optionalParams) => {
        const loggingContext = this.ensureDurableLoggingContext();
        const params = message !== void 0 ? [message, ...optionalParams] : optionalParams;
        this.consoleLogger.info(formatDurableLogData(DurableLogLevel.INFO, loggingContext.getDurableLogData(), this.enrichLogContext, ...params));
      };
    }
    if (levels.WARN.priority >= lambdaLogLevel.priority) {
      this.warn = (message, ...optionalParams) => {
        const loggingContext = this.ensureDurableLoggingContext();
        const params = message !== void 0 ? [message, ...optionalParams] : optionalParams;
        this.consoleLogger.warn(formatDurableLogData(DurableLogLevel.WARN, loggingContext.getDurableLogData(), this.enrichLogContext, ...params));
      };
    }
    if (levels.ERROR.priority >= lambdaLogLevel.priority) {
      this.error = (message, ...optionalParams) => {
        const loggingContext = this.ensureDurableLoggingContext();
        const params = message !== void 0 ? [message, ...optionalParams] : optionalParams;
        this.consoleLogger.error(formatDurableLogData(DurableLogLevel.ERROR, loggingContext.getDurableLogData(), this.enrichLogContext, ...params));
      };
    }
  }
  ensureDurableLoggingContext() {
    const context = this.executionContext;
    if (!this.durableLoggingContext && !context) {
      throw new Error("DurableLoggingContext is not configured. Please call configureDurableLoggingContext before logging.");
    }
    if (this.durableLoggingContext) {
      return this.durableLoggingContext;
    }
    if (!context) {
      throw new Error("Execution context is not provided.");
    }
    return {
      getDurableLogData: () => {
        return {
          requestId: context.requestId,
          executionArn: context.durableExecutionArn,
          tenantId: context.tenantId
        };
      }
    };
  }
  log(level, message, ...optionalParams) {
    switch (level) {
      case DurableLogLevel.DEBUG:
        this.debug(message, ...optionalParams);
        break;
      case DurableLogLevel.INFO:
        this.info(message, ...optionalParams);
        break;
      case DurableLogLevel.WARN:
        this.warn(message, ...optionalParams);
        break;
      case DurableLogLevel.ERROR:
        this.error(message, ...optionalParams);
        break;
      default:
        this.info(message, ...optionalParams);
        break;
    }
  }
  // These method signatures will be set dynamically in configureLogLevel()
  info;
  error;
  warn;
  debug;
  configureDurableLoggingContext(durableLoggingContext) {
    this.durableLoggingContext = durableLoggingContext;
  }
};
var createDefaultLogger = (executionContext, enrichLogContext) => {
  return new DefaultLogger(executionContext, enrichLogContext);
};
var runtimeDir = process.env.LAMBDA_RUNTIME_DIR || "/var/runtime";
var moduleFilePath;
if (typeof __filename !== "undefined") {
  moduleFilePath = __filename;
} else if (typeof import_meta?.url === "string") {
  moduleFilePath = (0, import_node_url.fileURLToPath)(import_meta.url);
}
function isInLambdaRuntime() {
  try {
    if (!moduleFilePath) {
      return false;
    }
    return (0, import_node_path.dirname)(moduleFilePath).startsWith(runtimeDir);
  } catch {
    return false;
  }
}
var isRuntimeBundled = isInLambdaRuntime();
var SDK_NAME = "aws-durable-execution-sdk-js";
var baseVersion = "3.0.0";
var SDK_VERSION = isRuntimeBundled ? `${baseVersion}-bundled` : baseVersion;
var lambdaModulePromise;
var defaultLambdaClient;
var DEFAULT_CLIENT_CONFIG = {
  customUserAgent: [[SDK_NAME, SDK_VERSION]],
  requestHandler: {
    connectionTimeout: 5e3,
    socketTimeout: 5e4,
    requestTimeout: 55e3,
    throwOnRequestTimeout: true
  }
};
var loadLambdaModule = () => {
  lambdaModulePromise ??= import("@aws-sdk/client-lambda").then((module2) => {
    const namespace = module2;
    return "LambdaClient" in namespace ? namespace : namespace.default;
  }).catch((error) => {
    lambdaModulePromise = void 0;
    throw error;
  });
  return lambdaModulePromise;
};
var resolveDefaultLambdaClient = async () => {
  const module2 = await loadLambdaModule();
  defaultLambdaClient ??= new module2.LambdaClient(DEFAULT_CLIENT_CONFIG);
  return defaultLambdaClient;
};
var DurableExecutionApiClient = class {
  injectedClient;
  constructor(client) {
    this.injectedClient = client;
    void loadLambdaModule().then(() => void 0, () => void 0);
  }
  /**
   * Resolves the client and command constructors to use, creating and caching the default
   * client on first use when none was injected.
   */
  async resolveClient() {
    const module2 = await loadLambdaModule();
    const client = this.injectedClient ?? await resolveDefaultLambdaClient();
    return { client, module: module2 };
  }
  /**
   * Gets operation state data from the durable execution
   * @param params - The GetDurableExecutionState request
   * @param logger - Optional developer logger for error reporting
   * @returns Response with operations data
   */
  async getExecutionState(params, logger) {
    const { client, module: module2 } = await this.resolveClient();
    try {
      const response = await client.send(new module2.GetDurableExecutionStateCommand({
        DurableExecutionArn: params.DurableExecutionArn,
        CheckpointToken: params.CheckpointToken,
        Marker: params.Marker,
        MaxItems: params.MaxItems
      }));
      return response;
    } catch (error) {
      log("\u274C", "GetDurableExecutionState failed", {
        error,
        requestId: error?.$metadata?.requestId,
        DurableExecutionArn: params.DurableExecutionArn,
        CheckpointToken: params.CheckpointToken,
        Marker: params.Marker
      });
      if (logger) {
        logger.error("Failed to get durable execution state", error, {
          requestId: error?.$metadata?.requestId
        });
      }
      throw error;
    }
  }
  /**
   * Checkpoints the durable execution with operation updates
   * @param params - The checkpoint request
   * @param logger - Optional developer logger for error reporting
   * @returns Checkpoint response
   */
  async checkpoint(params, logger) {
    const { client, module: module2 } = await this.resolveClient();
    try {
      const response = await client.send(new module2.CheckpointDurableExecutionCommand({
        DurableExecutionArn: params.DurableExecutionArn,
        CheckpointToken: params.CheckpointToken,
        ClientToken: params.ClientToken,
        Updates: params.Updates
      }));
      return response;
    } catch (error) {
      log("\u274C", "CheckpointDurableExecution failed", {
        error,
        requestId: error?.$metadata?.requestId,
        DurableExecutionArn: params.DurableExecutionArn,
        CheckpointToken: params.CheckpointToken,
        ClientToken: params.ClientToken
      });
      if (logger) {
        logger.error("Failed to checkpoint durable execution", error, {
          requestId: error?.$metadata?.requestId
        });
      }
      throw error;
    }
  }
};
var DurableExecutionInvocationInputWithClient = class _DurableExecutionInvocationInputWithClient {
  durableExecutionClient;
  InitialExecutionState;
  DurableExecutionArn;
  CheckpointToken;
  UpdatedOperationIds;
  constructor(params, durableExecutionClient) {
    this.durableExecutionClient = durableExecutionClient;
    this.InitialExecutionState = params.InitialExecutionState;
    this.DurableExecutionArn = params.DurableExecutionArn;
    this.CheckpointToken = params.CheckpointToken;
    this.UpdatedOperationIds = params.UpdatedOperationIds;
  }
  static isInstance(event) {
    if (event instanceof _DurableExecutionInvocationInputWithClient) {
      return true;
    }
    return !!(typeof event === "object" && event && event.toString() === "[object DurableExecutionInvocationInputWithClient]" && "durableExecutionClient" in event && event.constructor.name === "DurableExecutionInvocationInputWithClient");
  }
  get [Symbol.toStringTag]() {
    return "DurableExecutionInvocationInputWithClient";
  }
};
var resolveDurableExecutionClient = (event, config) => {
  if (DurableExecutionInvocationInputWithClient.isInstance(event)) {
    if (config?.durableExecutionClient) {
      log("\u{1F500}", "Event-injected durable execution client overrides config.durableExecutionClient");
    }
    return event.durableExecutionClient;
  }
  return config?.durableExecutionClient ?? new DurableExecutionApiClient(config?.client);
};
var initializeExecutionContext = async (event, context, config) => {
  log("\u{1F535}", "Initializing durable function with event:", event);
  log("\u{1F4CD}", "Function Input:", event);
  const checkpointToken = event.CheckpointToken;
  const durableExecutionArn = event.DurableExecutionArn;
  const durableExecutionClient = resolveDurableExecutionClient(event, config);
  const initLogger = createDefaultLogger({
    durableExecutionArn,
    requestId: context.awsRequestId,
    tenantId: context.tenantId
  });
  warnOnceIfContextStorageIsDegraded(initLogger);
  const operationsArray = normalizeOperations(event.InitialExecutionState.Operations || []);
  let nextMarker = event.InitialExecutionState.NextMarker;
  while (nextMarker) {
    const response = await durableExecutionClient.getExecutionState({
      CheckpointToken: checkpointToken,
      Marker: nextMarker,
      DurableExecutionArn: durableExecutionArn,
      MaxItems: 1e3
    }, initLogger);
    operationsArray.push(...normalizeOperations(response.Operations || []));
    nextMarker = response.NextMarker || "";
  }
  const durableExecutionMode = operationsArray.length > 1 ? DurableExecutionMode.ReplayMode : DurableExecutionMode.ExecutionMode;
  log("\u{1F4DD}", "Operations:", operationsArray);
  const stepData = operationsArray.reduce((acc, operation) => {
    if (operation.Id) {
      acc[operation.Id] = operation;
    }
    return acc;
  }, {});
  log("\u{1F4DD}", "Loaded step data:", stepData);
  const updatedOperationIds = new Set(event.UpdatedOperationIds || []);
  return {
    executionContext: {
      durableExecutionClient,
      _stepData: stepData,
      terminationManager: new TerminationManager(),
      durableExecutionArn,
      pendingCompletions: /* @__PURE__ */ new Set(),
      getStepData(stepId) {
        return getStepData(stepData, stepId);
      },
      isOperationUpdatedBetweenInvocation(hashedOperationId) {
        return updatedOperationIds.has(hashedOperationId);
      },
      tenantId: context.tenantId,
      requestId: context.awsRequestId,
      // The one reduction here that is a function rather than a value, because the answer
      // changes over the life of the invocation. Where no deadline is known, a caller
      // supplies `() => Infinity`. A context that lacks the method, throws from it, or
      // returns something other than a finite number states no deadline either, so it
      // reads as `Infinity` too. Otherwise a stub context in a unit test, or a context
      // from another compute, would fail the invocation when the SDK reads the deadline.
      getRemainingTimeMs: () => {
        try {
          const remaining = context.getRemainingTimeInMillis();
          return typeof remaining === "number" && Number.isFinite(remaining) ? remaining : Infinity;
        } catch {
          return Infinity;
        }
      }
    },
    durableExecutionMode,
    checkpointToken
  };
};
function validateChildOperationsDepth(childOperationsDepth) {
  if (childOperationsDepth === void 0)
    return void 0;
  if (childOperationsDepth === Infinity)
    return void 0;
  if (typeof childOperationsDepth !== "number" || Number.isNaN(childOperationsDepth) || !Number.isInteger(childOperationsDepth) || childOperationsDepth < 0) {
    return `pluginsConfig.childOperationsDepth must be a non-negative integer or Infinity; got ${String(childOperationsDepth)}.`;
  }
  return void 0;
}
function resolveRootPreserveChildDepth(childOperationsDepth) {
  if (childOperationsDepth === void 0 || childOperationsDepth <= 0)
    return 0;
  if (childOperationsDepth === Infinity)
    return Infinity;
  return childOperationsDepth + 1;
}
function validateTransportConfig(config) {
  if (config?.client && config?.durableExecutionClient) {
    return "Both `client` and `durableExecutionClient` were provided, but they configure the same thing in incompatible ways: `client` supplies a Lambda client for the SDK's Lambda transport, while `durableExecutionClient` replaces the transport. Provide only `durableExecutionClient` \u2014 to keep the Lambda transport with your own client, pass it to DurableExecutionApiClient: `{ durableExecutionClient: new DurableExecutionApiClient(myLambdaClient) }`.";
  }
  return void 0;
}
function validateDurableExecutionConfig(config) {
  const childOperationsDepthError = validateChildOperationsDepth(config?.pluginsConfig?.childOperationsDepth);
  if (childOperationsDepthError)
    return childOperationsDepthError;
  return void 0;
}
function pluginIdentity(plugin, index) {
  try {
    return `${plugin.constructor.name || "Plugin"} (plugins[${index}])`;
  } catch {
    return `plugins[${index}]`;
  }
}
function warn(message, details) {
  try {
    console.warn(message, details);
  } catch {
  }
}
function collectPropagationMetadata(plugins, input) {
  const snapshot = Object.freeze({
    executionArn: input.executionArn,
    operationId: input.operationId,
    ...input.parentOperationId === void 0 ? {} : { parentOperationId: input.parentOperationId },
    targetFunctionName: input.targetFunctionName
  });
  let xAmznTraceId;
  let firstPlugin;
  let conflictCount = 0;
  for (const [index, plugin] of plugins.entries()) {
    const identity = pluginIdentity(plugin, index);
    try {
      const hook = plugin.providePropagationMetadata;
      if (hook == null)
        continue;
      if (typeof hook !== "function")
        throw new TypeError("Propagation hook must be callable");
      const result = hook.call(plugin, snapshot);
      if (result == null)
        continue;
      if (typeof result !== "object" || Array.isArray(result)) {
        throw new TypeError("Propagation metadata must be an object");
      }
      if (typeof result.then === "function") {
        void Promise.resolve(result).catch(() => {
        });
        throw new TypeError("Propagation hook must be synchronous");
      }
      const value = result.xAmznTraceId;
      if (value == null)
        continue;
      if (typeof value !== "string")
        throw new TypeError("xAmznTraceId must be a string");
      if (value.trim().length === 0)
        continue;
      if (xAmznTraceId === void 0) {
        xAmznTraceId = value;
        firstPlugin = identity;
      } else if (value !== xAmznTraceId) {
        warn("Conflicting propagation metadata; keeping the first value.", {
          field: "xAmznTraceId",
          firstPlugin,
          laterPlugin: identity,
          conflictCount: ++conflictCount
        });
      }
    } catch {
      warn("Ignoring invalid propagation metadata from plugin.", {
        plugin: identity
      });
    }
  }
  return Object.freeze(xAmznTraceId === void 0 ? {} : { xAmznTraceId });
}
var PLUGIN_DRAIN_RESERVE_MS = 500;
var PLUGIN_END_RESERVE_MS = 50;
function readRemainingMs(read) {
  try {
    const value = read?.();
    return typeof value === "number" && Number.isFinite(value) ? value : Infinity;
  } catch {
    return Infinity;
  }
}
async function settleBy(promises, endBy) {
  if (promises.length === 0)
    return;
  const all = Promise.all(promises).then(() => true);
  if (endBy === Infinity) {
    await all;
    return;
  }
  while (Date.now() < endBy) {
    const delayMs = Math.min(endBy - Date.now(), MAX_TIMER_DELAY_MS);
    let timer;
    const timeout = new Promise((resolve) => {
      timer = setTimeout(() => resolve(false), delayMs);
    });
    try {
      if (await Promise.race([all, timeout]))
        return;
    } finally {
      clearTimeout(timer);
    }
  }
}
function createPluginRunner(plugins, options = {}) {
  if (plugins.length === 0)
    return {};
  const pending = /* @__PURE__ */ new Set();
  const invokeAll = (method, info) => plugins.map(async (p) => {
    const result = p[method]?.(info);
    if (result != null && typeof result.then === "function") {
      await result;
    }
  }).map((promise) => promise.catch(() => void 0));
  const runAsCallback = (method, info, fn) => {
    let fnError;
    let fnCalled = false;
    let fnResult;
    const guardedFn = () => {
      if (fnCalled)
        return fnResult;
      fnCalled = true;
      try {
        const result2 = fn();
        if (result2 != null && typeof result2.then === "function") {
          fnResult = result2.catch((err) => {
            fnError = { error: err };
            throw err;
          });
          return fnResult;
        }
        fnResult = result2;
        return result2;
      } catch (err) {
        fnError = { error: err };
        throw err;
      }
    };
    const chain = plugins.reduceRight((next, plugin) => () => {
      const hookFn = plugin[method];
      if (!hookFn)
        return next();
      let nextCalled = false;
      let nextResult;
      const guardedNext = () => {
        if (nextCalled)
          return nextResult;
        nextCalled = true;
        nextResult = next();
        return nextResult;
      };
      const recover = () => {
        if (fnError)
          throw fnError.error;
        return guardedNext();
      };
      let out;
      try {
        out = hookFn.call(plugin, info, guardedNext);
      } catch {
        return recover();
      }
      if (out != null && typeof out.then === "function") {
        return out.then((val) => val, recover);
      }
      return out;
    }, guardedFn);
    let result;
    try {
      result = chain();
    } catch (_err) {
      if (fnError)
        throw fnError.error;
      result = guardedFn();
    }
    if (result != null && typeof result.then === "function") {
      return result.then((val) => {
        if (fnError)
          throw fnError.error;
        return val;
      });
    }
    if (fnError)
      throw fnError.error;
    return result;
  };
  const run = async (method, info) => {
    await Promise.allSettled(invokeAll(method, info));
  };
  const fireAndForget = (method, info) => {
    for (const promise of invokeAll(method, info)) {
      pending.add(promise);
      void promise.then(() => pending.delete(promise));
    }
    return Promise.resolve();
  };
  const drainAndEnd = async (info) => {
    const deadline = readRemainingMs(options.getRemainingTimeMs) + Date.now();
    const drainEndBy = deadline - PLUGIN_DRAIN_RESERVE_MS;
    while (pending.size > 0 && Date.now() < drainEndBy) {
      await settleBy([...pending], drainEndBy);
    }
    await settleBy(invokeAll("onInvocationEnd", info), deadline - PLUGIN_END_RESERVE_MS);
  };
  return {
    providePropagationMetadata: (input) => collectPropagationMetadata(plugins, input),
    onInvocationStart: (info) => run("onInvocationStart", info),
    wrapInvocation: (info, fn) => runAsCallback("wrapInvocation", info, fn),
    onInvocationEnd: (info) => drainAndEnd(info),
    onOperationStart: (info) => fireAndForget("onOperationStart", info),
    wrapChildContextFn: (info, fn) => runAsCallback("wrapChildContextFn", info, fn),
    onOperationEnd: (info) => fireAndForget("onOperationEnd", info),
    onOperationAttemptStart: (info) => fireAndForget("onOperationAttemptStart", info),
    wrapOperationAttemptFn: (info, fn) => runAsCallback("wrapOperationAttemptFn", info, fn),
    onOperationAttemptEnd: (info) => fireAndForget("onOperationAttemptEnd", info),
    onOperationChange: (info) => fireAndForget("onOperationChange", info),
    enrichLogContext: () => plugins.reduce((acc, p) => {
      try {
        return { ...acc, ...p.enrichLogContext?.() };
      } catch {
        return acc;
      }
    }, {})
  };
}
function createInvocationPluginRunner(factories, info, options = {}) {
  const plugins = [];
  for (const factory of factories) {
    let plugin;
    try {
      plugin = factory.createPlugin(info);
      if (plugin != null && typeof plugin.then === "function") {
        void Promise.resolve(plugin).catch(() => void 0);
        continue;
      }
    } catch {
      continue;
    }
    if (plugin != null) {
      plugins.push(plugin);
    }
  }
  return createPluginRunner(plugins, options);
}
var PluginLoadError = class extends Error {
  constructor(message, options) {
    super(`Plugin configuration failed: ${message}`, options);
    this.name = "PluginLoadError";
  }
};
var PLUGIN_ENVIRONMENT_VARIABLE = "DURABLE_EXECUTION_PLUGINS";
var PLUGIN_PROVIDER_EXPORT = "durableExecutionPluginProvider";
var PluginModuleResolutionError = class extends AggregateError {
  constructor(specifier, errors) {
    super(errors, `Unable to resolve '${specifier}' from the application or configured Node.js module paths.`);
    this.name = "PluginModuleResolutionError";
  }
};
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}
function packageNameFromSpecifier(specifier) {
  if (specifier.startsWith(".") || specifier.startsWith("/") || /^[a-zA-Z][a-zA-Z\d+.-]*:/.test(specifier)) {
    return void 0;
  }
  const segments = specifier.split("/");
  return specifier.startsWith("@") ? segments.slice(0, 2).join("/") : segments[0];
}
function isConfiguredSpecifierNotFound(error, specifier) {
  if (!isRecord(error)) {
    return false;
  }
  if (error.code !== "ERR_MODULE_NOT_FOUND" && error.code !== "MODULE_NOT_FOUND") {
    return false;
  }
  const message = errorMessage(error);
  const targets = new Set([specifier, packageNameFromSpecifier(specifier)].filter((target) => target != null && target !== ""));
  return [...targets].some((target) => [
    `Cannot find package '${target}'`,
    `Cannot find package "${target}"`,
    `Cannot find module '${target}'`,
    `Cannot find module "${target}"`
  ].some((prefix) => message.includes(prefix)));
}
function parseConfiguredSpecifiers(environment) {
  const configuredPlugins = environment[PLUGIN_ENVIRONMENT_VARIABLE];
  if (configuredPlugins == null || configuredPlugins.trim() === "") {
    return [];
  }
  const specifiers = configuredPlugins.split(",").map((value) => value.trim());
  if (specifiers.some((specifier) => specifier === "")) {
    throw new PluginLoadError(`${PLUGIN_ENVIRONMENT_VARIABLE} must contain non-empty, comma-separated package or module specifiers.`);
  }
  const seen = /* @__PURE__ */ new Set();
  for (const specifier of specifiers) {
    if (seen.has(specifier)) {
      throw new PluginLoadError(`${PLUGIN_ENVIRONMENT_VARIABLE} contains duplicate module specifier '${specifier}'.`);
    }
    seen.add(specifier);
  }
  return specifiers;
}
function createDefaultModuleImporter(environment, dependencies = {}) {
  const applicationRoot = environment.LAMBDA_TASK_ROOT?.trim() || process.cwd();
  const requireFromApplication = (0, import_module.createRequire)((0, import_path.join)(applicationRoot, "package.json"));
  const importModule = dependencies.importModule ?? ((specifier) => import(specifier));
  const resolveModule = dependencies.resolveModule ?? ((specifier) => requireFromApplication.resolve(specifier));
  return async (specifier) => {
    try {
      return await importModule(specifier);
    } catch (importError) {
      if (!isConfiguredSpecifierNotFound(importError, specifier)) {
        throw importError;
      }
      let resolvedPath;
      try {
        resolvedPath = resolveModule(specifier);
      } catch (resolveError) {
        throw new PluginModuleResolutionError(specifier, [
          importError,
          resolveError
        ]);
      }
      return importModule((0, import_url.pathToFileURL)(resolvedPath).href);
    }
  };
}
function getProviderExport(specifier, importedModule) {
  if (!isRecord(importedModule)) {
    throw new PluginLoadError(`Plugin module '${specifier}' did not evaluate to a module namespace object.`);
  }
  const module2 = importedModule;
  const directProvider = module2[PLUGIN_PROVIDER_EXPORT];
  const defaultExport = module2.default;
  const nestedProvider = isRecord(defaultExport) ? defaultExport[PLUGIN_PROVIDER_EXPORT] : void 0;
  const candidates = [directProvider, nestedProvider].filter((candidate, index, values) => candidate !== void 0 && values.indexOf(candidate) === index);
  if (candidates.length === 0) {
    throw new PluginLoadError(`Plugin module '${specifier}' must export '${PLUGIN_PROVIDER_EXPORT}'.`);
  }
  if (candidates.length > 1) {
    throw new PluginLoadError(`Plugin module '${specifier}' exposes multiple different '${PLUGIN_PROVIDER_EXPORT}' values.`);
  }
  return candidates[0];
}
function isPluginFactory(value) {
  if (value === null || typeof value !== "object" && typeof value !== "function") {
    return false;
  }
  return typeof value.createPlugin === "function";
}
function getRegistrations(plugin) {
  if (!(DURABLE_INSTRUMENTATION_PLUGIN_REGISTRATION in plugin))
    return [];
  const registrations = [];
  const visited = /* @__PURE__ */ new Set();
  for (let current = plugin; current !== null && (typeof current === "object" || typeof current === "function") && !visited.has(current); current = Object.getPrototypeOf(current)) {
    visited.add(current);
    if (!Object.hasOwn(current, DURABLE_INSTRUMENTATION_PLUGIN_REGISTRATION))
      continue;
    const registration = Reflect.get(current, DURABLE_INSTRUMENTATION_PLUGIN_REGISTRATION, plugin);
    if (registration)
      registrations.push(registration);
  }
  return registrations;
}
function validateExclusiveGroups(plugins) {
  const groups = /* @__PURE__ */ new Map();
  for (const plugin of plugins) {
    const registrations = getRegistrations(plugin);
    const [nearest] = registrations;
    if (!nearest)
      continue;
    const registeredGroups = /* @__PURE__ */ new Set();
    for (const registration of registrations) {
      const group = registration.exclusiveGroup;
      if (!group || registeredGroups.has(group))
        continue;
      registeredGroups.add(group);
      const previous = groups.get(group);
      if (previous !== void 0) {
        throw new PluginLoadError(`Plugins '${previous}' and '${nearest.name}' are mutually exclusive in group '${group}'. Configure only one.`);
      }
      groups.set(group, nearest.name);
    }
  }
}
function validatePluginFactory(subject, providerValue, guidance = "") {
  if (providerValue != null && (typeof providerValue === "object" || typeof providerValue === "function") && "pluginApiVersion" in providerValue) {
    throw new PluginLoadError(`${subject} declares the legacy v1 provider contract, which SDK 3.x no longer accepts. Migrate to a factory with createPlugin(info) that returns a fresh plugin for each invocation, and remove the legacy pluginApiVersion/pluginType metadata. For bundled OTel plugins, upgrade to the SDK 3.x-compatible OTel factory package.`);
  }
  if (!isPluginFactory(providerValue)) {
    throw new PluginLoadError(`${subject} must be an object with a 'createPlugin(info)' method that creates a plugin for one invocation, but it is ${describeValue(providerValue)}.${guidance}`);
  }
  return providerValue;
}
function describeValue(value) {
  if (value === null)
    return "null";
  if (value === void 0)
    return "undefined";
  if (Array.isArray(value))
    return "an array";
  const type = typeof value;
  return type === "object" ? "an object" : `a ${type}`;
}
async function loadConfiguredPlugins(explicitPlugins, options = {}) {
  const plugins = (explicitPlugins ?? []).map((plugin, index) => validatePluginFactory(`Plugin at plugins[${index}]`, plugin, " Pass a factory such as `{ createPlugin: (info) => new MyPlugin() }`."));
  const environment = options.environment ?? process.env;
  const specifiers = parseConfiguredSpecifiers(environment);
  validateExclusiveGroups(plugins);
  if (specifiers.length === 0) {
    return plugins;
  }
  const importModule = options.importModule ?? createDefaultModuleImporter(environment, options.moduleImporterDependencies);
  for (const specifier of specifiers) {
    let importedModule;
    try {
      importedModule = await importModule(specifier);
    } catch (error) {
      const packagingGuidance = error instanceof PluginModuleResolutionError ? " Ensure the package is installed in the function artifact or an attached Lambda layer under 'nodejs/node_modules'." : "";
      throw new PluginLoadError(`Failed to load plugin module '${specifier}': ${errorMessage(error)}${packagingGuidance}`, { cause: error });
    }
    plugins.push(validatePluginFactory(`Plugin provider '${specifier}'`, getProviderExport(specifier, importedModule)));
  }
  validateExclusiveGroups(plugins);
  return plugins;
}
var LAMBDA_RESPONSE_SIZE_LIMIT = 6 * 1024 * 1024 - 50;
async function runHandler(event, context, executionContext, durableExecutionMode, checkpointToken, handler2, pluginFactories, config) {
  const initialExecutionEvent = executionContext._stepData[Object.keys(executionContext._stepData)[0]];
  const customerHandlerEvent = JSON.parse(initialExecutionEvent?.ExecutionDetails?.InputPayload ?? "{}");
  const allOperations = toOperationInfoMap(executionContext._stepData);
  const updatedOperationIds = event.UpdatedOperationIds ?? [];
  const updatedOperations = {};
  for (const id of updatedOperationIds) {
    if (allOperations[id]) {
      updatedOperations[id] = allOperations[id];
    }
  }
  const invocationBaseInfo = {
    requestId: executionContext.requestId,
    executionArn: executionContext.durableExecutionArn,
    executionInput: customerHandlerEvent,
    operations: allOperations,
    executionStartTimestamp: initialExecutionEvent?.StartTimestamp ?? void 0
  };
  let runtimeTraceInfo = {};
  if (pluginFactories.length > 0) {
    try {
      const xRayTraceId = context.xRayTraceId;
      if (xRayTraceId !== void 0 || "xRayTraceId" in context) {
        runtimeTraceInfo = { xRayTraceId: xRayTraceId ?? "" };
      }
    } catch {
      runtimeTraceInfo = { xRayTraceId: "" };
    }
  }
  const invocationInfo = {
    ...invocationBaseInfo,
    isFirstInvocation: durableExecutionMode === DurableExecutionMode.ExecutionMode,
    updatedOperations,
    ...runtimeTraceInfo
  };
  const plugin = createInvocationPluginRunner(pluginFactories, invocationInfo, { getRemainingTimeMs: executionContext.getRemainingTimeMs });
  const stepDataEmitter = new import_events.EventEmitter();
  const checkpointManager = new CheckpointManager(executionContext.durableExecutionArn, executionContext._stepData, executionContext.durableExecutionClient, executionContext.terminationManager, checkpointToken, stepDataEmitter, createDefaultLogger(executionContext, plugin.enrichLogContext?.bind(plugin)), /* @__PURE__ */ new Set(), plugin, executionContext.requestId, executionContext.getRemainingTimeMs);
  await plugin.onInvocationStart?.(invocationInfo);
  const configError = validateDurableExecutionConfig(config);
  if (configError) {
    const error = new Error(configError);
    await plugin.onInvocationEnd?.({
      ...invocationBaseInfo,
      status: PluginInvocationStatus.FAILED,
      executionInput: customerHandlerEvent,
      executionError: error,
      executionResult: void 0,
      operations: allOperations
    });
    return {
      Status: InvocationStatus.FAILED,
      Error: createErrorObjectFromError(error)
    };
  }
  executionContext.terminationManager.setCheckpointTerminatingCallback(() => {
    checkpointManager.setTerminating();
  });
  const durableExecution = {
    checkpointManager,
    stepDataEmitter,
    plugin,
    setTerminating: () => checkpointManager.setTerminating()
  };
  const rootPreserveChildDepth = resolveRootPreserveChildDepth(config?.pluginsConfig?.childOperationsDepth);
  const durableContext = createDurableContext(
    executionContext,
    context,
    durableExecutionMode,
    // Default logger may not have the same type as Logger, but we should always provide a default logger even if the user overrides it
    createDefaultLogger(void 0, plugin.enrichLogContext?.bind(plugin)),
    void 0,
    durableExecution,
    void 0,
    rootPreserveChildDepth
  );
  const executeInvocation = async () => {
    const answerPending = async (executionError) => {
      await plugin.onInvocationEnd?.({
        ...invocationBaseInfo,
        status: PluginInvocationStatus.PENDING,
        executionInput: customerHandlerEvent,
        executionResult: void 0,
        executionError,
        operations: toOperationInfoMap(executionContext._stepData)
      });
      return {
        Status: InvocationStatus.PENDING
      };
    };
    const answerFailed = async (error) => {
      const response = {
        Status: InvocationStatus.FAILED,
        Error: createErrorObjectFromError(error)
      };
      await plugin.onInvocationEnd?.({
        ...invocationBaseInfo,
        status: PluginInvocationStatus.FAILED,
        executionInput: customerHandlerEvent,
        executionError: error,
        executionResult: void 0,
        operations: toOperationInfoMap(executionContext._stepData)
      });
      return response;
    };
    try {
      log("\u{1F3AF}", `Starting handler execution, handler event: ${customerHandlerEvent}`);
      let handlerPromiseResolved = false;
      let terminationPromiseResolved = false;
      let termination;
      const handlerPromise = runWithRootContext({
        executionArn: executionContext.durableExecutionArn,
        requestId: executionContext.requestId,
        tenantId: executionContext.tenantId,
        enrichLogContext: plugin.enrichLogContext?.bind(plugin)
      }, () => handler2(customerHandlerEvent, durableContext)).then((result2) => {
        handlerPromiseResolved = true;
        log("\u{1F3C6}", "Handler promise resolved first!");
        return ["handler", result2];
      });
      const terminationPromise = executionContext.terminationManager.getTerminationPromise().then((result2) => {
        terminationPromiseResolved = true;
        termination = result2;
        log("\u{1F4A5}", "Termination promise resolved first!");
        durableExecution.setTerminating();
        return ["termination", result2];
      });
      setTimeout(() => {
        log("\u23F1\uFE0F", "Promise race status check:", {
          handlerResolved: handlerPromiseResolved,
          terminationResolved: terminationPromiseResolved
        });
      }, 500);
      const [resultType, result] = await Promise.race([
        handlerPromise,
        terminationPromise
      ]);
      log("\u{1F3C1}", "Promise race completed with:", {
        resultType
      });
      try {
        await durableExecution.checkpointManager.waitForQueueCompletion();
        log("\u2705", "All pending checkpoints completed");
      } catch (error) {
        log("\u26A0\uFE0F", "Error waiting for checkpoint completion:", error);
      }
      const answerWhenOutcomeCannotBeReported = async () => {
        if (durableExecution.checkpointManager.isCheckpointTokenRevoked()) {
          log("\u{1F6D1}", "Checkpoint token withdrawn - answering PENDING", termination ? { reason: termination.reason } : {});
          return await answerPending(termination?.error);
        }
        if (!termination) {
          return void 0;
        }
        if (termination.reason === TerminationReason.CHECKPOINT_FAILED) {
          log("\u{1F6D1}", "Checkpoint failed - handling termination");
          throw termination.error;
        }
        if (termination.reason === TerminationReason.SERDES_FAILED) {
          log("\u{1F6D1}", "Serdes failed - terminating Lambda execution");
          throw new SerdesFailedError(termination.message);
        }
        if (classifyTermination(termination.reason) === "suspend") {
          log("\u{1F6D1}", "Returning termination response", {
            reason: termination.reason
          });
          return await answerPending(termination.error);
        }
        const error = termination.error ?? new Error(termination.message);
        log("\u{1F6D1}", `Terminated with ${termination.reason} - returning FAILED status`, {
          message: termination.message
        });
        return await answerFailed(error);
      };
      const answer = await answerWhenOutcomeCannotBeReported();
      if (answer) {
        return answer;
      }
      if (resultType !== "handler") {
        throw new Error(`Unhandled termination reason: ${String(termination?.reason)}`);
      }
      log("\u2705", "Returning normal completion response");
      const serializedResult = JSON.stringify(result);
      const serializedSize = new TextEncoder().encode(serializedResult).length;
      if (serializedResult && serializedSize > LAMBDA_RESPONSE_SIZE_LIMIT) {
        log("\u{1F4E6}", `Response size (${serializedSize} bytes) exceeds Lambda limit (${LAMBDA_RESPONSE_SIZE_LIMIT} bytes). Checkpointing result.`);
        const stepId = `execution-result-${Date.now()}`;
        try {
          const outcome = await durableExecution.checkpointManager.checkpointExecutionResult(stepId, {
            Id: stepId,
            Action: "SUCCEED",
            Type: OperationType.EXECUTION,
            Payload: serializedResult
            // Reuse the already serialized result
          });
          if (outcome === "abandoned") {
            const abandonedAnswer = await answerWhenOutcomeCannotBeReported();
            if (abandonedAnswer) {
              return abandonedAnswer;
            }
            throw new Error("Execution result was not checkpointed and no termination was recorded");
          }
          log("\u2705", "Large result successfully checkpointed");
          try {
            await durableExecution.checkpointManager.waitForQueueCompletion();
          } catch (waitError) {
            log("\u26A0\uFE0F", "Error waiting for checkpoint queue completion:", waitError);
          }
          await plugin.onInvocationEnd?.({
            ...invocationBaseInfo,
            status: PluginInvocationStatus.SUCCEEDED,
            executionInput: customerHandlerEvent,
            executionResult: result,
            executionError: void 0,
            operations: toOperationInfoMap(executionContext._stepData)
          });
          return {
            Status: InvocationStatus.SUCCEEDED,
            Result: ""
          };
        } catch (checkpointError) {
          log("\u274C", "Failed to checkpoint large result:", checkpointError);
          throw checkpointError;
        }
      }
      try {
        await durableExecution.checkpointManager.waitForQueueCompletion();
      } catch (waitError) {
        log("\u26A0\uFE0F", "Error waiting for checkpoint queue completion:", waitError);
      }
      const lateAnswer = await answerWhenOutcomeCannotBeReported();
      if (lateAnswer) {
        return lateAnswer;
      }
      await plugin.onInvocationEnd?.({
        ...invocationBaseInfo,
        status: PluginInvocationStatus.SUCCEEDED,
        executionInput: customerHandlerEvent,
        executionResult: result,
        executionError: void 0,
        operations: toOperationInfoMap(executionContext._stepData)
      });
      return {
        Status: InvocationStatus.SUCCEEDED,
        Result: serializedResult
      };
    } catch (error) {
      log("\u274C", "Handler threw an error:", error);
      if (isUnrecoverableInvocationError(error) && durableExecution.checkpointManager.isCheckpointTokenRevoked()) {
        log("\u{1F6D1}", "Unrecoverable invocation error after the token was withdrawn - answering PENDING");
        return await answerPending(error);
      }
      if (isUnrecoverableInvocationError(error)) {
        log("\u{1F6D1}", "Unrecoverable invocation error - terminating Lambda execution");
        await plugin.onInvocationEnd?.({
          ...invocationBaseInfo,
          status: PluginInvocationStatus.RETRYING,
          executionInput: customerHandlerEvent,
          executionError: error,
          executionResult: void 0,
          operations: toOperationInfoMap(executionContext._stepData)
        });
        throw error;
      }
      try {
        await durableExecution.checkpointManager.waitForQueueCompletion();
      } catch (waitError) {
        log("\u26A0\uFE0F", "Error waiting for checkpoint queue completion:", waitError);
      }
      if (durableExecution.checkpointManager.isCheckpointTokenRevoked()) {
        log("\u{1F6D1}", "Checkpoint token withdrawn - answering PENDING");
        return await answerPending(error instanceof Error ? error : new Error(String(error)));
      }
      await plugin.onInvocationEnd?.({
        ...invocationBaseInfo,
        status: PluginInvocationStatus.FAILED,
        executionInput: customerHandlerEvent,
        executionError: error instanceof Error ? error : new Error(String(error)),
        executionResult: void 0,
        operations: toOperationInfoMap(executionContext._stepData)
      });
      return {
        Status: InvocationStatus.FAILED,
        Error: createErrorObjectFromError(error)
      };
    }
  };
  try {
    return await (plugin.wrapInvocation?.(invocationInfo, executeInvocation) ?? executeInvocation());
  } finally {
    checkpointManager.dispose();
  }
}
function validateDurableExecutionEvent(event) {
  const eventObj = event;
  if (!eventObj?.DurableExecutionArn || !eventObj?.CheckpointToken) {
    throw new Error("Unexpected payload provided to start the durable execution.\nCheck your resource configurations to confirm the durability is set.");
  }
}
var withDurableExecution = (handler2, config) => {
  const pluginFactoriesPromise = loadConfiguredPlugins(config?.plugins);
  void pluginFactoriesPromise.catch(() => void 0);
  return async (event, context) => {
    validateDurableExecutionEvent(event);
    const transportConfigError = validateTransportConfig(config);
    if (transportConfigError) {
      return {
        Status: InvocationStatus.FAILED,
        Error: createErrorObjectFromError(new Error(transportConfigError))
      };
    }
    let pluginFactories;
    try {
      pluginFactories = await pluginFactoriesPromise;
    } catch (error) {
      return {
        Status: InvocationStatus.FAILED,
        Error: createErrorObjectFromError(error)
      };
    }
    try {
      const { executionContext, durableExecutionMode, checkpointToken } = await initializeExecutionContext(event, context, config);
      return await runHandler(event, context, executionContext, durableExecutionMode, checkpointToken, handler2, pluginFactories, config);
    } catch (error) {
      if (isDurableExecutionClientError(error) && error.scope === DurableExecutionClientErrorScope.EXECUTION) {
        return {
          Status: InvocationStatus.FAILED,
          Error: createErrorObjectFromError(error)
        };
      }
      if (isNonRetryableCustomerError(error)) {
        return {
          Status: InvocationStatus.FAILED,
          Error: createErrorObjectFromError(error)
        };
      }
      throw error;
    }
  };
};
var FieldMatchMode;
(function(FieldMatchMode2) {
  FieldMatchMode2["ANYWHERE"] = "ANYWHERE";
  FieldMatchMode2["PATH"] = "PATH";
})(FieldMatchMode || (FieldMatchMode = {}));
var PreviewMode;
(function(PreviewMode2) {
  PreviewMode2["INCLUDE_ALL"] = "INCLUDE_ALL";
  PreviewMode2["EXCLUDE_ALL"] = "EXCLUDE_ALL";
})(PreviewMode || (PreviewMode = {}));
var OVERFLOW_THRESHOLD_BYTES = CHECKPOINT_SIZE_LIMIT_BYTES - 1024;
var FileSystemSerdesMode;
(function(FileSystemSerdesMode2) {
  FileSystemSerdesMode2["ALWAYS"] = "ALWAYS";
  FileSystemSerdesMode2["OVERFLOW"] = "OVERFLOW";
})(FileSystemSerdesMode || (FileSystemSerdesMode = {}));
var FileSystemPathEncoding;
(function(FileSystemPathEncoding2) {
  FileSystemPathEncoding2["URI"] = "URI";
  FileSystemPathEncoding2["HASH"] = "HASH";
})(FileSystemPathEncoding || (FileSystemPathEncoding = {}));
var DEFAULT_CONFIG = {
  maxAttempts: 60,
  initialDelay: { seconds: 5 },
  maxDelay: { seconds: 300 },
  // 5 minutes
  backoffRate: 1.5,
  jitter: JitterStrategy.FULL,
  timeoutSeconds: void 0
  // No timeout by default
};

// src/toolkit-cleaner/clean.lambda.ts
var import_client_cloudformation = require("@aws-sdk/client-cloudformation");
var import_client_ecr = require("@aws-sdk/client-ecr");
var import_client_s3 = require("@aws-sdk/client-s3");

// src/utils/index.ts
function getEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Environment variable ${name} is not set`);
  }
  return value;
}

// src/toolkit-cleaner/clean.lambda.ts
var cloudFormationClient = new import_client_cloudformation.CloudFormationClient({});
var s3Client = new import_client_s3.S3Client({});
var ecrClient = new import_client_ecr.ECRClient({});
var handler = withDurableExecution(async (_, context) => {
  const stackNames = await context.step("get-stack-names", getStackNames);
  context.logger.info(`Found ${stackNames.length} stacks`);
  let assetHashes = [];
  if (stackNames.length > 0) {
    const hashResults = await context.map(
      "extract-hashes",
      stackNames,
      (mapContext, stackName) => mapContext.step(`extract-hash-${stackName}`, () => extractHashes(stackName)),
      { maxConcurrency: 1 }
    );
    assetHashes = [...new Set(hashResults.getResults().flat())];
  }
  context.logger.info(`Found ${assetHashes.length} unique asset hashes`);
  const cleanResults = await context.parallel(
    "clean-assets",
    [
      async (branchContext) => branchContext.runInChildContext("clean-objects", (childContext) => cleanObjects(childContext, assetHashes)),
      async (branchContext) => branchContext.runInChildContext("clean-images", (childContext) => cleanImages(childContext, assetHashes))
    ]
  );
  const [cleanObjectsResult, cleanImagesResult] = cleanResults.getResults();
  const result = {
    Deleted: cleanObjectsResult.Deleted + cleanImagesResult.Deleted,
    Reclaimed: cleanObjectsResult.Reclaimed + cleanImagesResult.Reclaimed
  };
  context.logger.info("Cleanup complete", result);
  return result;
});
async function getStackNames() {
  const stacks = [];
  let nextToken;
  do {
    const response = await cloudFormationClient.send(new import_client_cloudformation.DescribeStacksCommand({ NextToken: nextToken }));
    for (const stack of response.Stacks ?? []) {
      if (stack.StackName) {
        stacks.push(stack.StackName);
      }
    }
    nextToken = response.NextToken;
  } while (nextToken);
  return stacks;
}
async function extractHashes(stackName) {
  const template = await cloudFormationClient.send(new import_client_cloudformation.GetTemplateCommand({
    StackName: stackName
  }));
  if (!template.TemplateBody) {
    return [];
  }
  const dockerTagPrefix = findDockerTagPrefix(getEnv("DOCKER_IMAGE_ASSET_HASH"));
  const regexp = new RegExp(`(${dockerTagPrefix})?[a-f0-9]{64}`, "g");
  const matches = template.TemplateBody.match(regexp);
  return [...new Set(matches)];
}
function findDockerTagPrefix(hash) {
  if (hash.length === 64) {
    return "";
  }
  return hash.substring(0, hash.length - 64);
}
async function cleanObjects(context, assetHashes) {
  const strategy = {
    list: async (token) => s3Client.send(new import_client_s3.ListObjectVersionsCommand({
      Bucket: getEnv("BUCKET_NAME"),
      KeyMarker: token
    })),
    getItems: (result) => result.Versions,
    getNextToken: (result) => result.NextKeyMarker,
    extractHash: (item) => item.Key ? path.basename(item.Key, path.extname(item.Key)) : void 0,
    getDate: (item) => item.LastModified,
    getSize: (item) => item.Size ?? 0,
    delete: async (items) => {
      await s3Client.send(new import_client_s3.DeleteObjectsCommand({
        Bucket: getEnv("BUCKET_NAME"),
        Delete: {
          Objects: items.map((v) => ({ Key: v.Key, VersionId: v.VersionId }))
        }
      }));
    }
  };
  return cleanAssets({
    stepNamePrefix: "list-and-delete-objects",
    strategy,
    context,
    assetHashes
  });
}
async function cleanImages(context, assetHashes) {
  const strategy = {
    list: async (token) => ecrClient.send(new import_client_ecr.DescribeImagesCommand({
      repositoryName: getEnv("REPOSITORY_NAME"),
      nextToken: token
    })),
    getItems: (result) => result.imageDetails,
    getNextToken: (result) => result.nextToken,
    extractHash: (item) => item.imageTags?.[0],
    getDate: (item) => item.imagePushedAt,
    getSize: (item) => item.imageSizeInBytes ?? 0,
    delete: async (items) => {
      await ecrClient.send(new import_client_ecr.BatchDeleteImageCommand({
        repositoryName: getEnv("REPOSITORY_NAME"),
        imageIds: items.map((x) => ({ imageTag: x.imageTags[0] }))
      }));
    }
  };
  return cleanAssets({
    stepNamePrefix: "list-and-delete-images",
    strategy,
    context,
    assetHashes
  });
}
async function cleanAssets(options) {
  const { context, assetHashes, strategy, stepNamePrefix } = options;
  let deleted = 0;
  let reclaimed = 0;
  let pageIndex = 0;
  let paginationToken;
  do {
    const response = await context.step(`${stepNamePrefix}-${pageIndex}`, (stepContext) => listAndDeleteAssets({
      strategy,
      assetHashes,
      logger: stepContext.logger,
      paginationToken
    }));
    deleted += response.Deleted;
    reclaimed += response.Reclaimed;
    paginationToken = response.nextToken;
    pageIndex++;
  } while (paginationToken);
  return { Deleted: deleted, Reclaimed: reclaimed };
}
async function listAndDeleteAssets(options) {
  const { strategy, assetHashes, logger, paginationToken } = options;
  const response = await strategy.list(paginationToken);
  const items = strategy.getItems(response) ?? [];
  const toDelete = items.filter((item) => {
    const hash = strategy.extractHash(item);
    if (!hash) {
      return false;
    }
    let pred = !assetHashes.includes(hash);
    if (process.env.RETAIN_MILLISECONDS) {
      const date = strategy.getDate(item);
      if (!date) {
        return false;
      }
      const limitDate = new Date(Date.now() - parseInt(process.env.RETAIN_MILLISECONDS));
      pred = pred && date < limitDate;
    }
    return pred;
  });
  if (toDelete.length === 0) {
    return { Deleted: 0, Reclaimed: 0, nextToken: strategy.getNextToken(response) };
  }
  if (!process.env.RUN) {
    logger.info("Dry run mode, skipping delete", { count: toDelete.length });
    return { Deleted: 0, Reclaimed: 0, nextToken: strategy.getNextToken(response) };
  }
  await strategy.delete(toDelete);
  return {
    Deleted: toDelete.length,
    Reclaimed: toDelete.reduce((acc, item) => acc + strategy.getSize(item), 0),
    nextToken: strategy.getNextToken(response)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
